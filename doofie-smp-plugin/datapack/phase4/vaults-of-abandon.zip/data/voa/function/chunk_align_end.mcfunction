#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#This command defines and summons the entity that will allow us to manipulate what happens with each chunk.

#Take Data
execute store result score x coords run data get entity @s Pos[0] 
execute store result score z coords run data get entity @s Pos[2]

#Do Calculation
scoreboard players operation #x coords = x coords
scoreboard players operation #z coords = z coords
scoreboard players operation #x coords %= #16 constant
scoreboard players operation #z coords %= #16 constant

#Put data back
summon area_effect_cloud ~ ~ ~ {Tags:["chunk_align"]}
execute store result entity @e[type=area_effect_cloud,tag=chunk_align,limit=1] Pos[0] double 1 run scoreboard players operation x coords -= #x coords
execute store result entity @e[type=area_effect_cloud,tag=chunk_align,limit=1] Pos[2] double 1 run scoreboard players operation z coords -= #z coords

#Adds Surface Detection Scoreboard + Intializes it
scoreboard players add @e[type=area_effect_cloud,tag=chunk_align] surfacecheck 0


#SET CHUNK COMMAND IS WHERE WE SPAWN THE STRUCTURES OR DO WHAT WE WANNA DO TO THE WORLD. Reference the 11 minute mark on video.
execute at @e[type=area_effect_cloud,tag=chunk_align] run function voa:set_chunk_end
kill @e[type=area_effect_cloud,tag=chunk_align]
