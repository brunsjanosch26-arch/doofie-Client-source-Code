#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# Steady Weapons
item replace entity @s weapon.mainhand with carrot_on_a_stick[custom_name="Bonesplitter",custom_model_data={floats:[888888]},custom_data={bonesplitter:1b},enchantments={"minecraft:knockback":1},enchantment_glint_override=false] 1
effect clear @s[] slowness