#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# Tag prevents current caster from being detected
tag @s add raycasting

# Anchor to the eyes and position with vector coordinates (Remove if not running from eyes of entity)
execute anchored eyes positioned ^ ^ ^.8 run function voa:bonesplitter/path
execute as @e[tag=shot] at @s run function voa:bonesplitter/dmg

# Remove the raycasting tag after raycast completion to prepare for the next player
tag @s remove raycasting
scoreboard players reset .distance tf_rc

#Muzzle Flash - And Sound
execute anchored eyes positioned ^ ^ ^ run particle minecraft:flame ^-.05 ^ ^1.1 
execute anchored eyes positioned ^ ^ ^ run particle smoke ^ ^.1 ^1.1 
execute anchored eyes positioned ^ ^ ^ run particle smoke ^ ^.3 ^1.1
execute anchored eyes positioned ^ ^ ^ run particle smoke ^ ^.5 ^1.1
playsound minecraft:musket.fire ambient @a[distance=..20] ~ ~ ~ 3

#data merge item- If they don't have Bone Armor on.
item replace entity @s[tag=!bone_reuse_helm,tag=!bone_reuse_chest,tag=!bone_reuse_legs,tag=!bone_reuse_boots] weapon.mainhand with carrot_on_a_stick[custom_name="Bonesplitter",custom_model_data={floats:[888888]},custom_data={bonesplitter:1b},enchantments={"minecraft:knockback":1},enchantment_glint_override=false] 1

#Bone Reuse Tags - If they do have Bone Armor on.
execute as @s[tag=bone_reuse_helm] at @s run tag @s add bone_retry_helm 
execute as @s[tag=bone_reuse_chest] at @s run tag @s add bone_retry_chest  
execute as @s[tag=bone_reuse_legs] at @s run tag @s add bone_retry_legs 
execute as @s[tag=bone_reuse_boots] at @s run tag @s add bone_retry_boots 

#RNG
scoreboard players set in math 0
scoreboard players set in1 math 7
function voa:natural_generation/random/range_lcg
#Random Chance - Success
execute as @s[tag=bone_retry_helm] if score out math matches 0 run playsound minecraft:block.amethyst_block.hit ambient @p[distance=..10] 
execute as @s[tag=bone_retry_helm] if score out math matches 0 run playsound minecraft:entity.firework_rocket.blast ambient @p[distance=..10] ~ ~ ~ 3
execute as @s[tag=bone_retry_helm] if score out math matches 0 run particle minecraft:totem_of_undying ~ ~ ~ 1.2 1.2 1.2 .1 100
execute as @s[tag=!bone_retry_helm] if score out math matches 0 run item replace entity @s[] weapon.mainhand with carrot_on_a_stick[custom_name="Bonesplitter",custom_model_data={floats:[888888]},custom_data={bonesplitter:1b},enchantments={"minecraft:knockback":1},enchantment_glint_override=false] 1

execute as @s[tag=bone_retry_chest] if score out math matches 1 run playsound minecraft:block.amethyst_block.hit ambient @p[distance=..10]
execute as @s[tag=bone_retry_chest] if score out math matches 1 run playsound minecraft:entity.firework_rocket.blast ambient @p[distance=..10] ~ ~ ~ 3
execute as @s[tag=bone_retry_chest] if score out math matches 1 run particle minecraft:totem_of_undying ~ ~ ~ 1.2 1.2 1.2 .1 100
execute as @s[tag=!bone_retry_chest] if score out math matches 1 run item replace entity @s[] weapon.mainhand with carrot_on_a_stick[custom_name="Bonesplitter",custom_model_data={floats:[888888]},custom_data={bonesplitter:1b},enchantments={"minecraft:knockback":1},enchantment_glint_override=false] 1

execute as @s[tag=bone_retry_legs] if score out math matches 2 run playsound minecraft:block.amethyst_block.hit ambient @p[distance=..10]
execute as @s[tag=bone_retry_legs] if score out math matches 2 run playsound minecraft:entity.firework_rocket.blast ambient @p[distance=..10] ~ ~ ~ 3
execute as @s[tag=bone_retry_legs] if score out math matches 2 run particle minecraft:totem_of_undying ~ ~ ~ 1.2 1.2 1.2 .1 100
execute as @s[tag=!bone_retry_legs] if score out math matches 2 run item replace entity @s[] weapon.mainhand with carrot_on_a_stick[custom_name="Bonesplitter",custom_model_data={floats:[888888]},custom_data={bonesplitter:1b},enchantments={"minecraft:knockback":1},enchantment_glint_override=false] 1

execute as @s[tag=bone_retry_boots] if score out math matches 3 run playsound minecraft:block.amethyst_block.hit ambient @p[distance=..10]
execute as @s[tag=bone_retry_boots] if score out math matches 3 run playsound minecraft:entity.firework_rocket.blast ambient @p[distance=..10] ~ ~ ~ 3
execute as @s[tag=bone_retry_boots] if score out math matches 3 run particle minecraft:totem_of_undying ~ ~ ~ 1.2 1.2 1.2 .1 100
execute as @s[tag=!bone_retry_boots] if score out math matches 3 run item replace entity @s[] weapon.mainhand with carrot_on_a_stick[custom_name="Bonesplitter",custom_model_data={floats:[888888]},custom_data={bonesplitter:1b},enchantments={"minecraft:knockback":1},enchantment_glint_override=false] 1

#Random Chance - Removal
execute as @s if score out math matches 4 run item replace entity @s[] weapon.mainhand with carrot_on_a_stick[custom_name="Bonesplitter",custom_model_data={floats:[888888]},custom_data={bonesplitter:1b},enchantments={"minecraft:knockback":1},enchantment_glint_override=false] 1
execute as @s if score out math matches 5 run item replace entity @s[] weapon.mainhand with carrot_on_a_stick[custom_name="Bonesplitter",custom_model_data={floats:[888888]},custom_data={bonesplitter:1b},enchantments={"minecraft:knockback":1},enchantment_glint_override=false] 1
execute as @s if score out math matches 6 run item replace entity @s[] weapon.mainhand with carrot_on_a_stick[custom_name="Bonesplitter",custom_model_data={floats:[888888]},custom_data={bonesplitter:1b},enchantments={"minecraft:knockback":1},enchantment_glint_override=false] 1
execute as @s if score out math matches 7 run item replace entity @s[] weapon.mainhand with carrot_on_a_stick[custom_name="Bonesplitter",custom_model_data={floats:[888888]},custom_data={bonesplitter:1b},enchantments={"minecraft:knockback":1},enchantment_glint_override=false] 1

#Tags - Bone Retry Removal
execute as @s at @s run tag @s remove bone_retry_helm 
execute as @s at @s run tag @s remove bone_retry_chest 
execute as @s at @s run tag @s remove bone_retry_legs 
execute as @s at @s run tag @s remove bone_retry_boots 

#Stops Lift Animation
scoreboard players set @p[scores={bonesptready=0..}] bonesptready 8
#tag @s add liftanimation






