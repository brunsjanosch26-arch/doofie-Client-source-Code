#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# Tag prevents current caster from being detected
item replace entity @s weapon.mainhand with carrot_on_a_stick[custom_name="Bonesplitter",custom_model_data={floats:[888889]},custom_data={bonesplitter:1b},enchantments={"minecraft:knockback":1},enchantment_glint_override=false] 1
effect give @s[] slowness 1 3 true

scoreboard players set @a[scores={bonespt_cool=0..}] bonespt_cool 8
