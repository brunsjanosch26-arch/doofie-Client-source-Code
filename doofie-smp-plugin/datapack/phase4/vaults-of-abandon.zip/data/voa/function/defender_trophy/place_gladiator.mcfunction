# AS AND AT POSITION of custom item frame 
setblock ~ ~ ~ minecraft:player_head


#Summons depending on direction - rotates model
execute as @s if entity @a[y_rotation=145..180,limit=1,sort=nearest,scores={trophy_delay=1..,trophy_place=1}] run tag @s add north
execute as @s if entity @a[y_rotation=-180..-145,limit=1,sort=nearest,scores={trophy_delay=1..,trophy_place=1}] run tag @s add north
execute as @s if entity @a[y_rotation=-144..-46,limit=1,sort=nearest,scores={trophy_delay=1..,trophy_place=1}] run tag @s add east
execute as @s if entity @a[y_rotation=-45..45,limit=1,sort=nearest,scores={trophy_delay=1..,trophy_place=1}] run tag @s add south
execute as @s if entity @a[y_rotation=46..144,limit=1,sort=nearest,scores={trophy_delay=1..,trophy_place=1}] run tag @s add west

execute as @s[tag=north] positioned ^ ^ ^0.5 align xyz run summon armor_stand ~ ~ ~ {Fire:9999999,Small:1b,Marker:1b,Invisible:1b,Tags:["trophy_gladiator"],equipment:{head:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":{floats:[787878]}}}}}
execute as @s[tag=east] positioned ^ ^ ^0.5 align xyz run summon armor_stand ~ ~ ~ {Fire:9999999,Small:1b,Marker:1b,Invisible:1b,Tags:["trophy_gladiator"],equipment:{head:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":{floats:[787879]}}}}}
execute as @s[tag=south] positioned ^ ^ ^0.5 align xyz run summon armor_stand ~ ~ ~ {Fire:9999999,Small:1b,Marker:1b,Invisible:1b,Tags:["trophy_gladiator"],equipment:{head:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":{floats:[787880]}}}}}
execute as @s[tag=west] positioned ^ ^ ^0.5 align xyz run summon armor_stand ~ ~ ~ {Fire:9999999,Small:1b,Marker:1b,Invisible:1b,Tags:["trophy_gladiator"],equipment:{head:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":{floats:[787881]}}}}}

kill @s




