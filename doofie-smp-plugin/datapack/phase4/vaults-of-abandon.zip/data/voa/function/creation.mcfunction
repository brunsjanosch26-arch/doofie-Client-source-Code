#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
recipe take @s voa:boneshot

advancement revoke @s only voa:boneshots_adv

give @s minecraft:stick 3

clear @s minecraft:knowledge_book 3

