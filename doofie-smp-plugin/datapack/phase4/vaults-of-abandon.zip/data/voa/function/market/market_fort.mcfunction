#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 1
function voa:natural_generation/random/range_lcg

#Spawn Room
#If 1 is selected, the following happens
execute if score out math matches 0 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -12, mode: "LOAD", posY: -10, sizeX: 25, posZ: -12, integrity: 1.0f, showair: 0b, name: "voa:mono_fort_1", id: "minecraft:structure_block", sizeY: 14, sizeZ: 25, showboundingbox: 1b}
execute if score out math matches 1 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -12, mode: "LOAD", posY: -10, sizeX: 25, posZ: -12, integrity: 1.0f, showair: 0b, name: "voa:mono_fort_2", id: "minecraft:structure_block", sizeY: 14, sizeZ: 25, showboundingbox: 1b}

#Always Spawns Redstone
setblock ~ ~1 ~ minecraft:redstone_block




tag @s add summoned