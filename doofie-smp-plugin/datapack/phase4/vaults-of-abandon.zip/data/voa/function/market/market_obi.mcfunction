#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 0
function voa:natural_generation/random/range_lcg

#Spawn Room
#If 1 is selected, the following happens
execute if score out math matches 0 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -23, mode: "LOAD", posY: -41, sizeX: 47, posZ: -23, integrity: 1.0f, showair: 0b, name: "voa:the_dark", id: "minecraft:structure_block", sizeY: 40, sizeZ: 47, showboundingbox: 1b}
execute if score out math matches 0 run setblock ~ ~44 ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -23, mode: "LOAD", posY: 1, sizeX: 47, posZ: -23, integrity: 1.0f, showair: 0b, name: "voa:moni_top", id: "minecraft:structure_block", sizeY: 47, sizeZ: 47, showboundingbox: 1b}
#execute if score out math matches 0 run setblock ~ ~-1 ~ minecraft:structure_block{metadata: "", mirror: "NONE", components: {}, ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: 20, mode: "LOAD", posY: -40, sizeX: 28, posZ: -23, integrity: 1.0f, showair: 0b, name: "voa:the_dark_east", id: "minecraft:structure_block", strict: 0b, sizeY: 41, sizeZ: 47, showboundingbox: 1b}
#execute if score out math matches 0 run setblock ~ ~-3 ~ minecraft:structure_block{metadata: "", mirror: "NONE", components: {}, ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -47, mode: "LOAD", posY: -38, sizeX: 28, posZ: -23, integrity: 1.0f, showair: 0b, name: "voa:the_dark_west",id: "minecraft:structure_block", strict: 0b, sizeY: 41, sizeZ: 47, showboundingbox: 1b}



##Always Spawns Redstone
setblock ~ ~-2 ~ minecraft:redstone_block
setblock ~ ~-4 ~ minecraft:redstone_block
setblock ~ ~1 ~ minecraft:redstone_block
setblock ~ ~45 ~ minecraft:redstone_block

##replace with obsidian
setblock ~ ~-4 ~ minecraft:obsidian
setblock ~ ~-3 ~ minecraft:obsidian
setblock ~ ~-2 ~ minecraft:obsidian
setblock ~ ~-1 ~ minecraft:obsidian
setblock ~ ~ ~ minecraft:obsidian
setblock ~ ~1 ~ minecraft:obsidian
setblock ~ ~2 ~ minecraft:obsidian
setblock ~ ~3 ~ minecraft:obsidian
setblock ~ ~4 ~ minecraft:obsidian
setblock ~ ~44 ~ minecraft:obsidian
setblock ~ ~45 ~ minecraft:obsidian

tag @s add summoned