#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks


#Spawn Room
#If 1 is selected, the following happens

##replace with obsidian
setblock ~ ~ ~ minecraft:obsidian
setblock ~ ~1 ~ minecraft:obsidian
setblock ~ ~2 ~ minecraft:obsidian
setblock ~ ~3 ~ minecraft:obsidian
setblock ~ ~4 ~ minecraft:obsidian
setblock ~ ~44 ~ minecraft:obsidian
setblock ~ ~45 ~ minecraft:obsidian

tag @s add obisidan