#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# Tag prevents current caster from being detected
tag @s add raycasting

# Anchor to the eyes and position with vector coordinates (Remove if not running from eyes of entity)
execute anchored eyes positioned ^ ^ ^.8 run function voa:staff_lucky/path

# Remove the raycasting tag after raycast completion to prepare for the next player
tag @s remove raycasting
scoreboard players reset .distance tf_rc

#Particle And Sound
playsound minecraft:entity.chicken.egg ambient @a[distance=..12]

#Staff Charge - #data merge item
item replace entity @s[tag=!tome_reuse_chest_dia,tag=!tome_reuse_helm,tag=!tome_reuse_chest,tag=!tome_reuse_legs,tag=!tome_reuse_boots] weapon.mainhand with carrot_on_a_stick[custom_name='"Staff: Chicken Claw (7 Charges)"',custom_model_data={floats:[333333]},custom_data={staffl7:1b}] 1

#Tome Reuse Tags - If they do have Tome Armor on.
execute as @s[tag=tome_reuse_helm] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_chest] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_chest_dia] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_legs] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_boots] at @s run tag @s add tome_retry 
#RNG
scoreboard players set in math 0
scoreboard players set in1 math 2
function voa:natural_generation/random/range_lcg
#Random Chance - Removal
execute as @s[tag=tome_retry] if score out math matches 0 run playsound minecraft:willowbee.mob.hurt player @a ~ ~ ~ 1
execute as @s[tag=tome_retry] if score out math matches 0 run particle minecraft:happy_villager ~ ~ ~ 1 1 1 .1 100
execute as @s[tag=tome_retry] if score out math matches 1 run item replace entity @s weapon.mainhand with carrot_on_a_stick[custom_name='"Staff: Chicken Claw (7 Charges)"',custom_model_data={floats:[333333]},custom_data={staffl7:1b}] 1
execute as @s[tag=tome_retry] if score out math matches 2 run item replace entity @s weapon.mainhand with carrot_on_a_stick[custom_name='"Staff: Chicken Claw (7 Charges)"',custom_model_data={floats:[333333]},custom_data={staffl7:1b}] 1

#Tags - Tome Retry Removal
execute as @s at @s run tag @s remove tome_retry 

#Sets Cooldown to reduce spam
scoreboard players set @s[scores={staff_l_cool=0..}] staff_l_cool 32



