#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#item replace entity @s weapon.mainhand with carrot_on_a_stick[custom_name='{"text":"Bonesket"}',custom_model_data=977779,custom_data={bonesket:"1b"},enchantments={levels:{"minecraft:knockback":1,"minecraft:sharpness":3}},enchantment_glint_override=false] 1

#execute anchored eyes positioned ^ ^ ^ run particle dust{color:[0.95,0.13,0.13],scale:2} ^-.01 ^ ^2
#execute anchored eyes positioned ^ ^ ^ run particle dust{color:[0.83,0.07,0.07],scale:1} ^-.01 ^ ^2 0.25 0.25 0.25 0 1
playsound minecraft:block.amethyst_block.resonate
#execute anchored eyes positioned ^ ^ ^ run particle minecraft:flame ^-.05 ^ ^1.1 
#execute anchored eyes positioned ^ ^ ^ run particle smoke ^ ^.1 ^1.1 

effect give @s[] slowness 1 5 true

#scoreboard players add @a[scores={boneskt_cool=0..}] boneskt_cool 8
