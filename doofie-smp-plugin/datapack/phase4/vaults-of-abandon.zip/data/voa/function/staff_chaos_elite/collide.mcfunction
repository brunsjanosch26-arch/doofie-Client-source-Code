## Called from tf_raycast:raycast upon any targets whose hitbox collides with the raycast

#### What you do to the target is up to you

# Detect Headshots/bodyshots/legshots
#execute positioned ~ ~0.35 ~ unless entity @s[dx=0] positioned ~ ~-0.3 ~ run say headshot
#
#execute positioned ~ ~0.35 ~ if entity @s[dx=0] positioned ~ ~-2.3 ~ if entity @s[dx=0] run say chest shot
#
#execute positioned ~ ~-1.95 ~ unless entity @s[dx=0] run say leg shot

#say I have been hit by a raycast. oof
particle explosion ~ ~ ~ 0 0 0 0 5

#teleport Command
execute at @s run summon armor_stand ~ ~ ~ {NoGravity:1b,Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["chaos_teleport"]}
teleport @a[tag=raycastingtele] @e[tag=chaos_teleport,limit=1,sort=nearest]
playsound minecraft:entity.enderman.teleport ambient @a[distance=..20] ~ ~ ~ 3
execute as @a[tag=raycastingtele] at @s run particle dust{color:[0.83,0.07,0.07],scale:1} ~ ~ ~ 2 1 2 0.05 200
execute as @e[tag=chaos_teleport] at @s run kill @s

#### Max out range to end the raycast
scoreboard players set .distance tf_rc 2500


