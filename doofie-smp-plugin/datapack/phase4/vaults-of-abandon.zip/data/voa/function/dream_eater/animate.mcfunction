#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#Test for broken code
#say hi

#Mob Sound/Sound Timer/Reset Sound so it happens again
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players add @s mob_demo_time 1
execute if entity @s[scores={mob_demo_time=2}] run playsound minecraft:block.grass.step hostile @a[distance=0..14] ~ ~ ~ 0.2 1
execute if entity @s[scores={mob_demo_time=2}] run particle minecraft:ash ~ ~ ~ 0 0 0 1 6 normal
execute if entity @s[scores={mob_demo_time=6}] run particle minecraft:ash ~ ~ ~ 0 0 0 1 6 normal
execute if entity @s[scores={mob_demo_time=8}] run scoreboard players set @s mob_demo_time 0


#Moving Animation
execute if entity @s[scores={animate=1}] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run data merge entity @e[limit=1,distance=0..2,type=minecraft:zombie,sort=nearest,tag=dream_eater] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[222001]}}}}}

#Resets Moving Animation
execute if entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players set @s animate 0
execute if entity @s[scores={animate=0}] run data merge entity @e[limit=1,distance=0..2,type=minecraft:zombie,sort=nearest,tag=dream_eater] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[222000]}}}}}

#Damage Sound
execute if entity @s[nbt={HurtTime:10s}] run playsound minecraft:item.trident.return hostile @a[distance=0..10]

#Detects if mob is moving
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players add @s animate 1 
