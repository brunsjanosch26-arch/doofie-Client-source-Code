#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 3
function voa:natural_generation/random/range_lcg

### THIS IS THE SPAWN COMMAND if I need to change the mob attributes this is where I will do it!!!
###  If matches 0 
execute if score out math matches 1 run summon zombie ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"voa:entities/abom_loot",PersistenceRequired:1b,Health:100f,Tags:["dream_eater","voa","cryptid"],CustomName:"Dream Eater",equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[222000]}}}},drop_chances:{head:0.000},active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:1800000000,show_particles:0b,show_icon:0b}],attributes:[{id:"minecraft:attack_damage",base:8},{id:"minecraft:max_health",base:100},{id:"minecraft:movement_speed",base:0.2}]}

### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
execute if score out math matches 1 run scoreboard players add @e[tag=dream_eater,type=minecraft:zombie,tag=!stats] atk_cool 0
execute if score out math matches 1 run scoreboard players add @e[tag=dream_eater,type=minecraft:zombie,tag=!stats] sound_cool 0
execute if score out math matches 1 run scoreboard players add @e[tag=dream_eater,type=minecraft:zombie,tag=!stats] titanhealth 0

execute if score out math matches 1 run tag @e[tag=dream_eater,type=minecraft:zombie,tag=!stats] add stats

#Kills Marker
tag @s add summoned
