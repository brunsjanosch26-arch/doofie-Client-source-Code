#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# Tag prevents current caster from being detected


#execute at @s run effect give @e[type=!area_effect_cloud,type=!experience_orb,type=!armor_stand,type=!item_frame,type=!player,type=!item,type=!arrow,type=!#voa:undead,distance=0..2.5,limit=1,sort=nearest] minecraft:instant_damage 1 1 true
execute at @s run effect give @e[type=!area_effect_cloud,type=!experience_orb,type=!armor_stand,type=!item_frame,type=!player,type=!item,type=!arrow,distance=0..1.5,limit=1,sort=nearest] minecraft:slowness 5 1 true
execute at @s run effect give @e[type=!area_effect_cloud,type=!experience_orb,type=!armor_stand,type=!item_frame,type=!player,type=!item,type=!arrow,distance=0..1.5,limit=1,sort=nearest] minecraft:weakness 5 1 true
#execute at @s run effect give @e[type=!area_effect_cloud,type=!experience_orb,type=!armor_stand,type=!item_frame,type=!player,type=!item,type=!arrow,type=!#voa:living,distance=0..2.5,limit=1,sort=nearest] minecraft:instant_health 1 1 true

execute at @s run damage @s[] 28 minecraft:player_attack by @a[tag=raycasting,limit=1,sort=nearest]

tag @s remove shot_double
