#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks


##Removes Ammo from inventory
clear @s stick[minecraft:custom_data={boneshot:1b}] 2

# Steady Weapons
playsound minecraft:block.stone_button.click_on ambient @p[distance=..10]

item replace entity @s weapon.mainhand with carrot_on_a_stick[custom_name="Double-Bone-87 (Loaded - 2 Shots)",custom_model_data={floats:[888900]},custom_data={dboneloaded_2:1b}] 1

scoreboard players set @p[scores={bonedracking=0..}] bonedracking 18


effect clear @s[] slowness