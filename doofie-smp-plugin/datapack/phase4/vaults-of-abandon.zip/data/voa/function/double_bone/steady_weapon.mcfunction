#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# Steady Weapons
item replace entity @s weapon.mainhand with carrot_on_a_stick[custom_name="Double-Bone-87",custom_model_data={floats:[888900]},custom_data={dbone:1b}] 1

effect clear @s[] slowness