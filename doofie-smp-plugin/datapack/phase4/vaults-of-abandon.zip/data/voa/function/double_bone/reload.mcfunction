#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# Tag prevents current caster from being detected
item replace entity @s weapon.mainhand with carrot_on_a_stick[custom_name="Double-Bone-87",custom_model_data={floats:[888901]},custom_data={dbone:1b}] 1

effect give @s[] slowness 1 3 true

scoreboard players set @a[scores={d_bone_cool=0..}] d_bone_cool 8
