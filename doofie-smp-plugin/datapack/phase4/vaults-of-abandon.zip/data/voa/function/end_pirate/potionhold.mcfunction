#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Giving the custom attack
data merge entity @s[] {equipment:{mainhand:{id:"minecraft:diamond_sword",count:1},offhand:{id:"minecraft:air",count:1}},drop_chances:{mainhand:0.000,offhand:0.000}}

#Selects Potion
execute as @s[tag=instant] at @s run summon splash_potion ~ ~ ~ {Item:{id:"minecraft:splash_potion",count:1,components:{"minecraft:potion_contents":{custom_effects:[{id:"minecraft:instant_damage",amplifier:2,duration:1}]}}}}
execute as @s[tag=instant_II] at @s run summon splash_potion ~ ~ ~ {Item:{id:"minecraft:splash_potion",count:1,components:{"minecraft:potion_contents":{custom_effects:[{id:"minecraft:instant_damage",amplifier:2,duration:1},{id:"minecraft:poison",amplifier:2,duration:200}]}}}}
execute as @s[tag=instant_III] at @s run summon splash_potion ~ ~ ~ {Item:{id:"minecraft:splash_potion",count:1,components:{"minecraft:potion_contents":{custom_effects:[{id:"minecraft:instant_damage",amplifier:2,duration:1},{id:"minecraft:wither",amplifier:3,duration:200}]}}}}


tag @s remove potionhold
