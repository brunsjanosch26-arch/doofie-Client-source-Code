#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

effect give @s[] minecraft:levitation 1 1

##Particle And Sound
particle minecraft:cloud ~ ~ ~ .5 0 .5 .2 20
playsound minecraft:item.bone_meal.use ambient @a[]

#Sets Cooldown to reduce spam
scoreboard players add @s[scores={staff_c_cool=0..}] staff_c_cool 1

tag @s add hover


