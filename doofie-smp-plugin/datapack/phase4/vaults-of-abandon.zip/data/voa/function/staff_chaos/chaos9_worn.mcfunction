#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Staff Charge - #data merge item
item replace entity @s[tag=!tome_reuse_chest_dia,tag=!tome_reuse_helm,tag=!tome_reuse_chest,tag=!tome_reuse_legs,tag=!tome_reuse_boots] weapon.mainhand with carrot_on_a_stick[custom_name='"Staff: Levitate (8 Charges)"',custom_model_data={floats:[313131]},custom_data={staffc8:1b}] 1

#Tome Reuse Tags - If they do have Tome Armor on.
execute as @s[tag=tome_reuse_helm] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_chest] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_chest_dia] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_legs] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_boots] at @s run tag @s add tome_retry 
#RNG
scoreboard players set in math 0
scoreboard players set in1 math 2
function voa:natural_generation/random/range_lcg
#Random Chance - Removal
execute as @s[tag=tome_retry] if score out math matches 0 run playsound minecraft:willowbee.mob.hurt player @a ~ ~ ~ 1
execute as @s[tag=tome_retry] if score out math matches 0 run particle minecraft:happy_villager ~ ~ ~ 1 1 1 .1 100
execute as @s[tag=tome_retry] if score out math matches 1 run item replace entity @s weapon.mainhand with carrot_on_a_stick[custom_name='"Staff: Levitate (8 Charges)"',custom_model_data={floats:[313131]},custom_data={staffc8:1b}] 1
execute as @s[tag=tome_retry] if score out math matches 2 run item replace entity @s weapon.mainhand with carrot_on_a_stick[custom_name='"Staff: Levitate (8 Charges)"',custom_model_data={floats:[313131]},custom_data={staffc8:1b}] 1

#Tags - Tome Retry Removal
execute as @s at @s run tag @s remove tome_retry 

#Sets Cooldown to reduce spam
scoreboard players set @s[scores={staff_c_cool=45..}] staff_c_cool 0


