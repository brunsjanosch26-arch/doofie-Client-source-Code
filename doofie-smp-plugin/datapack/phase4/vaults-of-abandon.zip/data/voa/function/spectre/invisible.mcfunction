#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks


#Makes Armor Stand Invisible - SO players don't see them
execute if entity @s[tag=spawnspectre,tag=!summoned,tag=!invisible] run data merge entity @e[type=armor_stand,tag=spawnspectre,tag=!summoned,tag=!invisible,limit=1] {Invisible:1b}

tag @s add invisible

#B-E-A-G-L-E-B-L-O-C-K-S
