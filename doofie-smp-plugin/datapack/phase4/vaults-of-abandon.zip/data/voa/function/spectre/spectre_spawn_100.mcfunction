#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks


### Execute as at Husk
### Always Spawns - Armor Stand Based Spawner

### THIS IS THE SPAWN COMMAND if I need to change the mob attributes this is where I will do it!!!
summon husk ~ ~ ~ {Silent:1b,DeathLootTable:"voa:entities/spectre_loot",PersistenceRequired:1b,Health:20f,CanBreakDoors:1b,DrownedConversionTime:99999,Tags:["spectre","voa"],CustomName:"Specter",equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[931000]}}}},drop_chances:{head:0.000},active_effects:[{id:"minecraft:jump_boost",amplifier:1,duration:99999,show_particles:0b},{id:"minecraft:invisibility",amplifier:1,duration:999999,show_particles:0b}],attributes:[{id:"minecraft:attack_damage",base:6},{id:"minecraft:follow_range",base:40},{id:"minecraft:max_health",base:20},{id:"minecraft:movement_speed",base:0.15}]}
#### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
scoreboard players add @e[tag=spectre,type=minecraft:husk,sort=nearest,limit=1] sound_cool 0

#Execute for Spectral-Schimitar
tag @e[tag=spectre,type=minecraft:husk] add ghost

##Makes the Mob burn possible for every Spectre
scoreboard players add @e[tag=spectre,type=minecraft:husk] timeofday 0
scoreboard players add @e[tag=spectre,type=minecraft:husk] skychecker 0

#Kills Marker
tag @s add summoned