#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# Tag prevents current caster from being detected
tag @s add raycasting

#Bone Reuse Tags - If they do have Bone Armor on.
execute as @s[tag=bone_reuse_helm] at @s run tag @s add bone_retry_helm 
execute as @s[tag=bone_reuse_chest] at @s run tag @s add bone_retry_chest  
execute as @s[tag=bone_reuse_legs] at @s run tag @s add bone_retry_legs 
execute as @s[tag=bone_reuse_boots] at @s run tag @s add bone_retry_boots 


#RNG - For Power Shot
scoreboard players set in math 0
scoreboard players set in1 math 7
function voa:natural_generation/random/range_lcg
#Random Chance - Success
execute as @s[tag=bone_retry_helm] if score out math matches 0 run tag @s add bone_shock
execute as @s[tag=bone_retry_helm] if score out math matches 0 run particle minecraft:totem_of_undying ~ ~ ~ 1.2 1.2 1.2 .1 100
execute as @s[tag=bone_retry_chest] if score out math matches 1 run tag @s add bone_shock
execute as @s[tag=bone_retry_chest] if score out math matches 1 run particle minecraft:totem_of_undying ~ ~ ~ 1.2 1.2 1.2 .1 100
execute as @s[tag=bone_retry_legs] if score out math matches 2 run tag @s add bone_shock
execute as @s[tag=bone_retry_legs] if score out math matches 2 run particle minecraft:totem_of_undying ~ ~ ~ 1.2 1.2 1.2 .1 100
execute as @s[tag=bone_retry_boots] if score out math matches 3 run tag @s add bone_shock
execute as @s[tag=bone_retry_boots] if score out math matches 3 run particle minecraft:totem_of_undying ~ ~ ~ 1.2 1.2 1.2 .1 100


# Anchor to the eyes and position with vector coordinates (Remove if not running from eyes of entity)
execute as @s[tag=!bone_shock] at @s anchored eyes positioned ^ ^ ^ run function voa:bonelock/path
execute as @s[tag=bone_shock] at @s anchored eyes positioned ^ ^ ^ run function voa:bonelock/path_shock
execute as @s[tag=bone_shock] at @s anchored eyes positioned ^ ^ ^0.7 run particle soul_fire_flame ~ ~ ~ 0 0 0 0 5


# Remove the raycasting tag after raycast completion to prepare fo the next player
tag @s remove raycasting
scoreboard players reset .distance tf_rc

#Plays Sound
execute as @s[tag=!bone_shock] at @s run playsound minecraft:flintlock.fire ambient @a[distance=..20] ~ ~ ~ 3
execute as @s[tag=bone_shock] at @s run playsound minecraft:entity.generic.explode ambient @a[distance=..20] ~ ~ ~ 3

#Removes Ammo from inventory - IF NOT WEARING ARMOR
clear @s[tag=!bone_shock] stick[minecraft:custom_data={boneshot:1b}] 1


#Random Chance - #Removes Ammo from inventory - ON FAIL
execute as @s[tag=bone_shock] if score out math matches 4 run clear @s stick[minecraft:custom_data={boneshot:1b}] 1
execute as @s[tag=bone_shock] if score out math matches 4 run playsound minecraft:flintlock.fire ambient @a[distance=..20] ~ ~ ~ 3
execute as @s[tag=bone_shock] if score out math matches 5 run clear @s stick[minecraft:custom_data={boneshot:1b}] 1
execute as @s[tag=bone_shock] if score out math matches 5 run playsound minecraft:flintlock.fire ambient @a[distance=..20] ~ ~ ~ 3
execute as @s[tag=bone_shock] if score out math matches 6 run clear @s stick[minecraft:custom_data={boneshot:1b}] 1
execute as @s[tag=bone_shock] if score out math matches 6 run playsound minecraft:flintlock.fire ambient @a[distance=..20] ~ ~ ~ 3
execute as @s[tag=bone_shock] if score out math matches 7 run clear @s stick[minecraft:custom_data={boneshot:1b}] 1
execute as @s[tag=bone_shock] if score out math matches 7 run playsound minecraft:flintlock.fire ambient @a[distance=..20] ~ ~ ~ 3


#Tags - Bone Retry Removal
execute as @s at @s run tag @s remove bone_shock 
execute as @s at @s run tag @s remove bone_retry_helm 
execute as @s at @s run tag @s remove bone_retry_chest 
execute as @s at @s run tag @s remove bone_retry_legs 
execute as @s at @s run tag @s remove bone_retry_boots 

#Sets Cooldown between shots - or rate of fire.
scoreboard players set @s bonelk_cool 12





