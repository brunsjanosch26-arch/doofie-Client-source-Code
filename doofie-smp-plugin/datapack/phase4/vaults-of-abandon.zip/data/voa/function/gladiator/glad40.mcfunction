#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Runs once

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 3
function voa:natural_generation/random/range_lcg


#Spawns Nether Demon
execute if score out math matches 0 run execute as @s run effect give @a[distance=..24] minecraft:slowness 30 3
execute if score out math matches 0 run execute as @s run effect give @a[distance=..24] minecraft:blindness 30 0
execute if score out math matches 1 run execute as @s run effect give @a[distance=..24] minecraft:infested 30 5
execute if score out math matches 1 run execute as @s run effect give @a[distance=..24] minecraft:poison 30 2
execute if score out math matches 2 run execute as @s run effect give @a[distance=..24] minecraft:instant_damage 1 1
execute if score out math matches 2 run execute as @s run effect give @e[distance=..24] minecraft:oozing 45 1
execute if score out math matches 2 run execute as @s run effect give @e[distance=..24] minecraft:wind_charged 45 1
execute if score out math matches 2 run execute as @s run effect give @e[distance=..24] minecraft:weaving 45 1
execute if score out math matches 3 run execute as @s run effect give @a[distance=..24] minecraft:hunger 30 5
execute if score out math matches 3 run execute as @s run effect give @a[distance=..24] minecraft:wither 30 5


tag @s add gladhealth40
execute as @s run playsound minecraft:item.goat_horn.sound.6 ambient @a ~ ~ ~ 3
execute as @s run particle minecraft:angry_villager ~ ~ ~ 0.5 0.5 0.5 .1 10


