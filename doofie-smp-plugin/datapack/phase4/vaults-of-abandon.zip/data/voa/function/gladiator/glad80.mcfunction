#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Runs once

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 2
function voa:natural_generation/random/range_lcg


#Spawns Nether Demon
execute if score out math matches 0 run execute as @s run effect give @s minecraft:strength 60 1
execute if score out math matches 1 run execute as @s run effect give @s minecraft:resistance 60 1
execute if score out math matches 2 run execute as @s run effect give @s minecraft:speed 60 1
execute if score out math matches 2 run execute as @s run effect clear @s minecraft:slowness 



tag @s add gladhealth80
execute as @s run playsound minecraft:item.goat_horn.sound.1 ambient @a ~ ~ ~ 3
execute as @s run particle minecraft:angry_villager ~ ~ ~ 0.5 0.5 0.5 .1 10


