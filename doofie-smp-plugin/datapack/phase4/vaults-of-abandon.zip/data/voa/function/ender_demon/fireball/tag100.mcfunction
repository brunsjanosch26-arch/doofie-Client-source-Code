#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Runs once?
tag @s add fireball100
tag @s add fireballready

