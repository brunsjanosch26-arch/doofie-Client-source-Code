#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks


summon zombified_piglin ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"voa:entities/end/ender_demon",PersistenceRequired:1b,Health:800f,Tags:["ender_demon","boss","voa","cryptid"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["ender_demon_body"],equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[670500]}}}}}],CustomName:"Greedox - Ender Demon",equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[670501]}}}},drop_chances:{head:0.000},active_effects:[{id:"minecraft:fire_resistance",amplifier:1,duration:999999,show_particles:0b},{id:"minecraft:invisibility",amplifier:1,duration:999999,show_particles:0b}],attributes:[{id:"minecraft:attack_damage",base:40},{id:"minecraft:attack_knockback",base:12},{id:"minecraft:follow_range",base:40},{id:"minecraft:knockback_resistance",base:0.9},{id:"minecraft:max_health",base:800},{id:"minecraft:movement_speed",base:0.21}]}

### INITALIZES CUSTOM ATTACK VARIA5LE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
execute as @e[tag=ender_demon,type=minecraft:zombified_piglin,tag=!stats] at @s run scoreboard players add @e[tag=ender_demon,type=minecraft:zombified_piglin,tag=!stats] atk_cool 140 
execute as @e[tag=ender_demon,type=minecraft:zombified_piglin,tag=!stats] at @s run scoreboard players add @e[tag=ender_demon,type=minecraft:zombified_piglin,tag=!stats] sound_cool 0
execute as @e[tag=ender_demon,type=minecraft:zombified_piglin,tag=!stats] at @s run scoreboard players add @e[tag=ender_demon,type=minecraft:zombified_piglin,tag=!stats] atk_dash_cool 0 
execute as @e[tag=ender_demon,type=minecraft:zombified_piglin,tag=!stats] at @s run scoreboard players add @e[tag=ender_demon,type=minecraft:zombified_piglin,tag=!stats] atk_snare_cool 0 
execute as @e[tag=ender_demon,type=minecraft:zombified_piglin,tag=!stats] at @s run tag @e[tag=ender_demon,type=minecraft:zombified_piglin,tag=!stats] add stats
execute as @e[tag=ender_demon,type=minecraft:zombified_piglin] at @s run tag @e[type=minecraft:armor_stand,tag=wakeup,distance=..80] add woken
execute as @e[tag=ender_demon,type=minecraft:zombified_piglin] at @s run tag @e[type=minecraft:armor_stand,tag=wakeup_dropdown,distance=..80] add woken

#Angry At
execute as @e[type=minecraft:zombified_piglin,tag=ender_demon,limit=1,sort=nearest] at @s run data modify entity @e[type=minecraft:zombified_piglin,tag=ender_demon,limit=1,sort=nearest] angryat set from entity @p[distance=..40] UUID

#Kills Marker
tag @s add summoned
