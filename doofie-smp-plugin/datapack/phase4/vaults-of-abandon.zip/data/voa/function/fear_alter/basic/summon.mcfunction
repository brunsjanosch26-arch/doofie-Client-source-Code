#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#Plays Sound adds Heart Effect
execute at @s run playsound minecraft:item.goat_horn.sound.2 ambient @a[] ~ ~ ~ 2
execute as @e[type=minecraft:item_frame,tag=fear,tag=placed,sort=nearest,limit=1] at @s run particle minecraft:heart ~ ~ ~ 0 0 0 0.50 40
#Adds Tag so that the function is only ran once.
execute as @e[type=minecraft:item_frame,tag=fear,tag=placed,sort=nearest,limit=1] at @s run tag @s add used
#Starts Trial
execute as @e[type=minecraft:item_frame,tag=fear,tag=placed,limit=1,sort=nearest] at @s run setblock ~ ~ ~ air replace
execute as @s run tag @s add active_trial
execute as @s at @s run function voa:fear_alter/basic/location
execute as @s at @s run function voa:fear_alter/basic/location
execute as @s at @s run function voa:fear_alter/basic/location
setblock ~0.5 ~1 ~8.5 air replace
setblock ~0.5 ~1 ~14.5 air replace
setblock ~3.5 ~1 ~11.5 air replace
setblock ~-2.5 ~1 ~11.5 air replace

execute as @s at @s run scoreboard players set @s[] end_trials_score 0
execute as @s at @s run scoreboard players set @s[] end_trials_chaos 600


#KILL ITEM FRAME
kill @e[type=minecraft:item_frame,tag=fear,tag=placed,tag=used,limit=1,sort=nearest]