#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
# AS AND AT POSITION of custom item frame 
setblock ~ ~ ~ minecraft:bedrock replace

summon armor_stand ~-.5 ~ ~-.5 {NoGravity:1b,Silent:1b,Invulnerable:1b,Fire:9999999,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["fear_alter_elite"],equipment:{head:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":{floats:[1700001]}}}}}


kill @s

