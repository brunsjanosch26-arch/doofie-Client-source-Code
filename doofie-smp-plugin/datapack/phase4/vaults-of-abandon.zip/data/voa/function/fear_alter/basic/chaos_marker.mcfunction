#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks


#Result Run
execute as @p at @s run summon armor_stand ~ ~1 ~ {Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,Tags:["chaos_marker"]}

execute as @e[tag=chaos_marker] at @s run scoreboard players set @s[] end_trials_chaos_countdown 40

execute as @s at @s run scoreboard players set @s[] end_trials_chaos 600
