#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
execute as @s at @s run scoreboard players set @s[] end_trials_chaos 300
execute as @s at @s run scoreboard players set @s[] end_trials_score 0
tag @s remove active_trial