#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
setblock ~0.5 ~1 ~8.5 chest{LootTable:"voa:blocks/end_medium"} replace
setblock ~0.5 ~1 ~14.5 chest{LootTable:"voa:blocks/end_medium"} replace
setblock ~3.5 ~1 ~11.5 chest{LootTable:"voa:blocks/end_medium"} replace
setblock ~-2.5 ~1 ~11.5 chest{LootTable:"voa:blocks/end_medium"} replace
playsound minecraft:ui.toast.challenge_complete ambient @a[] ~ ~ ~ 2
execute as @s at @s run scoreboard players set @s[] end_trials_loot_countdown 200
tag @s remove active_trial