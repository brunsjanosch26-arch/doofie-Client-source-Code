#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 3
function voa:natural_generation/random/range_lcg

#Result Run
#Garrison
execute if score out math matches 0 run function voa:fear_alter/basic/east
execute if score out math matches 1 run function voa:fear_alter/basic/west
execute if score out math matches 2 run function voa:fear_alter/basic/south
execute if score out math matches 3 run function voa:fear_alter/basic/north


#Particle
execute if score out math matches 0 run particle minecraft:dust_plume ~ ~ ~ 0.1 0.5 0.1 .1 30
execute if score out math matches 1 run particle minecraft:dust_plume ~ ~ ~ 0.1 0.5 0.1 .1 30
execute if score out math matches 2 run particle minecraft:dust_plume ~ ~ ~ 0.1 0.5 0.1 .1 30
execute if score out math matches 3 run particle minecraft:dust_plume ~ ~ ~ 0.1 0.5 0.1 .1 30



