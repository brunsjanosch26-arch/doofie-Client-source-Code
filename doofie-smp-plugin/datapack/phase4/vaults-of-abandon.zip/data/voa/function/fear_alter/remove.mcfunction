#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#SUMMON DROPS
summon item ~ ~0.5 ~ {Item:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_name":"Alter of Fear","minecraft:custom_model_data":{floats:[1700000]},"minecraft:entity_data":{id:"minecraft:item_frame",Item:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":{floats:[1700000]}}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["fear_alter"]}}}}

#KILL BLOCK DROP - PREVENTS Silk Touch!
kill @e[type=item,nbt={Item:{id:"minecraft:bedrock"}},distance=0..2,sort=nearest,limit=1]


#KILL ITEM FRAME
kill @s