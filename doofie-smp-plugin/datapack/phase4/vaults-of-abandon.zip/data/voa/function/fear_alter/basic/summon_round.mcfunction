#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#Plays Sound adds Heart Effect
execute at @s run playsound minecraft:item.goat_horn.sound.0 ambient @a[] ~ ~ ~ 2
execute as @s at @s run function voa:fear_alter/basic/location
execute as @s at @s run function voa:fear_alter/basic/location
execute as @s at @s run function voa:fear_alter/basic/location
execute as @s at @s run summon armor_stand ~0.5 ~ ~3.5 {Marker:1b,Invisible:1b,Tags:["legendaryspawntrial"]}
execute as @s at @s run scoreboard players add @s[] end_trials_score 3


