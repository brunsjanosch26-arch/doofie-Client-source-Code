#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
playsound minecraft:entity.player.levelup ambient @a[] ~ ~ ~ 2
loot spawn ~0.5 ~1 ~0.5 loot voa:blocks/trials/armor
particle minecraft:happy_villager ~0.5 ~1 ~0.5 1 1 1 0.1 20
