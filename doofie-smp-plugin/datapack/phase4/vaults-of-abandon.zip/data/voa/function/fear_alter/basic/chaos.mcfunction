#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 1
function voa:natural_generation/random/range_lcg

#Result Run
#Garrison
execute if score out math matches 0 run summon breeze ~ ~ ~


#Privateer
execute if score out math matches 1 run summon blaze ~ ~ ~


playsound minecraft:item.ominous_bottle.dispose ambient @a[] ~ ~ ~ 2

kill @s