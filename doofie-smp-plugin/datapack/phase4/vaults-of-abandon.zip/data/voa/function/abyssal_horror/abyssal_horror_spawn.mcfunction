#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

### THIS IS THE SPAWN COMMAND if I need to change the mob attributes this is where I will do it!!!
###  If matches 0 
execute if score abyssalhorror_count cm_abyssalhorror matches 0 run summon zombie ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"voa:entities/abyssal_loot",Health:50f,IsBaby:0b,CanBreakDoors:1b,DrownedConversionTime:9999999,Tags:["abyssal_horror","voa","cryptid"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["abyssal_horror_body"],equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[I;666666]}}}}}],CustomName:"Abyssal Horror",equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[666669]}}}},drop_chances:{head:0.000},active_effects:[{id:"minecraft:invisibility",amplifier:1,duration:999999,show_particles:0b}],attributes:[{id:"minecraft:attack_damage",base:8},{id:"minecraft:attack_knockback",base:3},{id:"minecraft:follow_range",base:24},{id:"minecraft:knockback_resistance",base:0.5},{id:"minecraft:max_health",base:50},{id:"minecraft:movement_speed",base:0.35}]}
execute if score abyssalhorror_count cm_abyssalhorror matches 0 run tp @s ~ ~-256 ~

### Add tag not_messenger to ensure the Zombie is not scanned again
tag @s add not_abyssal_horror
### Increment count
scoreboard players add abyssalhorror_count cm_abyssalhorror 1
### Reset Count
execute if score abyssalhorror_count cm_abyssalhorror matches 16 run scoreboard players set abyssalhorror_count cm_abyssalhorror 0

### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
scoreboard players add @e[tag=abyssal_horror,type=minecraft:zombie] atk_cool 0
scoreboard players add @e[tag=abyssal_horror,type=minecraft:zombie] sound_cool 0