#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Giving the custom attack
effect give @a[distance=0..4] slowness 5 2