#Damage & Healing
effect give @e[type=#voa:undead,distance=..15] minecraft:instant_health 1 4
effect give @e[type=#voa:friendly,distance=..15] minecraft:instant_health 1 4

#Partilce
particle minecraft:soul_fire_flame ~ ~ ~ 0 0 0 .1 300
particle minecraft:soul_fire_flame ~ ~ ~ 0 0 0 .5 300
particle minecraft:soul_fire_flame ~ ~ ~ 0 0 0 .7 500
particle minecraft:soul_fire_flame ~ ~ ~ 0 0 0 1 500
playsound minecraft:entity.lightning_bolt.thunder player @a ~ ~ ~ 3