#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 5
function voa:natural_generation/random/range_lcg

#Formation One - Small & Medium
execute if score out math matches 0 run summon armor_stand ~ ~ ~ {Tags:["boat_medium"]}
execute if score out math matches 0 run summon armor_stand ~30 ~15 ~25 {Tags:["boat_medium"]}
execute if score out math matches 0 run summon armor_stand ~-40 ~-10 ~-30 {Tags:["boat_medium"]}
execute if score out math matches 0 run summon armor_stand ~60 ~15 ~-11 {Tags:["boat_medium"]}
execute if score out math matches 0 run summon armor_stand ~30 ~-10 ~-25 {Tags:["boat_little"]}
execute if score out math matches 0 run summon armor_stand ~3 ~5 ~-40 {Tags:["boat_little"]}
execute if score out math matches 0 run summon armor_stand ~-40 ~ ~39 {Tags:["boat_little"]}
execute if score out math matches 0 run summon armor_stand ~60 ~20 ~60 {Tags:["boat_little"]}
execute if score out math matches 0 run summon armor_stand ~-15 ~-25 ~25 {Tags:["boat_little"]}
execute if score out math matches 0 run summon armor_stand ~-55 ~5 ~10 {Tags:["boat_little"]}
execute if score out math matches 0 run summon armor_stand ~-13 ~10 ~35 {Tags:["ghast_post"]}
execute if score out math matches 0 run summon armor_stand ~-30 ~15 ~-50 {Tags:["ghast_post"]}


#Formation Two - Small & Medium
execute if score out math matches 1 run summon armor_stand ~ ~ ~ {Tags:["boat_medium"]}
execute if score out math matches 1 run summon armor_stand ~-27 ~-15 ~-27 {Tags:["boat_medium"]}
execute if score out math matches 1 run summon armor_stand ~25 ~7 ~27 {Tags:["boat_medium"]}
execute if score out math matches 1 run summon armor_stand ~-63 ~12 ~-30 {Tags:["boat_medium"]}
execute if score out math matches 1 run summon armor_stand ~70 ~10 ~55 {Tags:["boat_little"]}
execute if score out math matches 1 run summon armor_stand ~10 ~18 ~-37 {Tags:["boat_little"]}
execute if score out math matches 1 run summon armor_stand ~40 ~15 ~-8 {Tags:["boat_little"]}
execute if score out math matches 1 run summon armor_stand ~-60 ~4 ~7 {Tags:["boat_little"]}
execute if score out math matches 1 run summon armor_stand ~-38 ~4 ~46 {Tags:["boat_little"]}
execute if score out math matches 1 run summon armor_stand ~-27 ~27 ~-51 {Tags:["boat_little"]}
execute if score out math matches 1 run summon armor_stand ~-5 ~15 ~50 {Tags:["ghast_post"]}
execute if score out math matches 1 run summon armor_stand ~-30 ~30 ~-30 {Tags:["ghast_post"]}

##Formation Three - Small & Medium
execute if score out math matches 2 run summon armor_stand ~ ~ ~ {Tags:["boat_medium"]}
execute if score out math matches 2 run summon armor_stand ~-17 ~-31 ~10 {Tags:["boat_medium"]}
execute if score out math matches 2 run summon armor_stand ~13 ~24 ~20 {Tags:["boat_medium"]}
execute if score out math matches 2 run summon armor_stand ~37 ~-22 ~-20 {Tags:["boat_medium"]}
execute if score out math matches 2 run summon armor_stand ~-19 ~-25 ~-22 {Tags:["boat_little"]}
execute if score out math matches 2 run summon armor_stand ~-54 ~-5 ~-10 {Tags:["boat_little"]}
execute if score out math matches 2 run summon armor_stand ~-25 ~10 ~32 {Tags:["boat_little"]}
execute if score out math matches 2 run summon armor_stand ~-9 ~35 ~-20 {Tags:["boat_little"]}
execute if score out math matches 2 run summon armor_stand ~23 ~14 ~-27 {Tags:["boat_little"]}
execute if score out math matches 2 run summon armor_stand ~-17 ~14 ~-43 {Tags:["boat_little"]}
execute if score out math matches 2 run summon armor_stand ~-54 ~-5 ~15 {Tags:["boat_little"]}
execute if score out math matches 2 run summon armor_stand ~-60 ~20 ~-45 {Tags:["ghast_post"]}
execute if score out math matches 2 run summon armor_stand ~-60 ~20 ~45 {Tags:["ghast_post"]}
execute if score out math matches 2 run summon armor_stand ~55 ~20 ~ {Tags:["ghast_post"]}

##Formation Four - Small & Medium & Large
execute if score out math matches 3 run summon armor_stand ~ ~ ~ {Tags:["boat_large"]}
execute if score out math matches 3 run summon armor_stand ~-8 ~-35 ~-18 {Tags:["boat_medium"]}
execute if score out math matches 3 run summon armor_stand ~30 ~20 ~-22 {Tags:["boat_medium"]}
execute if score out math matches 3 run summon armor_stand ~-32 ~-3 ~27 {Tags:["boat_medium"]}
execute if score out math matches 3 run summon armor_stand ~-35 ~-10 ~-31 {Tags:["boat_medium"]}
execute if score out math matches 3 run summon armor_stand ~31 ~-27 ~25 {Tags:["boat_medium"]}
execute if score out math matches 3 run summon armor_stand ~-6 ~8 ~48 {Tags:["boat_little"]}
execute if score out math matches 3 run summon armor_stand ~25 ~13 ~27 {Tags:["boat_little"]}
execute if score out math matches 3 run summon armor_stand ~60 ~17 ~7 {Tags:["boat_little"]}
execute if score out math matches 3 run summon armor_stand ~-60 ~-5 ~2 {Tags:["boat_little"]}
execute if score out math matches 3 run summon armor_stand ~-20 ~10 ~-55 {Tags:["boat_little"]}
execute if score out math matches 3 run summon armor_stand ~15 ~1 ~-45 {Tags:["boat_little"]}
execute if score out math matches 3 run summon armor_stand ~-10 ~25 ~-25 {Tags:["ghast_post"]}
execute if score out math matches 3 run summon armor_stand ~-10 ~25 ~25 {Tags:["ghast_post"]}

##Formation Five - Station
execute if score out math matches 4 run summon armor_stand ~6 ~8 ~42 {Tags:["boat_large"]}
execute if score out math matches 4 run summon armor_stand ~-4 ~4 ~-45 {Tags:["boat_large"]}
execute if score out math matches 4 run summon armor_stand ~55 ~3 ~17 {Tags:["boat_medium"]}
execute if score out math matches 4 run summon armor_stand ~60 ~10 ~-17 {Tags:["boat_medium"]}
execute if score out math matches 4 run summon armor_stand ~-50 ~15 ~-27 {Tags:["boat_medium"]}
execute if score out math matches 4 run summon armor_stand ~-52 ~-5 ~27 {Tags:["boat_medium"]}
execute if score out math matches 4 run summon armor_stand ~-15 ~40 ~-10 {Tags:["boat_little"]}
execute if score out math matches 4 run summon armor_stand ~25 ~42 ~27 {Tags:["boat_little"]}
execute if score out math matches 4 run summon armor_stand ~-55 ~ ~3 {Tags:["boat_little"]}
execute if score out math matches 4 run summon armor_stand ~59 ~31 ~-38 {Tags:["boat_little"]}
execute if score out math matches 4 run summon armor_stand ~ ~ ~ {Tags:["station"]}
execute if score out math matches 4 run summon armor_stand ~-40 ~15 ~18 {Tags:["ghast_post"]}
execute if score out math matches 4 run summon armor_stand ~30 ~25 ~-60 {Tags:["ghast_post"]}

##Formation Four - Six - YUGE
execute if score out math matches 5 run summon armor_stand ~ ~ ~ {Tags:["boat_large"]}
execute if score out math matches 5 run summon armor_stand ~-8 ~-35 ~-18 {Tags:["boat_medium"]}
execute if score out math matches 5 run summon armor_stand ~30 ~20 ~-22 {Tags:["boat_medium"]}
execute if score out math matches 5 run summon armor_stand ~-32 ~-3 ~27 {Tags:["boat_medium"]}
execute if score out math matches 5 run summon armor_stand ~-35 ~-10 ~-31 {Tags:["boat_medium"]}
execute if score out math matches 5 run summon armor_stand ~31 ~-27 ~25 {Tags:["boat_medium"]}
execute if score out math matches 5 run summon armor_stand ~-6 ~8 ~48 {Tags:["boat_little"]}
execute if score out math matches 5 run summon armor_stand ~25 ~13 ~27 {Tags:["boat_little"]}
execute if score out math matches 5 run summon armor_stand ~60 ~17 ~7 {Tags:["boat_little"]}
execute if score out math matches 5 run summon armor_stand ~-60 ~-5 ~2 {Tags:["boat_little"]}
execute if score out math matches 5 run summon armor_stand ~-20 ~10 ~-55 {Tags:["boat_little"]}
execute if score out math matches 5 run summon armor_stand ~15 ~1 ~-45 {Tags:["boat_little"]}
execute if score out math matches 5 run summon armor_stand ~-10 ~25 ~-25 {Tags:["ghast_post"]}
execute if score out math matches 5 run summon armor_stand ~-10 ~25 ~25 {Tags:["ghast_post"]}
##Extended
execute if score out math matches 5 run summon armor_stand ~-60 ~30 ~80 {Tags:["boat_large"]}
execute if score out math matches 5 run summon armor_stand ~-64 ~25 ~45 {Tags:["boat_medium"]}
execute if score out math matches 5 run summon armor_stand ~-32 ~35 ~110 {Tags:["boat_medium"]}
execute if score out math matches 5 run summon armor_stand ~-12 ~50 ~80 {Tags:["boat_little"]}
execute if score out math matches 5 run summon armor_stand ~-90 ~50 ~110 {Tags:["boat_little"]}
execute if score out math matches 5 run summon armor_stand ~-110 ~55 ~75 {Tags:["boat_little"]}
execute if score out math matches 5 run summon armor_stand ~-99 ~53 ~55 {Tags:["ghast_post"]}
execute if score out math matches 5 run summon armor_stand ~-72 ~55 ~125 {Tags:["ghast_post"]}


tag @s add summoned