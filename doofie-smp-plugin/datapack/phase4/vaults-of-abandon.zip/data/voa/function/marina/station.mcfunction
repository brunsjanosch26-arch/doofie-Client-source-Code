#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 0
function voa:natural_generation/random/range_lcg

###Ship Templates
execute if score out math matches 0 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -24, mode: "LOAD", posY: -24, sizeX: 48, posZ: -24, integrity: 1.0f, showair: 0b, name: "voa:station_steam", id: "minecraft:structure_block", sizeY: 48, sizeZ: 48, showboundingbox: 1b}

#Always Spawns Redstone
setblock ~ ~1 ~ minecraft:redstone_block

tag @s add summoned