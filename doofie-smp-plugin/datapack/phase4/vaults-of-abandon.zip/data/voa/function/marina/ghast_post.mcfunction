#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Dither Boats - 45%
setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -2, mode: "LOAD", posY: -3, sizeX: 5, posZ: -2, integrity: 1.0f, showair: 0b, name: "voa:ghast_turret", id: "minecraft:structure_block", strict: 0b, sizeY: 8, sizeZ: 5, showboundingbox: 1b}

#Always Spawns Redstone
setblock ~ ~1 ~ minecraft:redstone_block

tag @s add summoned