#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 11
function voa:natural_generation/random/range_lcg

###Ship Templates
#execute if score out math matches 0 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -24, mode: "LOAD", posY: -20, sizeX: 48, posZ: -12, integrity: 1.0f, showair: 0b, name: "voa:ship_galleon_dither", id: "minecraft:structure_block", sizeY: 41, sizeZ: 23, showboundingbox: 1b}
#execute if score out math matches 1 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -24, mode: "LOAD", posY: -20, sizeX: 48, posZ: -12, integrity: 1.0f, showair: 0b, name: "voa:ship_galleon_1", id: "minecraft:structure_block", sizeY: 41, sizeZ: 23, showboundingbox: 1b}
#execute if score out math matches 2 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -24, mode: "LOAD", posY: -20, sizeX: 48, posZ: -12, integrity: 1.0f, showair: 0b, name: "voa:ship_galleon_2", id: "minecraft:structure_block", sizeY: 41, sizeZ: 23, showboundingbox: 1b}


#Spawning Order - Least to Rarest

#Dither Boats - 60%
execute if score out math matches 0 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -24, mode: "LOAD", posY: -20, sizeX: 48, posZ: -12, integrity: 1.0f, showair: 0b, name: "voa:ship_galleon_dither", id: "minecraft:structure_block", sizeY: 41, sizeZ: 23, showboundingbox: 1b}
execute if score out math matches 1 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -24, mode: "LOAD", posY: -20, sizeX: 48, posZ: -12, integrity: 1.0f, showair: 0b, name: "voa:ship_galleon_dither", id: "minecraft:structure_block", sizeY: 41, sizeZ: 23, showboundingbox: 1b}
execute if score out math matches 2 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -24, mode: "LOAD", posY: -20, sizeX: 48, posZ: -12, integrity: 1.0f, showair: 0b, name: "voa:ship_galleon_dither", id: "minecraft:structure_block", sizeY: 41, sizeZ: 23, showboundingbox: 1b}
execute if score out math matches 3 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -24, mode: "LOAD", posY: -20, sizeX: 48, posZ: -12, integrity: 1.0f, showair: 0b, name: "voa:ship_galleon_dither", id: "minecraft:structure_block", sizeY: 41, sizeZ: 23, showboundingbox: 1b}
execute if score out math matches 4 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -24, mode: "LOAD", posY: -20, sizeX: 48, posZ: -12, integrity: 1.0f, showair: 0b, name: "voa:ship_galleon_dither", id: "minecraft:structure_block", sizeY: 41, sizeZ: 23, showboundingbox: 1b}
execute if score out math matches 5 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -24, mode: "LOAD", posY: -20, sizeX: 48, posZ: -12, integrity: 1.0f, showair: 0b, name: "voa:ship_galleon_dither", id: "minecraft:structure_block", sizeY: 41, sizeZ: 23, showboundingbox: 1b}
execute if score out math matches 10 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -24, mode: "LOAD", posY: -20, sizeX: 48, posZ: -12, integrity: 1.0f, showair: 0b, name: "voa:ship_galleon_dither", id: "minecraft:structure_block", sizeY: 41, sizeZ: 23, showboundingbox: 1b}


#Galleon Boat - 30%
execute if score out math matches 6 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -24, mode: "LOAD", posY: -20, sizeX: 48, posZ: -12, integrity: 1.0f, showair: 0b, name: "voa:ship_galleon_1", id: "minecraft:structure_block", sizeY: 41, sizeZ: 23, showboundingbox: 1b}
execute if score out math matches 7 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -24, mode: "LOAD", posY: -20, sizeX: 48, posZ: -12, integrity: 1.0f, showair: 0b, name: "voa:ship_galleon_1", id: "minecraft:structure_block", sizeY: 41, sizeZ: 23, showboundingbox: 1b}
execute if score out math matches 8 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -24, mode: "LOAD", posY: -20, sizeX: 48, posZ: -12, integrity: 1.0f, showair: 0b, name: "voa:ship_galleon_1", id: "minecraft:structure_block", sizeY: 41, sizeZ: 23, showboundingbox: 1b}
execute if score out math matches 11 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -24, mode: "LOAD", posY: -20, sizeX: 48, posZ: -12, integrity: 1.0f, showair: 0b, name: "voa:ship_galleon_1", id: "minecraft:structure_block", sizeY: 41, sizeZ: 23, showboundingbox: 1b}

#Treasure Ship - 10%
execute if score out math matches 9 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -24, mode: "LOAD", posY: -20, sizeX: 48, posZ: -12, integrity: 1.0f, showair: 0b, name: "voa:ship_galleon_2", id: "minecraft:structure_block", sizeY: 41, sizeZ: 23, showboundingbox: 1b}

#Always Spawns Redstone
setblock ~ ~1 ~ minecraft:redstone_block

tag @s add summoned