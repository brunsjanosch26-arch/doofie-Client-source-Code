#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#item replace entity @s weapon.mainhand with carrot_on_a_stick[custom_name='{"text":"Bonesket"}',custom_model_data=977779,custom_data={bonesket:"1b"},enchantments={levels:{"minecraft:knockback":1,"minecraft:sharpness":3}},enchantment_glint_override=false] 1

#execute anchored eyes positioned ^ ^ ^ run particle dust{color:[0.95,0.13,0.13],scale:2} ^-.01 ^ ^2
#execute anchored eyes positioned ^ ^ ^ run particle dust{color:[0.83,0.07,0.07],scale:1} ^-.01 ^ ^2 0.25 0.25 0.25 0 1
playsound minecraft:block.amethyst_block.resonate
#execute anchored eyes positioned ^ ^ ^ run particle minecraft:flame ^-.05 ^ ^1.1 
#execute anchored eyes positioned ^ ^ ^ run particle smoke ^ ^.1 ^1.1 

effect give @s[] slowness 1 5 true

#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# Tag prevents current caster from being detected
tag @s add raycastingdanger

# Anchor to the eyes and position with vector coordinates (Remove if not running from eyes of entity)
execute anchored eyes positioned ^ ^ ^.8 run function voa:staff_dangerous_elite/path

# Remove the raycasting tag after raycast completion to prepare for the next player
tag @s remove raycastingdanger
scoreboard players reset .distance tf_rc

#Muzzle Flash - And Sound
playsound minecraft:block.fire.extinguish ambient @a[distance=..20] ~ ~ ~ 3

#Sets Cooldown to reduce spam
execute as @s[scores={staff_d_elite_cool=..65}] at @s run scoreboard players add @s[] staff_d_elite_cool 1
execute as @s[scores={staff_d_elite_cool=66..}] at @s run item replace entity @s[tag=!tome_reuse_chest_dia,tag=!tome_reuse_helm,tag=!tome_reuse_chest,tag=!tome_reuse_legs,tag=!tome_reuse_boots] weapon.mainhand with carrot_on_a_stick[custom_name='"Godspell Staff: Incineration (11 Charges)"',custom_model_data={floats:[443434]},custom_data={staffm_d11:1b,staffm_d:1b}] 1

#Tome Reuse Tags - If they do have Tome Armor on.
execute as @s[tag=tome_reuse_helm] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_chest] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_chest_dia] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_legs] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_boots] at @s run tag @s add tome_retry 
#RNG
scoreboard players set in math 0
scoreboard players set in1 math 2
function voa:natural_generation/random/range_lcg
#Random Chance - Removal
execute as @s[scores={staff_d_elite_cool=66..},tag=tome_retry] if score out math matches 0 run playsound minecraft:willowbee.mob.hurt player @a ~ ~ ~ 1
execute as @s[scores={staff_d_elite_cool=66..},tag=tome_retry] if score out math matches 0 run particle minecraft:happy_villager ~ ~ ~ 1 1 1 .1 100
execute as @s[scores={staff_d_elite_cool=66..},tag=tome_retry] if score out math matches 1 run item replace entity @s weapon.mainhand with carrot_on_a_stick[custom_name='"Godspell Staff: Incineration (11 Charges)"',custom_model_data={floats:[443434]},custom_data={staffm_d11:1b,staffm_d:1b}] 1
execute as @s[scores={staff_d_elite_cool=66..},tag=tome_retry] if score out math matches 2 run item replace entity @s weapon.mainhand with carrot_on_a_stick[custom_name='"Godspell Staff: Incineration (11 Charges)"',custom_model_data={floats:[443434]},custom_data={staffm_d11:1b,staffm_d:1b}] 1

#Tags - Tome Retry Removal
execute as @s at @s run tag @s remove tome_retry 

execute as @s[scores={staff_d_elite_cool=66..}] at @s run scoreboard players set @s[] staff_d_elite_cool 0




