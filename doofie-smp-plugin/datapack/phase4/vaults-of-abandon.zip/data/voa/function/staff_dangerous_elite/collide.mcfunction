## Called from tf_raycast:raycast upon any targets whose hitbox collides with the raycast

#### What you do to the target is up to you

# Detect Headshots/bodyshots/legshots
#execute positioned ~ ~0.35 ~ unless entity @s[dx=0] positioned ~ ~-0.3 ~ run say headshot
#
#execute positioned ~ ~0.35 ~ if entity @s[dx=0] positioned ~ ~-2.3 ~ if entity @s[dx=0] run say chest shot
#
#execute positioned ~ ~-1.95 ~ unless entity @s[dx=0] run say leg shot

#say I have been hit by a raycast. oof
particle minecraft:flame ~ ~ ~ 0 0 0 0 5

#teleport Command
#execute at @s run summon armor_stand ~ ~ ~ {NoGravity:1b,Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["chaos_teleport"]}
#teleport @a[tag=raycastingtele] @e[tag=chaos_teleport,limit=1,sort=nearest]
#playsound minecraft:entity.enderman.teleport ambient @a[distance=..20] ~ ~ ~ 3
#execute as @a[tag=raycastingtele] at @s run particle dust{color:[0.83,0.07,0.07],scale:1} ~ ~ ~ 2 1 2 0.05 200
#execute as @e[tag=chaos_teleport] at @s run kill @s
damage @s 35 minecraft:explosion by @a[tag=raycastingdanger,limit=1,sort=nearest]
execute at @s run effect give @e[type=!area_effect_cloud,type=!experience_orb,type=!armor_stand,type=!item_frame,type=!player,type=!item,type=!arrow,distance=0..1.5,limit=1,sort=nearest] minecraft:slowness 1 1 true

#### Max out range to end the raycast
scoreboard players set .distance tf_rc 300


