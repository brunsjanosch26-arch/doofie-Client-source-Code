#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#item replace entity @s weapon.mainhand with carrot_on_a_stick[custom_name='{"text":"Bonesket"}',custom_model_data=977779,custom_data={bonesket:"1b"},enchantments={levels:{"minecraft:knockback":1,"minecraft:sharpness":3}},enchantment_glint_override=false] 1

execute anchored eyes positioned ^ ^ ^ run summon lightning_bolt ^ ^ ^10
execute anchored eyes positioned ^ ^ ^ run summon tnt ^ ^ ^10 {fuse:0}
