#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Spawn Structure
setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -24, mode: "LOAD", posY: -10, sizeX: 47, posZ: -23, integrity: 1.0f, showair: 0b, name: "voa:oblisk", id: "minecraft:structure_block", sizeY: 48, sizeZ: 48, showboundingbox: 1b}
setblock ~ ~1 ~ minecraft:redstone_block

scoreboard players set @e[tag=spawnoblisk,type=minecraft:armor_stand] buildingtime 180

tag @s add summoned
