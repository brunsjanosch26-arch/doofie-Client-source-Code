#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks


### THIS IS THE SPAWN COMMAND if I need to change the mob attributes this is where I will do it!!!
summon zombie ~ ~1 ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"voa:entities/abom_loot",Health:36f,IsBaby:0b,CanBreakDoors:1b,DrownedConversionTime:999999,Tags:["abomination","voa","cryptid"],Passengers:[{id:"minecraft:armor_stand",Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["abomination_body","voa"],equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[I;333331]}}}}}],CustomName:"Abomination",equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[333321]}}}},drop_chances:{head:0.000},active_effects:[{id:"minecraft:invisibility",amplifier:1,duration:999999,show_particles:0b}],attributes:[{id:"minecraft:attack_damage",base:7},{id:"minecraft:follow_range",base:30},{id:"minecraft:knockback_resistance",base:0.35},{id:"minecraft:max_health",base:36},{id:"minecraft:movement_speed",base:0.32}]}

#Particle & Sound
particle minecraft:squid_ink ~ ~0.5 ~ 1 1 1 0.00000000001 100
playsound minecraft:entity.generic.explode hostile @a[] ~ ~ ~ 5

#Gets rid of creeper
tp @s ~ ~-256 ~

