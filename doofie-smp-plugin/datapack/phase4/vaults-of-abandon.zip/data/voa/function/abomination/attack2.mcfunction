#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#Attack effect 2
effect give @a[distance=0..3] slowness 3 2
