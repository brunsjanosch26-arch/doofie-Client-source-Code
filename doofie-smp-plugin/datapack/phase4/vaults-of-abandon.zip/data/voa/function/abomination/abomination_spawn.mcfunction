#All of the code below is part of the Vaults of Abandon datapack created by Fried_Oats

###  If matches 0 
execute if score abomination_count cm_abomination matches 0 run summon zombie ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"voa:entities/abom_loot",Health:36f,IsBaby:0b,CanBreakDoors:1b,DrownedConversionTime:999999,Tags:["abomination","voa","cryptid"],Passengers:[{id:"minecraft:armor_stand",Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["abomination_body","voa"],equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[I;333331]}}}}}],CustomName:"Abomination",equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[333321]}}}},drop_chances:{head:0.000},active_effects:[{id:"minecraft:invisibility",amplifier:1,duration:999999,show_particles:0b}],attributes:[{id:"minecraft:attack_damage",base:7},{id:"minecraft:follow_range",base:30},{id:"minecraft:knockback_resistance",base:0.35},{id:"minecraft:max_health",base:36},{id:"minecraft:movement_speed",base:0.32}]}
execute if score abomination_count cm_abomination matches 0 run tp @s ~ ~-256 ~

### Add tag not_messenger to ensure the Zombie is not scanned again
tag @s add not_abomination
### Increment count
scoreboard players add abomination_count cm_abomination 1
### Reset Count
execute if score abomination_count cm_abomination matches 5 run scoreboard players set abomination_count cm_abomination 0

### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
scoreboard players add @e[tag=abomination,type=minecraft:zombie] atk_cool 0
scoreboard players add @e[tag=abomination,type=minecraft:zombie] sound_cool 0