#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Staircase
fill ~ ~ ~ ~ ~-33 ~ minecraft:spruce_log replace sponge
fill ~ ~ ~ ~ ~-33 ~ minecraft:spruce_log replace wet_sponge


#Rooms
fill ~4 ~ ~4 ~-4 ~-33 ~-4 minecraft:air replace sponge
fill ~4 ~ ~4 ~-4 ~-33 ~-4 minecraft:air replace wet_sponge

tag @s add summoned