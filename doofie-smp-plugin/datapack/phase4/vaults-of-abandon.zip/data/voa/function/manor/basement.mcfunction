#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Spawn Structure
setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "?", rotation: "NONE", posX: -15, mode: "LOAD", posY: -33, sizeX: 31, posZ: -15, integrity: 1.0f, showair: 0b, name: "voa:cobb", id: "minecraft:structure_block", sizeY: 25, sizeZ: 31, showboundingbox: 1b}
setblock ~ ~1 ~ minecraft:redstone_block

setblock ~ ~ ~ minecraft:air
setblock ~ ~1 ~ minecraft:air

summon armor_stand ~ ~ ~ {NoGravity:1b,Marker:1b,Invisible:0b,NoBasePlate:1b,Tags:["basement_sponge"],CustomName:'{"text":"Basement_sponge"}'}

tag @s add summoned