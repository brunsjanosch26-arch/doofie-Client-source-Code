#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#say SOAR!

execute as @p[distance=..50] at @s run summon armor_stand ~ ~ ~ {NoGravity:1b,Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["soar"]} 

#Armor-Stand Stats
scoreboard players add @e[tag=soar,type=minecraft:armor_stand,tag=!soar_stats] atk_soar_cool 80
execute as @e[tag=soar,tag=!soar_stats] at @s run tag @s add soar_stats

#Nether-Demon Stats
tag @s add soaring