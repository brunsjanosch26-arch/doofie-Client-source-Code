#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Nether Demon!

#Moving Animation - Body - Armor Stand Method
execute as @e[type=minecraft:armor_stand,tag=nether_demon_body] at @s if entity @e[type=minecraft:wither_skeleton,tag=nether_demon,distance=0..2.6,scores={animate=4}] run data merge entity @e[type=minecraft:armor_stand,tag=nether_demon_body,limit=1,sort=nearest,distance=..100] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[670003]}}}}}
execute if entity @s[scores={animate=4}] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run playsound minecraft:entity.hoglin.step hostile @a[distance=0..10]
execute as @e[type=minecraft:armor_stand,tag=nether_demon_body] at @s if entity @e[type=minecraft:wither_skeleton,tag=nether_demon,distance=0..2.6,scores={animate=8}] run data merge entity @e[type=minecraft:armor_stand,tag=nether_demon_body,limit=1,sort=nearest,distance=..100] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[670004]}}}}}
execute if entity @e[type=minecraft:wither_skeleton,tag=nether_demon,distance=0..2.6,scores={animate=8}] run scoreboard players set @s animate 1

##Resets Body Moving Animation
execute if entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players set @s animate 0
execute as @e[type=minecraft:armor_stand,tag=nether_demon_body] at @s if entity @e[type=minecraft:wither_skeleton,tag=nether_demon,distance=0..2.6,scores={animate=0}] run data merge entity @e[type=minecraft:armor_stand,tag=nether_demon_body,limit=1,sort=nearest,distance=..100] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[670001]}}}}}
##Detects if mob is moving - Applies body animation
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players add @s animate 1 

#Damage Sound
execute if entity @s[nbt={HurtTime:10s}] run playsound minecraft:horror.mob.hurt master @a[distance=0..10]
#

