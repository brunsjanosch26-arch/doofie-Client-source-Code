#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#How long it takes to cool down
#scoreboard players set @s atk_teleport 100


playsound minecraft:warped.titan.mob.atk hostile @a[] ~ ~ ~ 1.5

# Summon Cloud - or fireball - depending on tag
execute as @e[tag=nether_demon,scores={atk_flamethrower=1},tag=!fireballready] run summon minecraft:area_effect_cloud ~ ~1 ~ {Tags:["flamethrower_ball","not_rotated"],Duration:200} 
execute as @e[tag=nether_demon,scores={atk_flamethrower=1},tag=fireballready] run summon minecraft:area_effect_cloud ~ ~1 ~ {Tags:["flamethrower_ball","not_rotated","explosion"],Duration:200} 

# Face Player - raycasting
execute as @s[tag=nether_demon,scores={atk_flamethrower=1}] as @e[tag=flamethrower_ball,tag=not_rotated,distance=0..1.5] facing entity @p feet run tp @s ~ ~ ~ ~ ~
execute as @s[tag=nether_demon,scores={atk_flamethrower=1}] as @e[tag=flamethrower_ball,tag=not_rotated,distance=0..1.5] run tag @s remove not_rotated


#Resets Scoreboard
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,scores={atk_flamethrower=..1},sort=nearest,limit=1] at @s run scoreboard players set @e[tag=nether_demon,type=minecraft:wither_skeleton,scores={atk_flamethrower=..1}] atk_flamethrower 70

#particle affects
particle minecraft:squid_ink ~ ~0.5 ~ 1.5 .5 1.5 0.000000001 60

#Removes Fireball tag
execute as @e[tag=nether_demon,tag=fireballready] run tag @s remove fireballready
