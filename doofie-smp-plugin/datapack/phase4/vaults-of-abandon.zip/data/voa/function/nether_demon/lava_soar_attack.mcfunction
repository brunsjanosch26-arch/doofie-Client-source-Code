#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#say ATTACK!

#TP's Nether Demon
execute as @e[tag=nether_demon,tag=soaring] run tp @s @e[type=minecraft:armor_stand,tag=soar,sort=nearest,limit=1]
#Kills TP Marker
kill @e[type=minecraft:armor_stand,tag=soar,sort=nearest,limit=1]
#Nether Demon has completed attack
tag @e[tag=nether_demon,tag=soaring] remove soaring

