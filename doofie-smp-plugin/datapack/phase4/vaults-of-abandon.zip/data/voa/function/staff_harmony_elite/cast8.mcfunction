#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#item replace entity @s weapon.mainhand with carrot_on_a_stick[custom_name='{"text":"Bonesket"}',custom_model_data=977779,custom_data={bonesket:"1b"},enchantments={levels:{"minecraft:knockback":1,"minecraft:sharpness":3}},enchantment_glint_override=false] 1

#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Gives/Clears Effect
effect give @e[type=#voa:friendly,distance=..16] minecraft:instant_health 1 2
effect give @e[type=#voa:friendly,distance=..16] minecraft:resistance 30 2
effect give @e[type=#voa:friendly,distance=..16] minecraft:absorption 30 9
effect clear @e[type=#voa:friendly,distance=..16] minecraft:blindness
effect clear @e[type=#voa:friendly,distance=..16] minecraft:darkness
effect clear @e[type=#voa:friendly,distance=..16] minecraft:hunger
effect clear @e[type=#voa:friendly,distance=..16] minecraft:nausea
effect clear @e[type=#voa:friendly,distance=..16] minecraft:poison
effect clear @e[type=#voa:friendly,distance=..16] minecraft:slowness
effect clear @e[type=#voa:friendly,distance=..16] minecraft:weakness
effect clear @e[type=#voa:friendly,distance=..16] minecraft:wither
effect clear @e[type=#voa:friendly,distance=..16] minecraft:levitation

#Smite
effect give @e[type=#voa:undead,distance=..16] minecraft:instant_health 1 2

#Particle
particle minecraft:heart ~ ~ ~ 10 2 10 0.3 125 normal
particle dust{color:[0.0,0.98,1.0],scale:2} ~ ~ ~ 10 2 10 0.3 125 normal
particle dust{color:[0.18,0.4,0.92],scale:1} ~ ~ ~ 10 2 10 0.3 125 normal
playsound minecraft:willowbee.mob.hurt ambient @a[] ~ ~ ~ 2
playsound minecraft:item.totem.use ambient @a[] ~ ~ ~ 2

#data merge item
item replace entity @s[tag=!tome_reuse_chest_dia,tag=!tome_reuse_helm,tag=!tome_reuse_chest,tag=!tome_reuse_legs,tag=!tome_reuse_boots] weapon.mainhand with carrot_on_a_stick[custom_name='"Godspell Staff: Divine Heal (7 Charges)"',custom_model_data={floats:[423232]},custom_data={staffm_h7:1b,staffm_h:1b}] 1

#Tome Reuse Tags - If they do have Tome Armor on.
execute as @s[tag=tome_reuse_helm] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_chest] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_chest_dia] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_legs] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_boots] at @s run tag @s add tome_retry 

#RNG
scoreboard players set in math 0
scoreboard players set in1 math 2
function voa:natural_generation/random/range_lcg
#Random Chance - Removal
execute as @s[tag=tome_retry] if score out math matches 0 run playsound minecraft:willowbee.mob.hurt player @a ~ ~ ~ 1
execute as @s[tag=tome_retry] if score out math matches 0 run particle minecraft:happy_villager ~ ~ ~ 1 1 1 .1 100
execute as @s[tag=tome_retry] if score out math matches 1 run item replace entity @s weapon.mainhand with carrot_on_a_stick[custom_name='"Godspell Staff: Divine Heal (7 Charges)"',custom_model_data={floats:[423232]},custom_data={staffm_h7:1b,staffm_h:1b}] 1
execute as @s[tag=tome_retry] if score out math matches 2 run item replace entity @s weapon.mainhand with carrot_on_a_stick[custom_name='"Godspell Staff: Divine Heal (7 Charges)"',custom_model_data={floats:[423232]},custom_data={staffm_h7:1b,staffm_h:1b}] 1

#Tags - Tome Retry Removal
execute as @s at @s run tag @s remove tome_retry 