#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Control Sequence - Spawns a set number of enemies

playsound minecraft:fortress.music.petal.victory music @a[] ~ ~ ~ 7

#Summons Experience
summon experience_orb ~7 ~7 ~0.5 {Count:3,Value:20}
summon experience_orb ~7 ~6 ~0.5 {Count:3,Value:20}
summon experience_orb ~7 ~7 ~0.5 {Count:3,Value:20}
summon experience_orb ~7 ~6 ~0.5 {Count:3,Value:20}
summon experience_orb ~7 ~7 ~0.5 {Count:3,Value:20}
summon experience_orb ~7 ~4 ~1.5 {Count:3,Value:20}
summon experience_orb ~7 ~5 ~1.5 {Count:3,Value:20}
summon experience_orb ~7 ~4 ~1.5 {Count:3,Value:20}
summon experience_orb ~7 ~5 ~1.5 {Count:3,Value:20}
summon experience_orb ~7 ~4 ~1.5 {Count:3,Value:20}
summon experience_orb ~7 ~4 ~2.5 {Count:3,Value:20}
summon experience_orb ~7 ~4 ~2.5 {Count:3,Value:20}
summon experience_orb ~7 ~4 ~2.5 {Count:3,Value:20}
summon experience_orb ~7 ~4 ~2.5 {Count:3,Value:20}
summon experience_orb ~7 ~4 ~2.5 {Count:3,Value:20}
summon experience_orb ~7 ~8 ~-1.5 {Count:3,Value:20}
summon experience_orb ~7 ~6 ~-1.5 {Count:3,Value:20}
summon experience_orb ~7 ~8 ~-1.5 {Count:3,Value:20}
summon experience_orb ~7 ~6 ~-1.5 {Count:3,Value:20}
summon experience_orb ~7 ~8 ~-1.5 {Count:3,Value:20}
summon experience_orb ~7 ~8 ~-2.5 {Count:3,Value:20}
summon experience_orb ~7 ~8 ~-2.5 {Count:3,Value:20}
summon experience_orb ~7 ~8 ~-2.5 {Count:3,Value:20}
summon experience_orb ~7 ~8 ~-2.5 {Count:3,Value:20}
summon experience_orb ~7 ~8 ~-2.5 {Count:3,Value:20}
summon experience_orb ~8 ~5 ~0.5 {Count:3,Value:20}
summon experience_orb ~8 ~4 ~0.5 {Count:3,Value:20}
summon experience_orb ~8 ~5 ~0.5 {Count:3,Value:20}
summon experience_orb ~8 ~4 ~0.5 {Count:3,Value:20}
summon experience_orb ~8 ~5 ~0.5 {Count:3,Value:20}
summon experience_orb ~9 ~5 ~0.5 {Count:3,Value:20}
summon experience_orb ~9 ~5 ~0.5 {Count:3,Value:20}
summon experience_orb ~9 ~5 ~0.5 {Count:3,Value:20}
summon experience_orb ~9 ~5 ~0.5 {Count:3,Value:20}
summon experience_orb ~9 ~5 ~0.5 {Count:3,Value:20}
summon experience_orb ~6 ~8 ~0.5 {Count:3,Value:20}
summon experience_orb ~6 ~7 ~0.5 {Count:3,Value:20}
summon experience_orb ~6 ~7 ~0.5 {Count:3,Value:20}
summon experience_orb ~6 ~8 ~0.5 {Count:3,Value:20}
summon experience_orb ~6 ~8 ~0.5 {Count:3,Value:20}
summon experience_orb ~5 ~8 ~0.5 {Count:3,Value:20}
summon experience_orb ~5 ~8 ~0.5 {Count:3,Value:20}
summon experience_orb ~5 ~8 ~0.5 {Count:3,Value:20}
summon experience_orb ~5 ~8 ~0.5 {Count:3,Value:20}
summon experience_orb ~5 ~8 ~0.5 {Count:3,Value:20}


#Chests Spawn - Medium Chests
setblock ~2 ~12 ~-2 chest[facing=east]{LootTable:"voa:blocks/end_medium"} replace
particle minecraft:happy_villager ~2 ~12 ~-2 1 1 1 1 20 normal

setblock ~2 ~12 ~2 chest[facing=east]{LootTable:"voa:blocks/end_medium"} replace
particle minecraft:happy_villager ~2 ~12 ~2 1 1 1 1 20 normal

setblock ~-2 ~12 ~2 chest[facing=west]{LootTable:"voa:blocks/end_medium"} replace
particle minecraft:happy_villager ~-2 ~12 ~2 1 1 1 1 20 normal

setblock ~-2 ~12 ~-2 chest[facing=west]{LootTable:"voa:blocks/end_medium"} replace
particle minecraft:happy_villager ~-2 ~12 ~-2 1 1 1 1 20 normal

setblock ~ ~12 ~ chest[facing=south]{LootTable:"voa:blocks/end_medium"} replace
particle minecraft:happy_villager ~ ~12 ~ 1 1 1 1 20 normal

#Chests Spawn - Light Chests
setblock ~2 ~12 ~ chest[facing=east]{LootTable:"voa:blocks/end_light"} replace
particle minecraft:happy_villager ~2 ~12 ~ 1 1 1 1 20 normal

setblock ~ ~12 ~2 chest[facing=south]{LootTable:"voa:blocks/end_light"} replace
particle minecraft:happy_villager ~ ~12 ~2 1 1 1 1 20 normal

setblock ~ ~12 ~-2 chest[facing=north]{LootTable:"voa:blocks/end_light"} replace
particle minecraft:happy_villager ~ ~12 ~-2 1 1 1 1 20 normal

setblock ~-2 ~12 ~ chest[facing=west]{LootTable:"voa:blocks/end_light"} replace
particle minecraft:happy_villager ~2 ~12 ~-2 1 1 1 1 20 normal

#Outter Chests Spawn - Light Chests
setblock ~4 ~12 ~ chest[facing=east]{LootTable:"voa:blocks/end_light"} replace
particle minecraft:happy_villager ~2 ~12 ~ 1 1 1 1 20 normal

setblock ~ ~12 ~4 chest[facing=south]{LootTable:"voa:blocks/end_light"} replace
particle minecraft:happy_villager ~ ~12 ~2 1 1 1 1 20 normal

setblock ~ ~12 ~-4 chest[facing=north]{LootTable:"voa:blocks/end_light"} replace
particle minecraft:happy_villager ~ ~12 ~-2 1 1 1 1 20 normal

setblock ~-4 ~12 ~ chest[facing=west]{LootTable:"voa:blocks/end_light"} replace
particle minecraft:happy_villager ~2 ~12 ~-2 1 1 1 1 20 normal



#Kills Marker/Boundaries
particle entity_effect{color:[0.0,0.03,1.0,1.0]} ~ ~1 ~ 1 1 1 0.001 500
particle entity_effect{color:[1.0,0.0,0.0,1.0]} ~ ~1 ~ 1 1 1 0.001 500
particle entity_effect{color:[0.98,1.0,0.0,1.0]} ~ ~1 ~ 1 1 1 0.001 500

kill @s
execute as @s at @s run kill @e[type=minecraft:armor_stand,tag=petal_lava_field,distance=..30]
