#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 4
function voa:natural_generation/random/range_lcg


### Battle ----------------------------------------------------------------------------------------------------------------------------------------------- #Prelude#

#Note for Summoners
say Destroying the nearby end crystals is the only way to lift the force field protecting the center island! Find them!

### Spawns Boss ----------------------------------------------------------------------------------------------------------------------------------------- #Boss Start#
summon zombified_piglin ~ ~ ~ {NoGravity:0b,Silent:1b,Invulnerable:1b,CustomNameVisible:0b,DeathLootTable:"voa:entities/petal",PersistenceRequired:1b,Health:800f,CanBreakDoors:1b,Tags:["boss","voa","petal","ghost"],CustomName:"Petal",equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[740001]}}}},drop_chances:{head:0.000},active_effects:[{id:"minecraft:jump_boost",amplifier:1,duration:99999,show_particles:0b},{id:"minecraft:invisibility",amplifier:1,duration:999999,show_particles:0b}],attributes:[{id:"minecraft:max_health",base:800},{id:"minecraft:movement_speed",base:0}]}
#### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
scoreboard players add @e[tag=petal,type=minecraft:zombified_piglin,sort=nearest,limit=1] sound_cool 0
scoreboard players add @e[tag=petal,type=minecraft:zombified_piglin,sort=nearest,limit=1] petal_heal 0
scoreboard players add @e[tag=petal,type=minecraft:zombified_piglin,sort=nearest,limit=1] boss_cool 0
scoreboard players add @e[tag=petal,type=minecraft:zombified_piglin,sort=nearest,limit=1] atk_dart_cool 300
scoreboard players add @e[tag=petal,type=minecraft:zombified_piglin,sort=nearest,limit=1] atk_lair_cool 180

#Initializes Boss health Scoreboard - THIS IS ONLY USED FOR A PHASE 2, NOT BOSSBAR
scoreboard players add @e[tag=petal,type=minecraft:zombified_piglin,limit=1,sort=nearest] boss_health 0
### Spawns Boss -- #Boss END#

#Summons Protective Crystals

#BIG OLE SHIPS
summon end_crystal ~3 ~8 ~-43 {Tags:["petal_phase"]}
summon end_crystal ~13 ~12 ~44 {Tags:["petal_phase"]}

#Medium Front
summon end_crystal ~66 ~16 ~-13 {Tags:["petal_phase"]}
summon end_crystal ~61 ~9 ~21 {Tags:["petal_phase"]}

#Medium Rear
summon end_crystal ~-46 ~1 ~31 {Tags:["petal_phase"]}
summon end_crystal ~-44 ~21 ~-23 {Tags:["petal_phase"]}

#KILL ARMOR STAND
tag @s[] add summoned
tag @e[tag=petal_isle_detection,distance=..50,sort=nearest,limit=1] add petal_summoned