#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Effects
effect give @a[distance=0..6] slowness 10 2
effect give @a[distance=0..4] weakness 10 0
effect give @a[distance=0..4] blindness 10 0
effect give @a[distance=0..4] hunger 10 0
effect give @e[distance=0..6,type=!#voa:not_mob,type=!player] speed 12 1
summon breeze_wind_charge ~ ~ ~ {Motion:[0.0,-1.0,0.0]}
summon breeze_wind_charge ~1 ~ ~ {Motion:[0.0,-1.0,0.0]}
summon breeze_wind_charge ~-1 ~ ~ {Motion:[0.0,-1.0,0.0]}
summon breeze_wind_charge ~ ~ ~1 {Motion:[0.0,-1.0,0.0]}
summon breeze_wind_charge ~ ~ ~-1 {Motion:[0.0,-1.0,0.0]}

#Sounds & Particles
playsound minecraft:entity.firework_rocket.blast master @a[] ~ ~ ~ 2
particle minecraft:explosion ~ ~ ~ 3 3 3 .3 20 normal