#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 44
#scoreboard players set in1 math 49

function voa:natural_generation/random/range_lcg

execute if score out math matches 0 run playsound minecraft:entity.breeze.jump hostile @a ~ ~ ~ 3
execute if score out math matches 0 run summon breeze ~ ~3 ~
