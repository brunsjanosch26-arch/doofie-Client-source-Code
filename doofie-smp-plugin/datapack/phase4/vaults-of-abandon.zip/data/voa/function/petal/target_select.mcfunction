#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Selects Target
tag @a[tag=cantarget,sort=random,limit=1] add chosenOne

#Triggers Petal
tag @s add petalChosen

#Swaps Model;