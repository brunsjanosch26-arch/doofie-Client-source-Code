#tag_out_sequence
#Tags Petal
tag @e[tag=petal,sort=nearest,limit=1,tag=playerinlair,distance=..100] remove playerinlair
#Tags Marker
tag @s[tag=lock_in] remove lock_in
