#lock_in_sequence
#Tags Petal
tag @e[tag=petal,sort=nearest,limit=1,tag=!playerinlair,distance=..100] add playerinlair
#Tags Marker
tag @s[tag=!lock_in] add lock_in

