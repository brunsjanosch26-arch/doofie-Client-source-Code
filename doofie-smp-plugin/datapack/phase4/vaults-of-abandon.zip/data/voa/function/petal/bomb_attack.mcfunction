#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 6
function voa:natural_generation/random/range_lcg

execute if score out math matches 0 run execute as @a[] at @s if entity @e[distance=..110,scores={atk_dart_cool=2}] run summon armor_stand ~ ~ ~ {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["bomb_attack","stun"],equipment:{head:{id:"minecraft:snowball",count:1,components:{"minecraft:custom_model_data":{floats:[100421]}}}}}
execute if score out math matches 1 run execute as @a[] at @s if entity @e[distance=..110,scores={atk_dart_cool=2}] run summon armor_stand ~ ~ ~ {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["bomb_attack","stun"],equipment:{head:{id:"minecraft:snowball",count:1,components:{"minecraft:custom_model_data":{floats:[100421]}}}}}
execute if score out math matches 2 run execute as @a[] at @s if entity @e[distance=..110,scores={atk_dart_cool=2}] run summon armor_stand ~ ~ ~ {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["bomb_attack","stun"],equipment:{head:{id:"minecraft:snowball",count:1,components:{"minecraft:custom_model_data":{floats:[100421]}}}}}
execute if score out math matches 3 run execute as @a[] at @s if entity @e[distance=..110,scores={atk_dart_cool=2}] run summon armor_stand ~ ~ ~ {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["bomb_attack","stun"],equipment:{head:{id:"minecraft:snowball",count:1,components:{"minecraft:custom_model_data":{floats:[100421]}}}}}
execute if score out math matches 4 run execute as @a[] at @s if entity @e[distance=..110,scores={atk_dart_cool=2}] run summon armor_stand ~ ~ ~ {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["bomb_attack","stun"],equipment:{head:{id:"minecraft:snowball",count:1,components:{"minecraft:custom_model_data":{floats:[100421]}}}}}
execute if score out math matches 5 run execute as @a[] at @s if entity @e[distance=..110,scores={atk_dart_cool=2}] run summon armor_stand ~ ~ ~ {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["bomb_attack","stun"],equipment:{head:{id:"minecraft:snowball",count:1,components:{"minecraft:custom_model_data":{floats:[100421]}}}}}
execute if score out math matches 6 run execute as @a[] at @s if entity @e[distance=..110,scores={atk_dart_cool=2}] run summon armor_stand ~ ~ ~ {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["bomb_attack","explode"],equipment:{head:{id:"minecraft:snowball",count:1,components:{"minecraft:custom_model_data":{floats:[100422]}}}}}
execute as @a[] at @s if entity @e[distance=20..110,scores={atk_dart_cool=2}] run playsound minecraft:entity.firework_rocket.blast ambient @a ~ ~ ~ 1

#Scoreboard
scoreboard players set @e[tag=bomb_attack,type=minecraft:armor_stand,sort=nearest] atk_cool 38

