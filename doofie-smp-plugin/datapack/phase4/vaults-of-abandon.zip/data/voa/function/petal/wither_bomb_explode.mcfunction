#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Effects
particle minecraft:squid_ink ~ ~ ~ 0 2 0 .01 20
particle minecraft:squid_ink ~ ~ ~ 2 0 2 .01 20
playsound minecraft:entity.firework_rocket.large_blast_far hostile @a ~ ~ ~ 1
effect give @a[distance=..4] minecraft:wither 6 5
effect give @a[distance=..4] minecraft:hunger 6 1
effect give @a[distance=..4] minecraft:blindness 6 1
tag @a[distance=..4] add wither_boom
execute as @a[tag=wither_boom] at @s run damage @s 20 minecraft:arrow by @e[tag=petal,sort=nearest,limit=1]
summon breeze_wind_charge ~ ~ ~ {Motion:[0.0,-1.0,0.0]}
summon breeze_wind_charge ~1 ~ ~ {Motion:[0.0,-1.0,0.0]}
summon breeze_wind_charge ~-1 ~ ~ {Motion:[0.0,-1.0,0.0]}
summon breeze_wind_charge ~ ~ ~1 {Motion:[0.0,-1.0,0.0]}
summon breeze_wind_charge ~ ~ ~-1 {Motion:[0.0,-1.0,0.0]}
kill @s
