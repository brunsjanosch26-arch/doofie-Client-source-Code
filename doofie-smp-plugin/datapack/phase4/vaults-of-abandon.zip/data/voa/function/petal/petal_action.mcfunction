#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

##Petal Attack (Outter)---------------------------------------------------- >>

#Player Attack
execute as @s[scores={atk_dart_cool=2}] at @s run function voa:petal/bomb_attack

#Resets
execute as @s[scores={atk_dart_cool=..1}] at @s run scoreboard players set @s[scores={atk_dart_cool=..1}] atk_dart_cool 440

#Forcefield
execute as @s[tag=!field] at @s if entity @e[tag=petal_phase,distance=..100] run tag @s add field
execute as @s[tag=field] at @s if entity @a[distance=..40] run particle minecraft:soul ~ ~ ~ 20 55 20 0.1 1500
#execute as @s[tag=field] at @s if entity @a[distance=..40] run effect give @a[distance=..38] minecraft:darkness 3 1
#execute as @s[tag=field] at @s if entity @a[distance=..40] run effect give @a[distance=..38] minecraft:wither 1 1
execute as @s[tag=field] at @s unless entity @e[tag=petal_phase,distance=..100] run playsound minecraft:item.trident.thunder hostile @a ~ ~ ~ 8
execute as @s[tag=field] at @s unless entity @e[tag=petal_phase,distance=..100] run playsound minecraft:entity.firework_rocket.twinkle_far hostile @a ~ ~ ~ 8
execute as @s[tag=field] at @s unless entity @e[tag=petal_phase,distance=..100] run playsound minecraft:entity.firework_rocket.large_blast_far hostile @a ~ ~ ~ 8
execute as @s[tag=field] at @s unless entity @e[tag=petal_phase,distance=..100] run playsound minecraft:ambient.cave hostile @a ~ ~ ~ 8
execute as @s[tag=field] at @s unless entity @e[tag=petal_phase,distance=..100] run say MY SHIELD! YOU'LL PAY FOR THIS!
execute as @s[tag=field] at @s unless entity @e[tag=petal_phase,distance=..100] run tag @s remove field


##ARENA Control -- Whether Shielded or not---------------------------------------------------- >>
#Invulnearable Shield - Down
execute as @s[tag=playerinlair,tag=!broken_shield,tag=!health_boosty] run playsound minecraft:ambient.cave ambient @a ~ ~ ~ 5
execute as @s[tag=playerinlair,tag=!broken_shield,tag=!health_boosty] run data merge entity @e[tag=petal,type=minecraft:zombified_piglin,sort=nearest,limit=1] {Invulnerable:0b,equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[740000]}}}},drop_chances:{head:-327.670}}
execute as @s[tag=playerinlair,tag=!broken_shield,tag=!health_boosty] run tag @s add broken_shield

#Invulnearable Shield - Up
execute as @s[tag=!playerinlair,tag=broken_shield,tag=!health_boosty] run playsound minecraft:entity.firework_rocket.blast ambient @a ~ ~ ~ 5
execute as @s[tag=!playerinlair,tag=broken_shield,tag=!health_boosty] run data merge entity @e[tag=petal,type=minecraft:zombified_piglin,sort=nearest,limit=1] {Invulnerable:1b,equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[740001]}}}},drop_chances:{head:-327.670}}
execute as @s[tag=!playerinlair,tag=broken_shield,tag=!health_boosty] run tag @s remove broken_shield

#Healing Animation - If Healing - Players in Arena
execute as @s[tag=playerinlair,tag=health_boosty] at @s run data merge entity @e[tag=petal,type=minecraft:zombified_piglin,sort=nearest,limit=1] {Invulnerable:0b,equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[740003]}}}},drop_chances:{head:-327.670}}
execute as @s[tag=playerinlair,tag=health_boosty] at @s run particle minecraft:happy_villager ~ ~ ~ 1 1 1 .1 5

#Healing Animation - If Healing - Players OUT of Arena
execute as @s[tag=!playerinlair,tag=health_boosty] at @s run data merge entity @e[tag=petal,type=minecraft:zombified_piglin,sort=nearest,limit=1] {Invulnerable:1b,equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[740003]}}}},drop_chances:{head:-327.670}}
execute as @s[tag=!playerinlair,tag=health_boosty] at @s run particle minecraft:happy_villager ~ ~ ~ 1 1 1 .1 5

particle minecraft:dragon_breath ~ ~ ~ 1 1 1 0.1 10

##Petal Attack (Inner)---------------------------------------------------- >>
execute as @s[tag=playerinlair,tag=!petalChosen] at @s run tp @s ~ ~ ~ facing entity @p[distance=..20]
execute as @s[tag=playerinlair,tag=petalChosen] at @s run tp @s ~ ~ ~ facing entity @p[tag=chosenOne]

##HEAL Trigger~~~~~! - Ignore Shooting Attack
execute as @s[scores={atk_lair_cool=150,petal_heal=3}] at @s run tag @s add health_boosty
execute as @s[scores={atk_lair_cool=150,petal_heal=3}] at @s run playsound minecraft:willowbee.mob.heal hostile @a ~ ~ ~ 3
execute as @a[] at @s if entity @e[tag=health_boosty,distance=..30] run particle minecraft:dragon_breath ~ ~ ~ 1.5 1.5 1.5 0.1 20
execute as @a[] at @s if entity @e[tag=health_boosty,distance=..30] run effect give @s minecraft:slowness 1 1
execute as @a[] at @s if entity @e[tag=health_boosty,distance=..30,tag=playerinlair] run effect give @s minecraft:levitation 1 0
execute as @a[] at @s if entity @e[tag=health_boosty,distance=..30] run playsound minecraft:entity.guardian.attack ambient @a[] ~ ~ ~ 2

#Wither Bomb
execute as @s[scores={atk_lair_cool=150}] at @s run function voa:petal/wither_bomb
execute as @s[scores={atk_lair_cool=75}] at @s run function voa:petal/wither_bomb

#Chance to Summon Minion (Breeze)
execute as @e[tag=spawn_petal_minion] at @s if entity @e[tag=petal,scores={atk_lair_cool=150},distance=..50] run function voa:petal/minion

##Non-Heal~~~~~~~
#Pistol Shots
execute as @s[scores={atk_lair_cool=119},tag=!health_boosty] run data merge entity @e[tag=petal,type=minecraft:zombified_piglin,sort=nearest,limit=1] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[740002]}}}},drop_chances:{head:-327.670}}
execute as @s[scores={atk_lair_cool=119},tag=!health_boosty] at @s if entity @p[tag=cantarget] run function voa:petal/target_select_close
execute as @s[scores={atk_lair_cool=100},tag=!health_boosty] at @s if entity @a[tag=cantarget,tag=chosenOne] run function voa:petal/shot

execute as @s[scores={atk_lair_cool=99},tag=!health_boosty] at @s if entity @p[tag=cantarget] run function voa:petal/target_select
execute as @s[scores={atk_lair_cool=80},tag=!health_boosty] at @s if entity @a[tag=cantarget,tag=chosenOne] run function voa:petal/shot

execute as @s[scores={atk_lair_cool=79},tag=!health_boosty] at @s if entity @p[tag=cantarget] run function voa:petal/target_select
execute as @s[scores={atk_lair_cool=60},tag=!health_boosty] at @s if entity @a[tag=cantarget,tag=chosenOne] run function voa:petal/shot

execute as @s[scores={atk_lair_cool=59},tag=!health_boosty] at @s if entity @p[tag=cantarget] run function voa:petal/target_select_close
execute as @s[scores={atk_lair_cool=40},tag=!health_boosty] at @s if entity @a[tag=cantarget,tag=chosenOne] run function voa:petal/shot
execute as @s[scores={atk_lair_cool=39},tag=!health_boosty] run data merge entity @e[tag=petal,type=minecraft:zombified_piglin,sort=nearest,limit=1] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[740000]}}}},drop_chances:{head:-327.670}}

##HEAL~~~~~! - Removes Tag & Heals
execute as @s[scores={atk_lair_cool=3},tag=health_boosty] at @s run effect give @s minecraft:instant_damage 1 5

execute as @s[scores={atk_lair_cool=3},tag=health_boosty] at @s run data merge entity @e[tag=petal,type=minecraft:zombified_piglin,sort=nearest,limit=1] {Invulnerable:0b,equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[740000]}}}},drop_chances:{head:-327.670}}
execute as @s[scores={atk_lair_cool=3},tag=health_boosty] at @s run playsound minecraft:willowbee.mob.hurt ambient @a[] ~ ~ ~ 3
execute as @a at @s if entity @e[scores={atk_lair_cool=3},tag=health_boosty,distance=..30] run damage @s 25 minecraft:magic
execute as @s[scores={atk_lair_cool=3},tag=health_boosty] at @s run tag @s remove health_boosty

###Scoreboards---------------------------------------------------- >>
execute as @s[tag=!playerinlair] if entity @a[distance=..110] run scoreboard players remove @s[scores={atk_dart_cool=1..}] atk_dart_cool 1
execute as @s[tag=playerinlair] as @s run scoreboard players remove @s[scores={atk_lair_cool=1..}] atk_lair_cool 1
execute as @s[tag=playerinlair,scores={atk_lair_cool=..1}] as @s run scoreboard players add @s[scores={atk_lair_cool=..1}] petal_heal 1
execute as @s[tag=playerinlair,scores={petal_heal=4}] as @s run scoreboard players set @s[] petal_heal 0
execute as @s[tag=playerinlair,scores={atk_lair_cool=..1}] as @s run scoreboard players set @s[scores={atk_lair_cool=..1}] atk_lair_cool 180

