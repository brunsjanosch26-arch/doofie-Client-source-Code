#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
execute as @a[tag=cantarget] at @s run summon armor_stand ~ ~ ~ {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["wither_bomb_attack"],equipment:{head:{id:"minecraft:snowball",count:1,components:{"minecraft:custom_model_data":{floats:[100423]}}}}}
execute as @a[tag=cantarget] run playsound minecraft:entity.firework_rocket.blast master @a[] ~ ~ ~ 2

#Scoreboard
scoreboard players set @e[tag=wither_bomb_attack,type=minecraft:armor_stand,sort=nearest] atk_cool 38

