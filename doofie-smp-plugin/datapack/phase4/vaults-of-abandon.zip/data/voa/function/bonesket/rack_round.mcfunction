#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

##Removes Ammo from inventory
clear @s stick[minecraft:custom_data={boneshot:1b}] 1

# Steady Weapons
playsound minecraft:block.stone_button.click_on ambient @p[distance=..10]
item replace entity @s weapon.mainhand with carrot_on_a_stick[custom_name="Bonesket(Loaded)",custom_model_data={floats:[977778]},custom_data={bonesketloaded:1b},enchantments={"minecraft:knockback":1,"minecraft:sharpness":3},enchantment_glint_override=false] 1

effect clear @s[] slowness

scoreboard players set @p[scores={bonesktracking=0..}] bonesktracking 18
