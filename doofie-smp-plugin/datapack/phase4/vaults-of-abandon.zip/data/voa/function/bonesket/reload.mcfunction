#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
item replace entity @s weapon.mainhand with carrot_on_a_stick[custom_name="Bonesket",custom_model_data={floats:[977779]},custom_data={bonesket:1b},enchantments={"minecraft:knockback":1,"minecraft:sharpness":3},enchantment_glint_override=false] 1

effect give @s[] slowness 1 3 true

scoreboard players set @a[scores={boneskt_cool=0..}] boneskt_cool 8
