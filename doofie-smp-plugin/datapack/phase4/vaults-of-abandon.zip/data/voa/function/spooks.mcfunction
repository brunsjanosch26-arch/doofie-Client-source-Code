#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#----------------------------------------------------------------------------------- Mobs - Spooks ---------------------------------------------------------------------------------------------#
#say SPOOKY!

###----------------------------------------------------------------------------------- Wraith------------------------------------------------------------------------------>
#Wraith Spawn Options
#Skeleton Based Spawn
execute as @e[type=minecraft:skeleton,tag=!not_wraith,sort=random] at @s run function voa:wraith/wraith_spawn
##Armor-Stand Spawn
execute as @e[type=minecraft:armor_stand,tag=spawnwraith100,tag=!summoned] at @s run function voa:wraith/wraith_spawn_100
execute as @e[type=minecraft:armor_stand,tag=spawnwraith100,tag=summoned] at @s run kill @s

##Runs Mob Commands
execute as @e[tag=wraith,type=minecraft:husk] at @s if entity @a[distance=0..30] run function voa:wraith/mob


##----------------------------------------------------------------------------------- Spectre------------------------------------------------------------------------------>
#Spectre Spawn options
#Armor-Stand Spectre Spawn#
execute as @e[type=minecraft:armor_stand,tag=spawnspectre,tag=!summoned,tag=!invisible] run function voa:spectre/invisible
execute as @e[type=minecraft:armor_stand,tag=spawnspectre,tag=!summoned,tag=invisible] at @s if entity @a[distance=..20] run function voa:spectre/spawnspectre
execute as @e[type=minecraft:armor_stand,tag=spawnspectre,tag=summoned] at @s run kill @s
#Armor-Stand Spawner - 100% Chance
execute as @e[type=minecraft:armor_stand,tag=spawnspectre100,tag=!summoned] at @s run function voa:spectre/spectre_spawn_100
execute as @e[type=minecraft:armor_stand,tag=spawnspectre100,tag=summoned] at @s run kill @s

#Runs Mob Commands
execute as @e[tag=spectre,type=minecraft:husk] at @s if entity @a[distance=0..30] run function voa:spectre/mob



##----------------------------------------------------------------------------------- Reaper------------------------------------------------------------------------------>
#Reaper MOB START#

#Armor-Stand Reaper Spawn#
execute as @e[type=minecraft:armor_stand,tag=spawnreaper100,tag=!summoned] at @s if entity @a[distance=..7] run function voa:reaper/spawnreaper100
execute as @e[type=minecraft:armor_stand,tag=spawnreaper100,tag=summoned] at @s run kill @s

#Armor-Stand Reaper Spawn#
execute as @e[type=minecraft:armor_stand,tag=spawnreaper,tag=!summoned,tag=!invisible] run function voa:reaper/invisible
execute as @e[type=minecraft:armor_stand,tag=spawnreaper,tag=!summoned] at @s if entity @a[distance=..7] run function voa:reaper/spawnreaper
execute as @e[type=minecraft:armor_stand,tag=spawnreaper,tag=summoned] at @s run kill @s

#Runs Mob Commands
execute as @e[tag=reaper,type=minecraft:husk] at @s if entity @a[distance=0..30] run function voa:reaper/mob



#----------------------------------------------------------------------------------- Flower/Boss Fight------------------------------------------------------------------------------>
#Boss - Phase One ---------------------------------------------------- >>
#Phase One - AOE Potion Attack Timeline
execute at @e[tag=spook] if entity @e[type=zombified_piglin,tag=boss,tag=phase1,scores={atk_cool=240}] run playsound minecraft:willowbee.mob.hurt ambient @a[distance=..36] ~ ~ ~ 2
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase1,tag=canattack,scores={atk_cool=120}] at @s if entity @a[distance=0..50] run function voa:boss/attack_phase1
execute at @e[tag=spook] if entity @e[type=zombified_piglin,tag=boss,tag=phase1,scores={atk_cool=120}] run playsound minecraft:willowbee.mob.hurt ambient @a[distance=..36] ~ ~ ~ 2
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase1,tag=canattack,tag=potion2,scores={atk_cool=105}] at @s if entity @a[distance=0..50] run function voa:boss/attack_phase1_2
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase1,tag=canattack,tag=potion3,scores={atk_cool=90}] at @s if entity @a[distance=0..50] run function voa:boss/attack_phase1_3
execute at @e[tag=spook] if entity @e[type=zombified_piglin,tag=boss,tag=phase1,scores={atk_cool=0}] run playsound minecraft:willowbee.mob.hurt ambient @a[distance=..36] ~ ~ ~ 2
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase1,tag=canattack,scores={atk_cool=0}] at @s if entity @a[distance=0..50] run scoreboard players set @s atk_cool 240

#Phase1 - Potion Attack
#Potion1
execute as @e[type=minecraft:armor_stand,tag=boss_potion] at @s run particle minecraft:squid_ink ~ ~ ~ .2 1 .2 .2 20 normal
execute as @e[type=minecraft:armor_stand,tag=boss_potion,scores={atk_cool=2}] at @s run summon area_effect_cloud ~ ~ ~ {Particle:{type:"dragon_breath"},Radius:3.5f,Duration:40,potion_contents:{potion:"minecraft:strong_harming",custom_color:6368406},Tags:["pot_atk"]}
execute as @e[type=minecraft:armor_stand,tag=boss_potion,scores={atk_cool=1}] at @s run kill @s
#Potion2
execute as @e[type=minecraft:armor_stand,tag=boss_potion2] at @s run particle minecraft:squid_ink ~ ~ ~ .2 1 .2 .2 20 normal
execute as @e[type=minecraft:armor_stand,tag=boss_potion2,scores={atk_cool=2}] at @s run summon area_effect_cloud ~ ~ ~ {Particle:{type:"dragon_breath"},Radius:3.5f,Duration:40,potion_contents:{potion:"minecraft:strong_harming",custom_color:6368406},Tags:["pot_atk"]}
execute as @e[type=minecraft:armor_stand,tag=boss_potion2,scores={atk_cool=2}] at @s run summon area_effect_cloud ~ ~ ~ {Particle:{type:"dragon_breath"},Radius:3.5f,Duration:40,potion_contents:{potion:"minecraft:strong_harming",custom_color:6368406},Tags:["pot_atk"]}
execute as @e[type=minecraft:armor_stand,tag=boss_potion2,scores={atk_cool=1}] at @s run kill @s
#Potion3
execute as @e[type=minecraft:armor_stand,tag=boss_potion3] at @s run particle minecraft:squid_ink ~ ~ ~ .2 1 .2 .2 20 normal
execute as @e[type=minecraft:armor_stand,tag=boss_potion3,scores={atk_cool=2}] at @s run summon area_effect_cloud ~ ~ ~ {Particle:{type:"dragon_breath"},Radius:3.5f,Duration:40,potion_contents:{potion:"minecraft:strong_harming",custom_color:6368406},Tags:["pot_atk"]}
execute as @e[type=minecraft:armor_stand,tag=boss_potion3,scores={atk_cool=2}] at @s run summon area_effect_cloud ~ ~ ~ {Particle:{type:"dragon_breath"},Radius:3.5f,Duration:40,potion_contents:{potion:"minecraft:strong_harming",custom_color:6368406},Tags:["pot_atk"]}
execute as @e[type=minecraft:armor_stand,tag=boss_potion3,scores={atk_cool=2}] at @s run summon area_effect_cloud ~ ~ ~ {Particle:{type:"dragon_breath"},Radius:3.5f,Duration:40,potion_contents:{potion:"minecraft:strong_harming",custom_color:6368406},Tags:["pot_atk"]}
execute as @e[type=minecraft:armor_stand,tag=boss_potion3,scores={atk_cool=1}] at @s run kill @s

#Long Range Attack - Down - Phase One
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase1,tag=down,scores={atk_cool=120}] at @s if entity @a[distance=12..50] run function voa:boss/attack_phase1

##Triggers if all Spooks are dead - Phase One
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase1,tag=!down] at @s unless entity @e[tag=spook,distance=..60] run function voa:boss/boss_down
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=down,scores={boss_cool=..1}] at @s run function voa:boss/boss_up
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase1,tag=down] at @s run particle minecraft:bubble_column_up ~ ~ ~ 2 0 2 .2 100
#Phase One - Spook Particle Animation
execute as @e[tag=spook] at @s run particle minecraft:small_flame ~ ~-1 ~ .5 1 .5 .000005 5


#Boss - Phase Two ---------------------------------------------------- >>
##Phase 2 - Movement Animation - Boss
execute as @e[tag=boss,tag=phase2,tag=!casting,type=minecraft:zombified_piglin] at @s if entity @a[distance=0..50] run function voa:boss/animate


#Phase2 - Tome Attack
#Casting - First Break
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=497}] at @s run tag @s add casting
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=casting,scores={atk_cool=497}] at @s run particle minecraft:soul_fire_flame ~ ~ ~ .5 1 .5 .2 20
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=497}] at @s run function voa:boss/phase2/tome_first_break
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=497}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=497}] at @s if entity @a[distance=..22] run effect give @a[distance=..22] minecraft:slowness 40 3
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=497}] at @s if entity @a[distance=..22] run effect give @a[distance=..22] minecraft:weakness 40 3
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=497}] at @s run effect give @s minecraft:slowness 40 3
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=casting,scores={atk_cool=480}] at @s run particle minecraft:soul_fire_flame ~ ~ ~ .5 1 .5 .2 20
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=480}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=casting,scores={atk_cool=460}] at @s run particle minecraft:soul_fire_flame ~ ~ ~ .5 1 .5 .2 20
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=460}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=casting,scores={atk_cool=440}] at @s run particle minecraft:soul_fire_flame ~ ~ ~ .5 1 .5 .2 20
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=440}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=casting,scores={atk_cool=420}] at @s run particle minecraft:soul_fire_flame ~ ~ ~ .5 1 .5 .2 20
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=420}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=casting,scores={atk_cool=401}] at @s run particle minecraft:soul_fire_flame ~ ~ ~ .5 1 .5 .2 20
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=401}] at @s if entity @a[distance=..22] run effect clear @a[distance=..22] minecraft:slowness
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=401}] at @s if entity @a[distance=..22] run effect clear @a[distance=..22] minecraft:weakness
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=401}] at @s run effect clear @s minecraft:slowness
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=401}] at @s run function voa:boss/phase2/tome_chaos
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=401}] at @s run function voa:boss/phase2/tome_harmony_cast
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=401}] at @s run tag @s remove tomec
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=401}] at @s run tag @s remove tomeh
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=400}] at @s run tag @s remove casting

#Casting - General Loop
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=100}] at @s run tag @s add casting
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=100}] at @s run function voa:boss/phase2/tome_choice
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=100}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=100}] at @s if entity @a[distance=..22] run effect give @a[distance=..22] minecraft:slowness 40 3
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=100}] at @s if entity @a[distance=..22] run effect give @a[distance=..22] minecraft:weakness 40 3
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=100}] at @s run effect give @s minecraft:slowness 40 3
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=80}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=60}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=40}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=20}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=1}] at @s if entity @a[distance=..22] run effect clear @a[distance=..22] minecraft:slowness
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=1}] at @s if entity @a[distance=..22] run effect clear @a[distance=..22] minecraft:weakness
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=1}] at @s run effect clear @s minecraft:slowness

#Casting - Chaos Tome
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=99}] at @s run particle minecraft:cloud ~ ~ ~ .5 1 .5 .2 20
execute as @a[] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=99},distance=..22] run particle minecraft:dragon_breath ~ ~1 ~ .65 .5 .65 .0005 15
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=80}] at @s run particle minecraft:cloud ~ ~ ~ .5 1 .5 .2 20
execute as @a[] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=80},distance=..22] run particle minecraft:dragon_breath ~ ~1 ~ .65 .5 .65 .0005 15
#execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=60}] at @s run say chaos! 
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=60}] at @s run particle minecraft:cloud ~ ~ ~ .5 1 .5 .2 20
execute as @a[] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=60},distance=..22] run particle minecraft:dragon_breath ~ ~1 ~ .65 .5 .65 .0005 15
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=40}] at @s run particle minecraft:cloud ~ ~ ~ .5 1 .5 .2 20
execute as @a[] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=40},distance=..22] run particle minecraft:dragon_breath ~ ~1 ~ .65 .5 .65 .0005 15
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=20}] at @s run particle minecraft:cloud ~ ~ ~ .5 1 .5 .2 20
execute as @a[] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=20},distance=..22] run particle minecraft:dragon_breath ~ ~1 ~ .65 .5 .65 .0005 15
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=1}] at @s run particle minecraft:cloud ~ ~ ~ .5 1 .5 .2 20
execute as @a[] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=1},distance=..22] run particle minecraft:dragon_breath ~ ~1 ~ .65 .5 .65 .0005 15
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=1}] at @s run function voa:boss/phase2/tome_chaos
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=1}] at @s run tag @s remove tomec

#Casting - Lucky Tome
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomel,scores={atk_cool=99}] at @s run particle minecraft:happy_villager ~ ~ ~ .5 1 .5 .2 20 
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomel,scores={atk_cool=80}] at @s run particle minecraft:happy_villager ~ ~ ~ .5 1 .5 .2 20 
#execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomel,scores={atk_cool=60}] at @s run say lucky!
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomel,scores={atk_cool=60}] at @s run particle minecraft:happy_villager ~ ~ ~ .5 1 .5 .2 20 
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomel,scores={atk_cool=40}] at @s run particle minecraft:happy_villager ~ ~ ~ .5 1 .5 .2 20 
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomel,scores={atk_cool=1}] at @s run particle minecraft:happy_villager ~ ~ ~ .5 1 .5 .2 20 
execute as @a[] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomel,scores={atk_cool=1},distance=..40] run function voa:boss/phase2/tome_lucky
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomel,scores={atk_cool=1}] at @s run tag @s remove tomel
execute as @e[type=minecraft:bat,tag=lucky_bat,scores={atk_cool=3}] at @s run effect give @a[distance=..5] minecraft:instant_damage 1 1
execute as @e[type=minecraft:bat,tag=lucky_bat,scores={atk_cool=2}] at @s run summon fireball ~ ~ ~ {HasVisualFire:1b,ExplosionPower:1b,Motion:[0.0,-4.0,0.0]}
execute as @e[type=minecraft:bat,tag=lucky_bat,scores={atk_cool=1}] at @s run kill @s

#Casting - Harmony Tome
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=99}] at @s run particle minecraft:heart ~ ~ ~ .5 1 .5 .2 20 
#execute as @a[] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=99},distance=..40] run function voa:boss/phase2/tome_harmony
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=80}] at @s run particle minecraft:heart ~ ~ ~ .5 1 .5 .2 20 
#execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=60}] at @s run say harmony! 
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=60}] at @s run particle minecraft:heart ~ ~ ~ .5 1 .5 .2 20 
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=40}] at @s run particle minecraft:heart ~ ~ ~ .5 1 .5 .2 20 
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=20}] at @s run particle minecraft:heart ~ ~ ~ .5 1 .5 .2 20 
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=1}] at @s run particle minecraft:heart ~ ~ ~ .5 1 .5 .2 20 
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=1}] at @s run function voa:boss/phase2/tome_harmony_cast
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=1}] at @s run tag @s remove tomeh

#Casting - General Loop - Continued
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=1}] at @s if entity @a[distance=..22] run tp @s @r[distance=..22]
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=1}] at @s run particle minecraft:smoke ~ ~ ~ .5 1 .5 .2 20 
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=1}] at @s run tag @s remove casting
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=1}] at @s run function voa:boss/phase2/target_player
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=0}] at @s run scoreboard players set @s atk_cool 340


####Boss Utilities ---------------------------------------------------- >>
##Wither Shield - Boss
execute at @e[type=minecraft:zombified_piglin,tag=boss,tag=canattack] run function voa:boss/shield
##Boss Bar
execute store result bossbar bossbar:flower value as @e[type=minecraft:zombified_piglin,tag=flower,tag=boss,limit=1,sort=nearest] run data get entity @s Health
##Displaying Boss Bar
execute if entity @e[type=minecraft:zombified_piglin,tag=flower,tag=boss] run bossbar set bossbar:flower visible true
execute unless entity @e[type=minecraft:zombified_piglin,tag=flower,tag=boss] run bossbar set bossbar:flower visible false
execute unless entity @e[type=minecraft:zombified_piglin,tag=flower,tag=boss] run bossbar set bossbar:flower players
##Displaying Distance for Boss Bar
execute at @e[type=minecraft:zombified_piglin,tag=flower,tag=boss] run bossbar set bossbar:flower players @a[distance=..120]
#
##Gets Boss Health
data get entity @e[type=minecraft:zombified_piglin,tag=boss,tag=flower,sort=nearest,limit=1] Health

#
###Initializes Spectre Animation/Sound function
execute as @e[tag=boss,type=minecraft:zombified_piglin] at @s if entity @a[distance=..24] run function voa:boss/hurt
#
###Scoreboards - Im lazy so this countdown ALSO works for the Ender Demon
scoreboard players remove @e[tag=boss,type=minecraft:zombified_piglin,scores={atk_cool=1..}] atk_cool 1
scoreboard players remove @e[tag=boss,type=minecraft:zombified_piglin,scores={boss_cool=1..}] boss_cool 1
scoreboard players remove @e[type=minecraft:armor_stand,tag=boss_potion,scores={atk_cool=1..}] atk_cool 1
scoreboard players remove @e[type=minecraft:armor_stand,tag=boss_potion2,scores={atk_cool=1..}] atk_cool 1
scoreboard players remove @e[type=minecraft:armor_stand,tag=boss_potion3,scores={atk_cool=1..}] atk_cool 1
scoreboard players remove @e[type=minecraft:armor_stand,tag=boss_potion4,scores={atk_cool=1..}] atk_cool 1
scoreboard players remove @e[type=minecraft:bat,tag=lucky_bat,scores={atk_cool=1..}] atk_cool 1


#----------------------------------------------------------------------------------- Petal/Boss Fight------------------------------------------------------------------------------>

##Summon Petal ---------------------------------------------------- >>
#Armor-Stand Spectre Spawn#
execute as @e[type=minecraft:armor_stand,tag=spawnpetal,tag=!summoned] at @s if entity @a[distance=..70] run function voa:petal/spawnpetal
#TP - Holds Boss in Middle of room
execute as @e[type=minecraft:armor_stand,tag=spawnpetal,tag=summoned] at @s run tp @e[type=zombified_piglin,tag=petal,limit=1,sort=nearest,distance=..100] ~ ~ ~
#Reward Upon Death
execute as @e[type=minecraft:armor_stand,tag=spawnpetal,tag=summoned] at @s unless entity @e[tag=petal,distance=..20] run function voa:petal/reward

#execute as @e[type=minecraft:armor_stand,tag=spawnpetal,tag=summoned] at @s run kill @s

##Petal ---------------------------------------------------- >>
execute as @e[type=minecraft:zombified_piglin,tag=petal] at @s run function voa:petal/petal_action

##Bomb Attacks ---------------------------------------------------- >>
#Outter Bombs - All Bombs
execute as @e[type=minecraft:armor_stand,tag=bomb_attack] at @s run particle minecraft:crit ~ ~ ~ .2 .5 .2 .2 10 normal
#Outter Bombs - STUN
execute as @e[type=minecraft:armor_stand,tag=bomb_attack,tag=stun,scores={atk_cool=2}] at @s run function voa:petal/stun_bomb
#Outter Bombs - TNT
execute as @e[type=minecraft:armor_stand,tag=bomb_attack,tag=explode,scores={atk_cool=37}] at @s run playsound minecraft:entity.tnt.primed ambient @a ~ ~ ~ 2
execute as @e[type=minecraft:armor_stand,tag=bomb_attack,tag=explode,scores={atk_cool=2}] at @s run summon tnt ~ ~ ~ {fuse:0}
#Outter Bombs - All Bombs
execute as @e[type=minecraft:armor_stand,tag=bomb_attack,scores={atk_cool=..1}] at @s run kill @s

#Wither Bomb (Inner)
execute as @e[type=minecraft:armor_stand,tag=wither_bomb_attack] at @s run particle minecraft:crit ~ ~ ~ .2 .5 .2 .2 10 normal
execute as @e[type=minecraft:armor_stand,tag=wither_bomb_attack,scores={atk_cool=2}] at @s run summon armor_stand ~ ~ ~ {NoGravity:1b,Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["wither_pot_act"]}
execute as @e[type=minecraft:armor_stand,tag=wither_pot_act] at @s run function voa:petal/wither_bomb_explode
execute as @e[type=minecraft:armor_stand,tag=wither_bomb_attack,scores={atk_cool=..1}] at @s run kill @s

#Bomb Countdown
scoreboard players remove @e[type=minecraft:armor_stand,tag=bomb_attack,scores={atk_cool=1..}] atk_cool 1
scoreboard players remove @e[type=minecraft:armor_stand,tag=wither_bomb_attack,scores={atk_cool=1..}] atk_cool 1

####Boss Utilities ---------------------------------------------------- >>
#Is a Player in Petals Arena;
execute as @e[type=minecraft:armor_stand,tag=petal_lair_detection,tag=!lock_in] at @s if entity @a[dx=28,dy=7,dz=28] run function voa:petal/lair_marker/lock_in
execute as @e[type=minecraft:armor_stand,tag=petal_lair_detection,tag=lock_in] at @s unless entity @a[dx=28,dy=7,dz=28] run function voa:petal/lair_marker/tag_out
#Is a Player in Petals Island - Damage Field;
execute as @e[type=minecraft:armor_stand,tag=petal_isle_detection] at @s if entity @a[dx=48,dy=48,dz=48] run effect give @a[dx=48,dy=48,dz=48] minecraft:darkness 3 1
execute as @e[type=minecraft:armor_stand,tag=petal_isle_detection] at @s if entity @a[dx=48,dy=48,dz=48] run effect give @a[dx=48,dy=48,dz=48] minecraft:wither 1 1
execute as @e[type=minecraft:armor_stand,tag=petal_isle_detection,tag=petal_summoned] at @s unless entity @e[type=end_crystal,tag=petal_phase,distance=..90] if entity @a[distance=..90] run kill @s

#Target-able Players
execute as @e[type=minecraft:armor_stand,tag=petal_lair_detection] at @s if entity @a[dx=28,dy=7,dz=28,tag=!cantarget] run tag @a[dx=28,dy=7,dz=28,tag=!cantarget] add cantarget
execute as @a[tag=cantarget] at @s unless entity @e[type=minecraft:armor_stand,tag=petal_lair_detection,distance=..40,tag=lock_in] run tag @s[tag=cantarget] remove cantarget
#Slow Field
execute as @e[type=minecraft:armor_stand,tag=petal_lava_field] at @s run particle minecraft:large_smoke ~9 ~ ~9 5 3 5 .01 30
execute as @e[type=minecraft:armor_stand,tag=petal_lava_field] at @s run effect give @a[dx=18, dy=3, dz=18] minecraft:slowness 1 4

##Wither Shield - Boss - Just uses Particles.
execute at @e[type=minecraft:zombified_piglin,tag=petal,tag=!playerinlair] run function voa:boss/shield


##Boss Bar
execute store result bossbar bossbar:petal value as @e[type=minecraft:zombified_piglin,tag=petal] run data get entity @s Health
##Displaying Boss Bar
execute if entity @e[type=minecraft:zombified_piglin,tag=petal] run bossbar set bossbar:petal visible true
execute unless entity @e[type=minecraft:zombified_piglin,tag=petal] run bossbar set bossbar:petal visible false
execute unless entity @e[type=minecraft:zombified_piglin,tag=petal] run bossbar set bossbar:petal players 
##Displaying Distance for Boss Bar
execute at @e[type=minecraft:zombified_piglin,tag=petal] run bossbar set bossbar:petal players @a[distance=..120]



