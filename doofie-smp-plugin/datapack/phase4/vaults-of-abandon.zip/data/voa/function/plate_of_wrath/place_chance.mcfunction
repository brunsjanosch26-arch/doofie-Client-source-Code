#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# AS AND AT POSITION of custom item frame 
#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 2
function voa:natural_generation/random/range_lcg

#If 1 is selected, the following happens 
execute if score out math matches 2 run summon item_frame ~ ~ ~ {CustomNameVisible:0b,Facing:1b,Invulnerable:1b,Invisible:1b,Fixed:1b,Tags:["wrath"],CustomName:'"Plate of Wrath"',Item:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":{floats:[222222]}}}}


tag @s add summoned
