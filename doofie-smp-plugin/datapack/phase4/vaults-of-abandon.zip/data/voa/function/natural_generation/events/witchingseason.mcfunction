#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

playsound minecraft:entity.witch.ambient hostile @a[distance=..16] ~ ~ ~ 3
playsound minecraft:entity.witch.ambient hostile @a[distance=..16] ~ ~ ~ 3
playsound minecraft:entity.witch.ambient hostile @a[distance=..16] ~ ~ ~ 3
summon witch ~ ~ ~ {CustomNameVisible:1b,DeathLootTable:"voa:entities/grand_witch",PersistenceRequired:1b,Health:125f,Tags:["voa"],CustomName:{"bold":true,"color":"red","text":"Elder Witch"},equipment:{head:{id:"minecraft:beetroot",count:1,components:{"minecraft:custom_model_data":{floats:[767676]}}}},attributes:[{id:"minecraft:max_health",base:125},{id:"minecraft:movement_speed",base:0.38}]}
effect give @a[distance=..16] minecraft:slowness 20 1