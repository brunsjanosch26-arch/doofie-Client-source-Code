#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

scoreboard players add @e[tag=witchevent,type=minecraft:armor_stand] atk_cool 20

tag @s add witchscore