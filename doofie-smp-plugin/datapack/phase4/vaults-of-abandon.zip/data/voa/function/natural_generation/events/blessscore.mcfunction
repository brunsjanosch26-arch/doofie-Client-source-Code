#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

scoreboard players add @e[tag=blessevent,type=minecraft:armor_stand] atk_cool 10

tag @s add blesscore