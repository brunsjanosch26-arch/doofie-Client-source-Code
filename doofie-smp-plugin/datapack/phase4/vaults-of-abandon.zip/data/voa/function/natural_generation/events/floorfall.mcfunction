#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Spawn Spawner
playsound minecraft:entity.zombie.break_wooden_door hostile @a[] ~ ~ ~ 2

#Floor Falls
setblock ~ ~-1 ~ gravel
setblock ~1 ~-1 ~ gravel
setblock ~-1 ~-1 ~ gravel
setblock ~ ~-1 ~1 gravel
setblock ~ ~-1 ~-1 gravel

particle minecraft:explosion ~ ~1 ~ 5 4 5 .0000000008 200 normal

#kills Marker
tag @s add summoned