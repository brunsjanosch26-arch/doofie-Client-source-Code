#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Spawn Spawner
playsound minecraft:block.fire.extinguish hostile @a[] ~ ~ ~ 2
playsound minecraft:block.sculk_shrieker.shriek hostile @a[] ~ ~ ~ 2
playsound minecraft:block.sculk_sensor.clicking hostile @a[] ~ ~ ~ 2

effect give @a[distance=..8] minecraft:slowness 15 5
effect give @a[distance=..8] minecraft:instant_damage 1 2

#Hatches Eggs Nearby if possible.
tag @s add setforgila

execute as @e[type=minecraft:armor_stand,tag=gila_egg,tag=!hatched] at @s if entity @e[type=minecraft:armor_stand,tag=snare,tag=setforgila,distance=..8] run function voa:gila/gila_spawn_hatch

#kills Marker
tag @s add summoned