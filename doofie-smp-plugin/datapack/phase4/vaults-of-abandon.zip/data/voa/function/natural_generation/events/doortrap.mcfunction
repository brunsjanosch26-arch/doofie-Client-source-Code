#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Spawn Spawner
playsound minecraft:block.fire.extinguish hostile @a[] ~ ~ ~ 2
playsound minecraft:block.sculk_shrieker.shriek hostile @a[] ~ ~ ~ 2
playsound minecraft:block.sculk_sensor.clicking hostile @a[] ~ ~ ~ 2

effect give @a[distance=..8] minecraft:slowness 10 5
effect give @a[distance=..8] minecraft:weakness 10 0
effect give @a[distance=..8] minecraft:instant_damage 1 2

summon armor_stand ~ ~ ~ {NoGravity:1b,Silent:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["spawnreaper100"]}

#kills Marker
tag @s add summoned