#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Staircase
fill ~ ~ ~ ~ ~-17 ~ minecraft:spruce_log replace sponge
fill ~ ~ ~ ~ ~-17 ~ minecraft:spruce_log replace wet_sponge

tag @s add summoned