#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#say Spawn Southhall Cap Boss (Far) QCCCC


###---- SPAWNS ROOOOOOOMS ------------------------------------------#

#South
##Spawns South Hallway - Attached to Middle Cap
#Spawns South Endcap - OUTER  
setblock ~ ~7 ~34 minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -23, mode: "LOAD", posY: -15, sizeX: 47, posZ: 1, integrity: 1.0f, showair: 0b, name: "voa:brickhallcapboss", id: "minecraft:structure_block", sizeY: 22, sizeZ: 47, showboundingbox: 1b}
#Always Spawns Redstone
setblock ~ ~8 ~34 minecraft:redstone_block


###---- SPAWNS AIR ------------------------------------------#

#South
##Air South Hallway - Attached to Middle Cap
#Air South Endcap - OUTER  
setblock ~ ~7 ~34 minecraft:air
setblock ~ ~8 ~34 minecraft:air

#Summon Tag - Only Spawns Once
tag @s add summoned
scoreboard players add @e[tag=qcsouth,type=minecraft:armor_stand,sort=nearest,limit=1] buildingtime 30
