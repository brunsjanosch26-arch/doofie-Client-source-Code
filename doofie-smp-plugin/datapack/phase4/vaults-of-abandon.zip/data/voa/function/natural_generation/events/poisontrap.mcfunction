#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Spawn Spawner
playsound minecraft:block.fire.extinguish hostile @a[] ~ ~ ~ 1
playsound minecraft:entity.splash_potion.break hostile @a[] ~ ~ ~ 1

effect give @a[distance=..12] minecraft:poison 20 1
effect give @a[distance=..12] minecraft:blindness 20 1
effect give @a[distance=..12] minecraft:infested 20 1

particle minecraft:explosion ~ ~1 ~ 5 4 5 .0000000008 200 normal

#Spawns Titan Nearby if possible.
tag @s add setfortitan

execute as @e[tag=titantrap] at @s if entity @e[tag=poison,tag=setfortitan,distance=..24] run summon armor_stand ~ ~ ~ {Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["spawntitan100"]}
execute as @e[tag=titantrap] at @s if entity @e[tag=poison,tag=setfortitan,distance=..24] run playsound minecraft:titan.mob.wail hostile @a ~ ~ ~ 2
execute as @e[tag=titantrap] at @s if entity @e[tag=poison,tag=setfortitan,distance=..24] run playsound minecraft:entity.generic.explode hostile @a[] ~ ~ ~ 2

#kills Marker
tag @s add summoned