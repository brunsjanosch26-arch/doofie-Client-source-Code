#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 2
function voa:natural_generation/random/range_lcg

#Result Run
#Potion- 
execute if score out math matches 1 run summon shulker ~ ~ ~ {AttachFace:0b}
tag @s add summoned