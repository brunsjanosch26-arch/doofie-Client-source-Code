#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

summon armor_stand ~ 65 ~ {Tags:["spawnoblisk"]}

tag @s add spawnvaultgen

