#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Spawn Spawner
playsound minecraft:entity.firework_rocket.large_blast_far hostile @a[] ~ ~ ~ 3
playsound minecraft:entity.firework_rocket.launch hostile @a[] ~ ~ ~ 1

effect give @p minecraft:levitation 2 20
effect give @p minecraft:blindness 5 1
effect give @p minecraft:wither 5 2
effect give @p minecraft:instant_damage 1 0

particle minecraft:firework ~ ~1 ~ 1 1 1 .1 200 normal

tag @s add summoned
