#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

summon armor_stand ~ 61 ~ {Tags:["market_start"]}

tag @s add spawnvaultgen

