#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

summon armor_stand ~ 130 ~ {NoGravity:1b,Marker:1b,Invisible:1b,Tags:["marina"]}
summon armor_stand ~ 130 ~ {NoGravity:1b,Marker:1b,Invisible:1b,Tags:["marina_start"]}

tag @s add spawnvaultgen

