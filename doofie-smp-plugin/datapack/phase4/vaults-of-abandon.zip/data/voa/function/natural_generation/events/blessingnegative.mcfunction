#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

playsound minecraft:ambient.cave hostile @a[] ~ ~ ~ 2
particle minecraft:angry_villager ~ ~1 ~2 1 1 1 .05 20
effect give @a[distance=..16] minecraft:weakness 90 2
effect give @a[distance=..16] minecraft:instant_damage 1 1
effect give @a[distance=..16] minecraft:mining_fatigue 90 2
summon armor_stand ~3 ~ ~ {NoGravity:1b,Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["spawntitan100"]}
summon armor_stand ~-3 ~ ~ {NoGravity:1b,Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["spawntitan100"]}

tag @s add summoned