#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#say Spawn Northhall Cap (Close)

###---- SPAWNS ROOOOOOOMS ------------------------------------------#

#Vault Start
##Spawns North Hallway - Atttached to Vault Start
#setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -16, mode: "LOAD", posY: -15, sizeX: 33, posZ: -48, integrity: 1.0f, showair: 0b, name: "voa:brickhallnorthsouth", id: "minecraft:structure_block", sizeY: 22, sizeZ: 47, showboundingbox: 1b}
##Always Spawns Redstone
#setblock ~ ~1 ~ minecraft:redstone_block
#Spawns North Endcap - MIDDLE 
setblock ~ ~ ~-96 minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -23, mode: "LOAD", posY: -15, sizeX: 47, posZ: 1, integrity: 1.0f, showair: 0b, name: "voa:brickhallcap", id: "minecraft:structure_block", sizeY: 22, sizeZ: 47, showboundingbox: 1b}
#Always Spawns Redstone
setblock ~ ~1 ~-96 minecraft:redstone_block


###---- SPAWNS AIR ------------------------------------------#

#Vault Start
##North Starting Hallway Air
#setblock ~ ~1 ~ minecraft:air
#setblock ~ ~ ~ minecraft:air
#Air North Endcap - MIDDLE 
setblock ~ ~ ~-96 minecraft:air
setblock ~ ~1 ~-96 minecraft:air
