#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

playsound minecraft:entity.player.levelup ambient @a[]
particle minecraft:happy_villager ~ ~1 ~2 .5 1 .5 1 30
effect give @a[distance=..16] minecraft:absorption 180 4
effect give @a[distance=..16] minecraft:instant_health 1 4
effect give @a[distance=..16] minecraft:regeneration 180 1
setblock ~2 ~1 ~2 chest{LootTable:"voa:blocks/vault_heavy"}
setblock ~1 ~1 ~2 minecraft:soul_lantern
setblock ~-1 ~1 ~2 minecraft:soul_lantern
summon item_frame ~-2 ~1 ~2 {CustomNameVisible:0b,Facing:1b,Invulnerable:1b,Invisible:1b,Fixed:1b,Tags:["wrath"],CustomName:"Plate of Wrath",Item:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":{floats:[222222]}}}}

#Only Summon Once
tag @s add summoned