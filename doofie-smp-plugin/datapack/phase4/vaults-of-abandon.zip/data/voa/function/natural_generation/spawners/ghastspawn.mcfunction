#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks



#If 1 is selected, the following happens
#setblock ~ ~ ~ spawner{MaxNearbyEntities:24,RequiredPlayerRange:80,SpawnData:{entity:{id:"minecraft:ghast"}}} replace
summon end_crystal ~ ~ ~ {Tags:["ghast_post_spawner"]}
summon ghast ~ ~8 ~

### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
scoreboard players add @e[tag=ghast_post_spawner,type=minecraft:end_crystal,tag=!stats] atk_cool 0

#Stats
execute as @e[tag=ghast_post_spawner,type=minecraft:end_crystal,tag=!stats] at @s run tag @s add stats

#Spawns Once
tag @s add summoned