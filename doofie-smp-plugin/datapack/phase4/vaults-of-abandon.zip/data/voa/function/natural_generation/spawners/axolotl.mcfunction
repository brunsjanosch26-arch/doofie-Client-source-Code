#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks


#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 5
function voa:natural_generation/random/range_lcg


#Result Run
execute if score out math matches 4 run summon minecraft:glow_squid ~ ~ ~
execute if score out math matches 5 run summon minecraft:axolotl ~ ~ ~






tag @s add summoned