#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Spawn Spawner
playsound minecraft:block.fire.extinguish hostile @a[] ~ ~ ~ 1
playsound minecraft:entity.splash_potion.break hostile @a[] ~ ~ ~ 1

effect give @a[distance=..12] minecraft:poison 20 1
effect give @a[distance=..12] minecraft:blindness 20 1

particle minecraft:explosion ~ ~1 ~ 5 4 5 .0000000008 200 normal

tag @s add summoned
