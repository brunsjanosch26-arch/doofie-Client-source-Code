#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

scoreboard players set in math 0
scoreboard players set in1 math 1
function voa:natural_generation/random/range_lcg

execute if score out math matches 0 run setblock ~ ~ ~ minecraft:stone_pressure_plate 

execute if score out math matches 0 run summon armor_stand ~ ~ ~ {NoGravity:1b,Silent:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["levi"]}

tag @s add summoned