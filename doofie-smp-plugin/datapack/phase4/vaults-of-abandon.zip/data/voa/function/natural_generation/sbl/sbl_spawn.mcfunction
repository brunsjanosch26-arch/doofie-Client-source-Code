#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 5
function voa:natural_generation/random/range_lcg

#Spawn Room
#If 1 is selected, the following happens
execute if score out math matches 0 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -4, mode: "LOAD", posY: -1, sizeX: 9, posZ: -4, integrity: 1.0f, showair: 0b, name: "voa:sbl1", id: "minecraft:structure_block", sizeY: 22, sizeZ: 9, showboundingbox: 1b}
execute if score out math matches 1 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -4, mode: "LOAD", posY: -1, sizeX: 9, posZ: -4, integrity: 1.0f, showair: 0b, name: "voa:sbl2", id: "minecraft:structure_block", sizeY: 22, sizeZ: 9, showboundingbox: 1b}
execute if score out math matches 2 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -4, mode: "LOAD", posY: -1, sizeX: 9, posZ: -4, integrity: 1.0f, showair: 0b, name: "voa:sbl3", id: "minecraft:structure_block", sizeY: 22, sizeZ: 9, showboundingbox: 1b}
execute if score out math matches 3 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -4, mode: "LOAD", posY: -1, sizeX: 9, posZ: -4, integrity: 1.0f, showair: 0b, name: "voa:sbl4", id: "minecraft:structure_block", sizeY: 22, sizeZ: 9, showboundingbox: 1b}
execute if score out math matches 4 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -4, mode: "LOAD", posY: -1, sizeX: 9, posZ: -4, integrity: 1.0f, showair: 0b, name: "voa:sbl5", id: "minecraft:structure_block", sizeY: 22, sizeZ: 9, showboundingbox: 1b}
execute if score out math matches 5 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -4, mode: "LOAD", posY: -1, sizeX: 9, posZ: -4, integrity: 1.0f, showair: 0b, name: "voa:sbl6", id: "minecraft:structure_block", sizeY: 22, sizeZ: 9, showboundingbox: 1b}


#Always Spawns Redstone
setblock ~ ~1 ~ minecraft:redstone_block

tag @s add summoned