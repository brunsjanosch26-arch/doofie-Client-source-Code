#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 4
function voa:natural_generation/random/range_lcg

#If 1 is selected, the following happens
execute if score out math matches 0 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:breeze"}}}
execute if score out math matches 1 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:blaze"}}}
execute if score out math matches 2 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:blaze"}}}
execute if score out math matches 3 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:phantom",Tags:["voa"],Passengers:[{id:"minecraft:stray",DeathLootTable:"voa:entities/end/ethereal_watcher",CustomName:"Ethereal Wingman",equipment:{head:{id:"minecraft:beetroot",count:1,components:{"minecraft:custom_model_data":{floats:[777777]}}},mainhand:{id:"minecraft:bow",count:1,components:{"minecraft:enchantments":{"power":6,"punch":2}}}},drop_chances:{head:0.000,mainhand:0.000}}]}}}

tag @s add summoned