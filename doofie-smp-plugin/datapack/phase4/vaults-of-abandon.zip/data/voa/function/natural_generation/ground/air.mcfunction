#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#say AIR!

tag @s add wehaveair
