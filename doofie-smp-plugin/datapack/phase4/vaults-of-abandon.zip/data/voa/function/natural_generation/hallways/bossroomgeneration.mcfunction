#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#say Spawn (GirlBoss <3) Loaded

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 1
function voa:natural_generation/random/range_lcg

execute if score out math matches 0 run tag @e[type=minecraft:armor_stand,tag=vaultnorthhallway,tag=!summoned,distance=..30,sort=nearest,limit=1] add bossnorth
#execute if score out math matches 0 run say GirlBossNorth <3
execute if score out math matches 1 run tag @e[type=minecraft:armor_stand,tag=vaultsouthhallway,tag=!summoned,distance=..30,sort=nearest,limit=1] add bosssouth
#execute if score out math matches 1 run say NotVeryCashMoneySouth
