#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#B-E-A-G-L-E-B-L-O-C-K-S

#Summons Vault-Start
setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -5, mode: "LOAD", posY: -32, sizeX: 11, posZ: -5, integrity: 1.0f, showair: 0b, name: "voa:vault-start", id: "minecraft:structure_block", sizeY: 22, sizeZ: 11, showboundingbox: 1b}
setblock ~ ~1 ~ minecraft:redstone_block
setblock ~ ~ ~ minecraft:air
setblock ~ ~1 ~ minecraft:air

tag @s add summoned