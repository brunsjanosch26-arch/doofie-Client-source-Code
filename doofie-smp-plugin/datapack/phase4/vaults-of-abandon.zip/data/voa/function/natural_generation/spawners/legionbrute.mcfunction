#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 5
function voa:natural_generation/random/range_lcg

#Result Run
execute if score out math matches 1 run summon stray ~ ~ ~ {DeathLootTable:"voa:entities/legion_loot",PersistenceRequired:1b,Health:45f,Tags:["voa"],CustomName:"Legionnaire Brute",equipment:{chest:{id:"minecraft:netherite_chestplate",count:1},head:{id:"minecraft:beetroot",count:1,components:{"minecraft:custom_model_data":{floats:[767676]}}},mainhand:{id:"minecraft:netherite_axe",count:1}},drop_chances:{chest:0.000,head:0.000,mainhand:0.000},attributes:[{id:"minecraft:follow_range",base:16},{id:"minecraft:max_health",base:45},{id:"minecraft:movement_speed",base:0.28}]}
execute if score out math matches 2 run summon stray ~ ~ ~ {DeathLootTable:"voa:entities/legion_loot",PersistenceRequired:1b,Health:45f,Tags:["voa"],CustomName:"Legionnaire Brute",equipment:{chest:{id:"minecraft:netherite_chestplate",count:1,components:{"minecraft:trim":{material:"minecraft:gold",pattern:"minecraft:rib"}}},head:{id:"minecraft:beetroot",count:1,components:{"minecraft:custom_model_data":{floats:[767676]}}},mainhand:{id:"minecraft:netherite_axe",count:1,components:{"minecraft:enchantments":{"minecraft:sharpness":2}}}},drop_chances:{chest:0.000,head:0.000,mainhand:0.000},attributes:[{id:"minecraft:follow_range",base:16},{id:"minecraft:max_health",base:45},{id:"minecraft:movement_speed",base:0.29}]}
execute if score out math matches 3 run summon stray ~ ~ ~ {DeathLootTable:"voa:entities/legion_loot",PersistenceRequired:1b,Health:45f,Tags:["voa"],CustomName:"Legionnaire Brute",equipment:{chest:{id:"minecraft:netherite_chestplate",count:1,components:{"minecraft:trim":{material:"minecraft:diamond",pattern:"minecraft:rib"}}},head:{id:"minecraft:beetroot",count:1,components:{"minecraft:custom_model_data":{floats:[767676]}}},mainhand:{id:"minecraft:netherite_axe",count:1,components:{"minecraft:enchantments":{"minecraft:sharpness":4}}}},drop_chances:{chest:0.000,head:0.000,mainhand:0.000},attributes:[{id:"minecraft:follow_range",base:16},{id:"minecraft:max_health",base:45},{id:"minecraft:movement_speed",base:0.3}]}

tag @s add summoned