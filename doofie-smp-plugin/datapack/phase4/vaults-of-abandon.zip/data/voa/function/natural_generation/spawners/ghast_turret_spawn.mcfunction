#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks



#If 1 is selected, the following happens
summon ghast ~ ~8 ~

### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
scoreboard players set @s atk_cool 1800
