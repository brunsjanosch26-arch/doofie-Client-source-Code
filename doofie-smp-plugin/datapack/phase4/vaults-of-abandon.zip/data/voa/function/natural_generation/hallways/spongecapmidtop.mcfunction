#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#say Sponge Cap Mid/Top Clearance

fill ~ ~ ~ ~47 ~13 ~47 minecraft:air replace minecraft:sponge
fill ~ ~ ~ ~47 ~13 ~47 minecraft:air replace minecraft:wet_sponge

#Summon Tag - Only Spawns Once
tag @s add summoned

