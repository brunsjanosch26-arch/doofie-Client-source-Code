#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 6
function voa:natural_generation/random/range_lcg

#Spawn Room
#If 1 is selected, the following happens
execute if score out math matches 0 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: -1, sizeX: 7, posZ: -6, integrity: 1.0f, showair: 0b, name: "voa:garden1", id: "minecraft:structure_block", sizeY: 6, sizeZ: 12, showboundingbox: 1b}
execute if score out math matches 1 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: -1, sizeX: 7, posZ: -6, integrity: 1.0f, showair: 0b, name: "voa:garden2", id: "minecraft:structure_block", sizeY: 6, sizeZ: 12, showboundingbox: 1b}
execute if score out math matches 2 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: -1, sizeX: 7, posZ: -6, integrity: 1.0f, showair: 0b, name: "voa:garden3", id: "minecraft:structure_block", sizeY: 6, sizeZ: 12, showboundingbox: 1b}
execute if score out math matches 3 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: -1, sizeX: 7, posZ: -6, integrity: 1.0f, showair: 0b, name: "voa:garden4", id: "minecraft:structure_block", sizeY: 6, sizeZ: 12, showboundingbox: 1b}
execute if score out math matches 4 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: -1, sizeX: 7, posZ: -6, integrity: 1.0f, showair: 0b, name: "voa:garden5", id: "minecraft:structure_block", sizeY: 6, sizeZ: 12, showboundingbox: 1b}
execute if score out math matches 5 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: -1, sizeX: 7, posZ: -6, integrity: 1.0f, showair: 0b, name: "voa:garden6", id: "minecraft:structure_block", sizeY: 6, sizeZ: 12, showboundingbox: 1b}
execute if score out math matches 6 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: -1, sizeX: 7, posZ: -6, integrity: 1.0f, showair: 0b, name: "voa:garden7", id: "minecraft:structure_block", sizeY: 6, sizeZ: 12, showboundingbox: 1b}


#Always Spawns Redstone
setblock ~ ~1 ~ minecraft:redstone_block

tag @s add summoned