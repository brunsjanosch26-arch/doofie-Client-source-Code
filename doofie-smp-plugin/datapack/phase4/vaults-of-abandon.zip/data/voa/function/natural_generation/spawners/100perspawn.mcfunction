#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 10
function voa:natural_generation/random/range_lcg

#The following happens
execute if score out math matches 0 run setblock ~ ~ ~ spawner{SpawnData:{entity:{id:"minecraft:zombie",Tags:["no_hh"]}}} replace
execute if score out math matches 1 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:skeleton"}}}
execute if score out math matches 2 run setblock ~ ~ ~ spawner{SpawnData:{entity:{id:"minecraft:zombie",Tags:["no_hh"]}}} replace
execute if score out math matches 3 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:skeleton"}}}
execute if score out math matches 4 run setblock ~ ~ ~ spawner{SpawnData:{entity:{id:"minecraft:zombie",Tags:["no_hh"]}}} replace
execute if score out math matches 5 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:skeleton"}}}
execute if score out math matches 6 run setblock ~ ~ ~ spawner{SpawnData:{entity:{id:"minecraft:zombie",Tags:["no_hh"]}}} replace
execute if score out math matches 7 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:skeleton"}}}
execute if score out math matches 8 run setblock ~ ~ ~ spawner{SpawnData:{entity:{id:"minecraft:zombie",Tags:["no_hh"]}}} replace
execute if score out math matches 9 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:skeleton"}}}
execute if score out math matches 10 run setblock ~ ~ ~ spawner{SpawnData:{entity:{id:"minecraft:skeleton",CustomNameVisible:0b,DeathLootTable:"voa:entities/guardian_loot",Health:35f,Tags:["s_knight","voa"],CustomName:"Vault Guardian",equipment:{feet:{id:"minecraft:leather_boots",count:1,components:{"minecraft:dyed_color":2359296}},legs:{id:"minecraft:leather_leggings",count:1,components:{"minecraft:dyed_color":2359296}},chest:{id:"minecraft:leather_chestplate",count:1,components:{"minecraft:dyed_color":7208960}},head:{id:"minecraft:leather_helmet",count:1,components:{"minecraft:dyed_color":2359296}},mainhand:{id:"minecraft:iron_sword",count:1,components:{"minecraft:custom_model_data":{floats:[555555]}}}},drop_chances:{feet:0.000,legs:0.000,chest:0.000,head:0.000,mainhand:0.000},attributes:[{id:"minecraft:attack_damage",base:2},{id:"minecraft:attack_knockback",base:6},{id:"minecraft:knockback_resistance",base:0.45},{id:"minecraft:max_health",base:35},{id:"minecraft:movement_speed",base:0.21}]}}} replace

tag @s add summoned