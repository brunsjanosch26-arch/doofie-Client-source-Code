

#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#----------------------------------------------------------------------------------- Player Authentication ---------------------------------------------------------------------------------------------#
execute as @a[tag=!authenticated_voa5] at @s run function voa:player/authenticate
#say LOOOOP!

#Recipe Enabling
execute as @a[tag=!recipevoa] at @s run function voa:player/recipe


#----------------------------------------------------------------------------------- Alters/Plates/Benches ---------------------------------------------------------------------------------------------#
#--- Wealth Alter/Plate Start------------------------------------------------------------------------------>
#Plate of Wealth
execute as @e[type=minecraft:item_frame,tag=wealth,tag=!placed] at @s run function voa:plate_of_wealth/place
execute as @e[type=minecraft:item_frame,tag=wealth,tag=placed,tag=!used] at @s unless block ~ ~ ~ minecraft:quartz_slab run function voa:plate_of_wealth/remove
#Plate of Wealth END##


#Plate of Wrath
execute as @e[type=minecraft:item_frame,tag=wrath,tag=!placed] at @s run function voa:plate_of_wrath/place
execute as @e[type=minecraft:item_frame,tag=wrath,tag=placed,tag=!used] at @s unless block ~ ~ ~ minecraft:quartz_slab run function voa:plate_of_wrath/remove
#Plate of Wrath END##


#Plate of Fear
execute as @e[type=minecraft:item_frame,tag=fear,tag=!placed] at @s run function voa:plate_of_fear/place
execute as @e[type=minecraft:item_frame,tag=fear,tag=placed,tag=!used] at @s unless block ~ ~ ~ minecraft:quartz_slab run function voa:plate_of_fear/remove
#Plate of Fear END##


#Wealth Alter
execute as @e[type=minecraft:item_frame,tag=wealth_alter] at @s run function voa:wealth_alter/place
execute as @e[type=minecraft:armor_stand,tag=wealth_alter] at @s unless block ~ ~ ~ minecraft:bedrock run function voa:wealth_alter/remove
#Detects Plate of Abundance and runs the Loot Summon function!
execute as @e[type=minecraft:armor_stand,tag=wealth_alter] at @s if block ~ ~ ~ minecraft:bedrock if entity @e[distance=0..1.5,tag=wealth,tag=!used] run function voa:wealth_alter/summon
execute as @e[type=minecraft:armor_stand,tag=wealth_alter] at @s if block ~ ~ ~ minecraft:bedrock run kill @e[type=minecraft:item,tag=used,nbt={Item:{id:"minecraft:item_frame"}},distance=..2]
#Music for Vault 
#execute as @e[type=minecraft:armor_stand,tag=wealth_alter,tag=!nomusic] at @s if entity @e[distance=0..40,type=player] run function voa:wealth_alter/music
#Wealth Alter  END##


#Fear Alter
execute as @e[type=minecraft:item_frame,tag=fear_alter] at @s run function voa:fear_alter/place
execute as @e[type=minecraft:armor_stand,tag=fear_alter] at @s unless block ~ ~ ~ minecraft:bedrock run function voa:fear_alter/remove
execute as @e[type=minecraft:item_frame,tag=fear_alter_elite] at @s run function voa:fear_alter/elite_place
execute as @e[type=minecraft:armor_stand,tag=fear_alter_elite] at @s unless block ~ ~ ~ minecraft:bedrock run function voa:fear_alter/elite_remove

#Runs Trial if key is placed!
execute as @e[type=minecraft:armor_stand,tag=fear_alter,tag=!active_trial] at @s if block ~ ~ ~ minecraft:bedrock if entity @e[distance=0..1.5,tag=fear,tag=!used] run function voa:fear_alter/basic/summon
execute as @e[type=minecraft:armor_stand,tag=fear_alter] at @s if block ~ ~ ~ minecraft:bedrock run kill @e[type=minecraft:item,tag=used,nbt={Item:{id:"minecraft:item_frame"}},distance=..2]

#Checks Score
execute as @e[type=minecraft:armor_stand,tag=fear_alter,tag=active_trial,scores={end_trials_score=..20}] at @s unless entity @e[type=stray,tag=trial,distance=..60] run function voa:fear_alter/basic/summon_round
execute as @e[type=minecraft:armor_stand,tag=fear_alter,tag=active_trial,scores={end_trials_score=21}] at @s unless entity @e[type=stray,tag=trial,distance=..60] run function voa:fear_alter/basic/summon_round_boss

#Loot/Fail
execute as @e[type=minecraft:armor_stand,tag=fear_alter,tag=active_trial,scores={end_trials_score=24..}] at @s unless entity @e[type=stray,tag=trial,distance=..60] run function voa:fear_alter/basic/loot
execute as @e[type=minecraft:armor_stand,tag=fear_alter,scores={end_trials_loot_countdown=60}] at @s run function voa:fear_alter/basic/loot_sword
execute as @e[type=minecraft:armor_stand,tag=fear_alter,scores={end_trials_loot_countdown=40}] at @s run function voa:fear_alter/basic/loot_magic
execute as @e[type=minecraft:armor_stand,tag=fear_alter,scores={end_trials_loot_countdown=20}] at @s run function voa:fear_alter/basic/loot_armor
execute as @e[type=minecraft:armor_stand,tag=fear_alter,scores={end_trials_loot_countdown=1..}] at @s run particle minecraft:electric_spark ~0.5 ~ ~0.5 0.75 1 0.75 .1 30 normal


execute as @e[type=minecraft:armor_stand,tag=fear_alter,tag=active_trial] at @s unless entity @a[distance=..40] run function voa:fear_alter/basic/trial_fail


#Random Chaos
execute as @e[type=minecraft:armor_stand,tag=fear_alter,tag=active_trial,scores={end_trials_chaos=..1}] at @s run function voa:fear_alter/basic/chaos_marker
execute as @e[type=minecraft:armor_stand,tag=chaos_marker,scores={end_trials_chaos_countdown=..1}] at @s run function voa:fear_alter/basic/chaos
execute as @e[type=minecraft:armor_stand,tag=chaos_marker] at @s run particle minecraft:cloud ~ ~ ~ 0.25 0.25 0.25 .1 20
execute as @e[type=minecraft:armor_stand,tag=chaos_marker] at @s run playsound minecraft:ui.hud.bubble_pop ambient @a[] ~ ~ ~ 2

##Scoreboard
execute as @e[type=minecraft:armor_stand,tag=fear_alter,scores={end_trials_loot_countdown=1..}] at @s run scoreboard players remove @e[tag=fear_alter,scores={end_trials_loot_countdown=1..}] end_trials_loot_countdown 1
execute as @e[type=minecraft:armor_stand,tag=fear_alter,tag=active_trial,scores={end_trials_chaos=1..}] at @s if entity @a[distance=..40] run scoreboard players remove @e[tag=fear_alter,tag=active_trial,scores={end_trials_chaos=1..}] end_trials_chaos 1
scoreboard players remove @e[tag=chaos_marker] end_trials_chaos_countdown 1
#Fear Alter  END##


###Detecting Location
#execute as @e[type=minecraft:armor_stand,tag=fear_alter] at @s run particle minecraft:heart ~0.5 ~1 ~8.5
#execute as @e[type=minecraft:armor_stand,tag=fear_alter] at @s run particle minecraft:heart ~0.5 ~1 ~14.5
#execute as @e[type=minecraft:armor_stand,tag=fear_alter] at @s run particle minecraft:heart ~3.5 ~1 ~11.5
#execute as @e[type=minecraft:armor_stand,tag=fear_alter] at @s run particle minecraft:heart ~-2.5 ~1 ~11.5
##Fear Alter  END##

#Wrath Alter
execute as @e[type=minecraft:item_frame,tag=wrath_alter] at @s run function voa:wrath_alter/place
execute as @e[type=minecraft:armor_stand,tag=wrath_alter] at @s unless block ~ ~ ~ minecraft:bedrock run function voa:wrath_alter/remove
#Detects Dread Plate and runs the Boss Summon function! - Also makes it so that only one boss can be summoned at a time!
execute as @e[type=minecraft:armor_stand,tag=wrath_alter] at @s if entity @e[distance=..100,tag=boss,type=zombified_piglin] run tag @s add boss_active
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active] at @s unless entity @e[distance=..600,tag=boss,type=zombified_piglin] run function voa:boss/reward
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active] at @s unless entity @e[distance=..600,tag=boss,type=zombified_piglin] run tag @s remove boss_active

#Spawns Boss
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=!boss_active] at @s if block ~ ~ ~ minecraft:bedrock if entity @e[distance=0..1.5,tag=wrath,tag=!used] run function voa:boss/bossspawn

#TP - Holds Boss in Middle of room
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,limit=1,sort=nearest] at @s run tp @e[type=zombified_piglin,tag=boss,limit=1,sort=nearest,tag=phase1,distance=..200] ~7.5 ~ ~.5

#Phase One - Spook Spawn

#Alpha 1 function is called via bossspawn function
#ALPHA
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=alpha6,tag=alpha] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase1,tag=down,scores={boss_cool=..2},distance=..120] run function voa:boss/phase2/bossetup_phase2
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=alpha5,tag=alpha] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/alpha/alpha6
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=alpha4,tag=alpha] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/alpha/alpha5
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=alpha3,tag=alpha] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/alpha/alpha4
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=alpha2,tag=alpha] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/alpha/alpha3
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=alpha1,tag=alpha] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/alpha/alpha2
#BETA
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=beta6,tag=beta] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase1,tag=down,scores={boss_cool=..2},distance=..120] run function voa:boss/phase2/bossetup_phase2
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=beta5,tag=beta] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/beta/beta6
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=beta4,tag=beta] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/beta/beta5
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=beta3,tag=beta] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/beta/beta4
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=beta2,tag=beta] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/beta/beta3
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=beta1,tag=beta] at @s if entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/beta/beta2

#Kills Plate
execute as @e[type=minecraft:armor_stand,tag=wrath_alter] at @s if block ~ ~ ~ minecraft:bedrock run kill @e[type=minecraft:item,tag=used,nbt={Item:{id:"minecraft:item_frame",tag:{wrath:1b}}},distance=..2]

#--- Magic Bench----------------------------------------------------------------------------------------->
#Magic Bench
execute as @e[type=minecraft:item_frame,tag=magic_bench] at @s run function voa:magic_bench/place
execute as @e[type=minecraft:armor_stand,tag=magic_bench] at @s unless block ~ ~ ~ minecraft:dropper run function voa:magic_bench/remove
execute as @e[tag=magic_bench] at @s run function voa:magic_bench/crafting

#---Magic-Bench Armor-stand Spawn# 
execute as @e[type=minecraft:armor_stand,tag=magicbenchmarker,tag=!summoned] at @s run function voa:magic_bench/placechance
execute as @e[type=minecraft:armor_stand,tag=magicbenchmarker,tag=summoned] at @s run kill @s
#Magic Bench  END##

#----------------------------------------------------------------------------------- Items ---------------------------------------------------------------------------------------------#

##Use - Scoreboard
scoreboard players set @a[nbt={SelectedItem:{id:"minecraft:snowball",components:{"minecraft:custom_data":{bdb:1b}}}}] dust_bomb_delay 2
scoreboard players set @a[nbt={SelectedItem:{id:"minecraft:snowball",components:{"minecraft:custom_data":{bynab:1b}}}}] dyna_bomb_delay 2


#--- Bone Dust Bomb-------------------------------------------------------------------------------------->
### Runs throw function
#Detects if Player has a BDB in main hand.
execute as @a[scores={dust_bomb_delay=1..,bomb_use=1}] at @s run tag @s add bomb
execute as @a[scores={dust_bomb_delay=1..,bomb_use=1}] at @s anchored eyes run function voa:bone_dust_bomb/bomb

#execute as @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_data":{bdb:1b}}}}] as @a[tag=bomb] at @s anchored eyes run function voa:bone_dust_bomb/bomb
execute as @e[type=minecraft:armor_stand,tag=player,tag=!motion] at @s rotated as @a[tag=bomb] run function voa:bone_dust_bomb/motion
execute as @e[type=minecraft:armor_stand,tag=player,tag=motion,scores={bdb_cool=1..35}] at @s run particle minecraft:large_smoke
execute as @e[type=minecraft:armor_stand,tag=player,tag=motion,scores={bdb_cool=0}] at @s run function voa:bone_dust_bomb/timer
#Removes tag if thrown, or if they don't have the BDB selected.
execute as @a[scores={dust_bomb_delay=1..,bomb_use=1},nbt=!{SelectedItem:{id:"minecraft:snowball",components:{"minecraft:custom_data":{bdb:1b}}}}] at @s run tag @s remove bomb
scoreboard players remove @e[type=minecraft:armor_stand,tag=player,tag=motion,scores={bdb_cool=1..}] bdb_cool 1

#End Bone Dust Bomb#

#--- Dyna-Bomb-------------------------------------------------------------------------------------->
### Runs throw function
#Detects if Player has a BDB in main hand.
execute as @a[scores={dyna_bomb_delay=1..,bomb_use=1}] at @s run tag @s add dynabomb
execute as @a[scores={dyna_bomb_delay=1..,bomb_use=1}] at @s anchored eyes run function voa:dyna_bomb/bomb
execute as @e[type=minecraft:armor_stand,tag=player,tag=!motion] at @s rotated as @a[tag=dynabomb] run function voa:dyna_bomb/motion
execute as @e[type=minecraft:armor_stand,tag=player,tag=motion,scores={byb_cool=1..35}] at @s run particle minecraft:large_smoke
execute as @e[type=minecraft:armor_stand,tag=player,tag=motion,scores={byb_cool=0}] at @s run function voa:dyna_bomb/timer
#Removes tag if thrown, or if they don't have the BDB selected.
execute as @a[scores={dyna_bomb_delay=1..,bomb_use=1},nbt=!{SelectedItem:{id:"minecraft:snowball",components:{"minecraft:custom_data":{bynab:1b}}}}] at @s run tag @s remove dynabomb

#Removes for both BDB and DYB
scoreboard players remove @e[type=minecraft:armor_stand,tag=player,tag=motion,scores={byb_cool=1..}] byb_cool 1
execute as @a[scores={dust_bomb_delay=1..}] unless entity @s[nbt={SelectedItem:{id:"minecraft:snowball",components:{"minecraft:custom_data":{bdb:1b}}}}] run scoreboard players remove @s dust_bomb_delay 1
execute as @a[scores={dyna_bomb_delay=1..}] unless entity @s[nbt={SelectedItem:{id:"minecraft:snowball",components:{"minecraft:custom_data":{bynab:1b}}}}] run scoreboard players remove @s dyna_bomb_delay 1
scoreboard players reset @a[scores={bomb_use=1..}] bomb_use




#--- Bonelock Weapon------------------------------------------------------------------------------------->
#Ready to Fire!
execute as @a[scores={bonelk=1..,bonelk_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{bonelock:1b}}},Inventory:[{id:"minecraft:stick",components:{"minecraft:custom_data":{boneshot:1b}}}]}] at @s run function voa:bonelock/shot
#Keeps setting the score to 1 when player fires the Bonelock (THIS CODE NEEDS TO BE BELOW COMMANDS AT THE BOTTOM!)
scoreboard players set @a[scores={bonelk=1..}] bonelk 0
#Sets Cooldown between shots and resets it
scoreboard players remove @a[scores={bonelk_cool=1..}] bonelk_cool 1
#Bonelock END#


##--- Bonesket Weapon------------------------------------------------------------------------------------->
##Reload Weapon
execute as @a[scores={bonesktrld=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{bonesket:1b}}},Inventory:[{id:"minecraft:stick",components:{"minecraft:custom_data":{boneshot:1b}}}]}] at @s run function voa:bonesket/reload
execute as @a[scores={boneskt_cool=..1},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{bonesket:1b}}},Inventory:[{id:"minecraft:stick",components:{"minecraft:custom_data":{boneshot:1b}}}]}] at @s run function voa:bonesket/steady_weapon
##Racked Round
execute as @a[scores={boneskt=24..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{bonesket:1b}}},Inventory:[{id:"minecraft:stick",components:{"minecraft:custom_data":{boneshot:1b}}}]}] at @s run function voa:bonesket/rack_round
##Ready to Fire!
execute as @a[scores={bonesktracking=0,bonesktrld=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{bonesketloaded:1b}}}}] at @s run function voa:bonesket/shot
#
#Reload Scoreboards for Animation, plus steadies weapon when not reloading.
#Keeps setting the score to 1 when player fires the Bonesketrld (THIS CODE NEEDS TO BE BELOW COMMANDS AT THE BOTTOM!)
scoreboard players set @a[scores={bonesktrld=1..}] bonesktrld 0
scoreboard players remove @a[scores={boneskt_cool=1..}] boneskt_cool 1
scoreboard players remove @a[scores={bonesktready=1..}] bonesktready 1
#How long until the round is racked, once it hits ten the round is racked and the countdown resets.
scoreboard players set @a[scores={boneskt=24..}] boneskt 0
#Sets rackround cooldown, so round doesn't immediately fire.
scoreboard players remove @a[scores={bonesktracking=1..}] bonesktracking 1
#Bonesket END#


#--- Bonesplitter Weapon------------------------------------------------------------------------------------->
#Reload Weapon
execute as @a[scores={bonesptrld=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{bonesplitter:1b}}},Inventory:[{id:"minecraft:stick",components:{"minecraft:custom_data":{boneshot:1b}}}]}] at @s run function voa:bonesplitter/reload
execute as @a[scores={bonespt_cool=..1},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{bonesplitter:1b}}},Inventory:[{id:"minecraft:stick",components:{"minecraft:custom_data":{boneshot:1b}}}]}] at @s run function voa:bonesplitter/steady_weapon
#Racked Round
execute as @a[scores={bonespt=13..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{bonesplitter:1b}}},Inventory:[{id:"minecraft:stick",components:{"minecraft:custom_data":{boneshot:1b}}}]}] at @s run function voa:bonesplitter/rack_round
#Ready to Fire!
execute as @a[scores={bonesptracking=0,bonesptrld=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{bonesplitterloaded:1b}}}}] at @s run function voa:bonesplitter/shot

#Multi-Enemy Dmg
#execute as @e[tag=shot] at @s run function voa:bonesplitter/dmg

#Reload Scoreboards for Animation, plus steadies weapon when not reloading.
##Keeps setting the score to 1 when player fires the Bonesketrld (THIS CODE NEEDS TO BE BELOW COMMANDS AT THE BOTTOM!)
scoreboard players set @a[scores={bonesptrld=1..}] bonesptrld 0
scoreboard players remove @a[scores={bonespt_cool=1..}] bonespt_cool 1
scoreboard players remove @a[scores={bonesptready=1..}] bonesptready 1

##How long until the round is racked, once it hits ten the round is racked and the countdown resets.
scoreboard players set @a[scores={bonespt=13..}] bonespt 0
##Sets rackround cooldown, so round doesn't immediately fire.
scoreboard players remove @a[scores={bonesptracking=1..}] bonesptracking 1
#Bonesket END#


##--- Double-Bone Weapon------------------------------------------------------------------------------------->
#Reload Weapon
execute as @a[scores={bonedrld=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{dbone:1b}}},Inventory:[{id:"minecraft:stick",components:{"minecraft:custom_data":{boneshot:1b}}}]}] at @s run function voa:double_bone/reload
execute as @a[scores={d_bone_cool=..1},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{dbone:1b}}},Inventory:[{id:"minecraft:stick",components:{"minecraft:custom_data":{boneshot:1b}}}]}] at @s run function voa:double_bone/steady_weapon
#Racked Round
execute as @a[scores={bonedoub=13..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{dbone:1b}}},Inventory:[{id:"minecraft:stick",components:{"minecraft:custom_data":{boneshot:1b}}}]}] at @s run function voa:double_bone/rack_round
#Ready to Fire! - Half Loaded
execute as @a[scores={bonedracking=0,bonedrld=1..,d_bone_2nd_shot_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{dboneloaded:1b}}}}] at @s run function voa:double_bone/shot
#Ready to Fire! - Full Loaded
execute as @a[scores={bonedracking=0,bonedrld=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{dboneloaded_2:1b}}}}] at @s run function voa:double_bone/shot_full


#Multi-Enemy Dmg
#execute as @e[tag=shot_double] at @s run function voa:double_bone/dmg

#Reload Scoreboards for Animation, plus steadies weapon when not reloading.
##Keeps setting the score to 1 when player fires the Bonesketrld (THIS CODE NEEDS TO BE BELOW COMMANDS AT THE BOTTOM!)
scoreboard players set @a[scores={bonedrld=1..}] bonedrld 0
scoreboard players remove @a[scores={d_bone_cool=1..}] d_bone_cool 1
scoreboard players remove @a[scores={d_bone_2nd_shot_cool=1..}] d_bone_2nd_shot_cool 1
scoreboard players remove @a[scores={bonedready=1..}] bonedready 1

##How long until the round is racked, once it hits ten the round is racked and the countdown resets.
scoreboard players set @a[scores={bonedoub=13..}] bonedoub 0
##Sets rackround cooldown, so round doesn't immediately fire.
scoreboard players remove @a[scores={bonedracking=1..}] bonedracking 1
#Double-Bone END#


#--- Battle Ghast Scepter------------------------------------------------------------------------------------->
#Ready to Fire!
#execute as @a on vehicle if entity @s[type=minecraft:happy_ghast] run say The player is riding a Ghast.
execute as @a[scores={ghast_spt=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{ghast_scepter:1b}}}}] at @s on vehicle if entity @s[type=minecraft:happy_ghast,scores={ghast_scepter_cool=0}] run function voa:ghast_scepter/shot
#Keeps setting the score to 1 when player fires the Bonelock (THIS CODE NEEDS TO BE BELOW COMMANDS AT THE BOTTOM!)
scoreboard players set @a[scores={ghast_spt=1..}] ghast_spt 0
#Sets Cooldown between shots and resets it
scoreboard players remove @e[scores={ghast_scepter_cool=1..}] ghast_scepter_cool 1

#Gives Ghast Scoreboard
execute as @e[type=minecraft:happy_ghast,tag=!stats] at @s run function voa:ghast_scepter/stats

#Battle Ghast Scepter END#

#--- Swords ----------------------------------------------------------------------------------------------->
#PestKeeper
execute as @e[type=#voa:pest] at @s if entity @a[scores={irony=1..},distance=..10,nbt={SelectedItem:{id:"minecraft:iron_sword",count:1,components:{"minecraft:custom_data":{pestkeeper:1b}}}}] run function voa:swords/pest
#PestKeeper END##


#Spectral-Schimitar
execute as @a[nbt={SelectedItem:{id:"minecraft:netherite_sword",count:1,components:{"minecraft:custom_data":{schimitar:1b}}}}] at @s if entity @e[tag=ghost,distance=..6] run function voa:swords/ghost
#Spectral-Schimitar END##


#Cryptonic-Schimitar
execute as @a[tag=!sight,nbt={SelectedItem:{id:"minecraft:netherite_sword",count:1,components:{"minecraft:custom_data":{c_schimitar:1b}}}}] at @s run tag @s add sight
execute as @a[nbt={SelectedItem:{id:"minecraft:netherite_sword",count:1,components:{"minecraft:custom_data":{c_schimitar:1b}}}}] at @s if entity @e[tag=cryptid,distance=..6] run function voa:swords/horror
execute as @a[tag=sight] at @s unless entity @s[nbt={SelectedItem:{id:"minecraft:netherite_sword",count:1,components:{"minecraft:custom_data":{c_schimitar:1b}}}}] at @s run tag @s remove sight

#Cryptonic-Schimitar END##


#Cake-Blade
execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{cakeblade:1b}}}}] at @s if entity @e[nbt={HurtTime:9s},distance=..6] run function voa:swords/cake
#Cake-Blade END##


#Champion
execute as @a[nbt={HurtTime:9s,SelectedItem:{id:"minecraft:netherite_sword",count:1,components:{"minecraft:custom_data":{champion:1b}}}}] at @s run function voa:swords/champion
#Champion END##


#Cookie-Monster
execute as @a[nbt={SelectedItem:{id:"minecraft:netherite_sword",count:1,components:{"minecraft:custom_data":{cookieblade:1b}}}}] at @s if entity @e[nbt={HurtTime:9s},distance=..6] run function voa:swords/cookie
#Cookie-Monster END##


#Coal-Train
execute as @a[nbt={SelectedItem:{id:"minecraft:iron_sword",count:1,components:{"minecraft:custom_data":{coaltrain:1b}}}}] at @s if entity @e[nbt={HurtTime:9s},distance=..6] run function voa:swords/coaltrain
execute as @a[nbt={SelectedItem:{id:"minecraft:iron_sword",count:1,components:{"minecraft:custom_data":{coaltrain:1b}}}}] at @s if entity @a[scores={coaltrain=1..}] run execute anchored eyes positioned ^ ^ ^ run particle minecraft:large_smoke ^-.05 ^ ^1.5   
#Coal-Train END##


#Coal-Train
execute as @a[nbt={SelectedItem:{id:"minecraft:iron_sword",count:1,components:{"minecraft:custom_data":{baguette:1b}}}}] at @s if entity @e[nbt={HurtTime:9s},distance=..6] run function voa:swords/baguette
#Coal-Train END##


#Emerald-Embezzler
execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{emeraldblade:1b}}}}] at @s if entity @e[nbt={HurtTime:9s},distance=..6] run function voa:swords/embezzler 
#Emerald-Embezzler END##


#Psionic Sabre
execute as @a[nbt={SelectedItem:{id:"minecraft:netherite_sword",count:1,components:{"minecraft:custom_data":{psi_sabre:1b}}}}] at @s if entity @e[nbt={HurtTime:9s},distance=..6] run function voa:swords/psionic
#Emerald-Embezzler END##


#Ice Sword
execute as @a[nbt={SelectedItem:{id:"minecraft:netherite_sword",count:1,components:{"minecraft:custom_data":{ice_sword:1b}}}}] at @s if entity @e[nbt={HurtTime:9s},distance=..6] run function voa:swords/ice_sword
execute as @e[tag=snowdamage] run function voa:swords/ice_sword_damage
#Ice Sword END##


#Hellraiser!
execute as @a[scores={hellfire=1..,hellfire_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{hellraiser:1b}}},Inventory:[{id:"minecraft:tnt"}]}] at @s run function voa:swords/hellraiser
scoreboard players set @a[scores={hellfire=1..}] hellfire 0
#Sets Cooldown between shots and resets it
scoreboard players remove @a[scores={hellfire_cool=1..}] hellfire_cool 1
#Hellraiser END#


#X-blade(Chaos)
execute as @a[nbt={SelectedItem:{id:"minecraft:netherite_sword",count:1,components:{"minecraft:custom_data":{xbladec:1b}}}}] at @s if entity @e[nbt={HurtTime:9s},distance=..6,type=!player] run function voa:swords/xblades/chaos
execute as @e[tag=rocket,tag=!expo] at @s run function voa:swords/xblades/chaos_rocket
execute as @e[tag=rocket,scores={xblade_c_cool=..1}] at @s run function voa:swords/xblades/chaos_rocket_detonate
execute as @e[tag=rocket] at @s run particle minecraft:firework ~ ~ ~ .2 .2 .2 .2 1
#X-blade(Chaos) END##


#X-blade(Harmony)
execute as @a[nbt={SelectedItem:{id:"minecraft:netherite_sword",count:1,components:{"minecraft:custom_data":{xbladeh:1b}}}}] at @s if entity @e[nbt={HurtTime:9s},distance=..6] run function voa:swords/xblades/harmony
#X-blade(Harmony) END##


#X-blade(Lucky)
execute as @a[nbt={SelectedItem:{id:"minecraft:netherite_sword",count:1,components:{"minecraft:custom_data":{xbladel:1b}}}}] at @s if entity @e[nbt={HurtTime:9s},distance=..6] run function voa:swords/xblades/lucky
execute as @e[tag=luck,type=!ravager,tag=!titan,type=!warden,tag=!gladiator,tag=!dream_eater,tag=!warpedtitan] at @s run function voa:swords/xblades/lucky_spawn
execute as @e[tag=luck,type=ravager] at @s run function voa:swords/xblades/lucky_spawn_big
execute as @e[tag=luck,tag=titan] at @s run function voa:swords/xblades/lucky_spawn_big
execute as @e[tag=luck,tag=warpedtitan] at @s run function voa:swords/xblades/lucky_spawn_big
execute as @e[tag=luck,tag=dream_eater] at @s run function voa:swords/xblades/lucky_spawn_big
execute as @e[tag=luck,tag=gladiator] at @s run function voa:swords/xblades/lucky_spawn_big
execute as @e[tag=luckybat] at @s unless entity @a[distance=..20] run tp @s ~ ~-256 ~
#X-blade(Lucky) END##


#X-blade(Dangerous)
execute as @e[type=!#voa:not_mob] at @s if entity @a[scores={xblade_d=1..},distance=..8,nbt={SelectedItem:{id:"minecraft:netherite_sword",count:1,components:{"minecraft:custom_data":{xbladed:1b}}}}] run function voa:swords/xblades/dangerous
#X-blade(Dangerous) END##


##SWORD SCOREBOARDS - ALL
scoreboard players set @e[scores={embezzler=1..}] embezzler 0
scoreboard players set @a[scores={coaltrain=1..}] coaltrain 0
scoreboard players set @a[scores={irony=1..}] irony 0
scoreboard players set @a[scores={xblade_d=1..}] xblade_d 0
scoreboard players remove @e[scores={xblade_c_cool=1..}] xblade_c_cool 1
#--- Swords END------------------------------------------------------------------------------------------->

#--- Armor Sets ----------------------------------------------------------------------------------------------->
#Tome Armor - Setting Tome/Bone Reuse Tag
execute as @a[tag=!tome_reuse_helm,nbt={equipment:{head:{id:'minecraft:netherite_helmet',components:{"minecraft:custom_data":{tometic:1b}}}}}] at @s run tag @s add tome_reuse_helm
execute as @a[tag=!tome_reuse_chest,nbt={equipment:{chest:{id:'minecraft:netherite_chestplate',components:{"minecraft:custom_data":{tometic:1b}}}}}] at @s run tag @s add tome_reuse_chest
execute as @a[tag=!tome_reuse_chest_dia,nbt={equipment:{chest:{id:'minecraft:diamond_chestplate',components:{"minecraft:custom_data":{tometic:1b}}}}}] at @s run tag @s add tome_reuse_chest_dia
execute as @a[tag=!tome_reuse_legs,nbt={equipment:{legs:{id:'minecraft:netherite_leggings',components:{"minecraft:custom_data":{tometic:1b}}}}}] at @s run tag @s add tome_reuse_legs
execute as @a[tag=!tome_reuse_boots,nbt={equipment:{feet:{id:'minecraft:netherite_boots',components:{"minecraft:custom_data":{tometic:1b}}}}}] at @s run tag @s add tome_reuse_boots
#BONE
execute as @a[tag=!bone_reuse_helm,nbt={equipment:{head:{id:'minecraft:netherite_helmet',components:{"minecraft:custom_data":{bone:1b}}}}}] at @s run tag @s add bone_reuse_helm
execute as @a[tag=!bone_reuse_chest,nbt={equipment:{chest:{id:'minecraft:netherite_chestplate',components:{"minecraft:custom_data":{bone:1b}}}}}] at @s run tag @s add bone_reuse_chest
execute as @a[tag=!bone_reuse_legs,nbt={equipment:{legs:{id:'minecraft:netherite_leggings',components:{"minecraft:custom_data":{bone:1b}}}}}] at @s run tag @s add bone_reuse_legs
execute as @a[tag=!bone_reuse_boots,nbt={equipment:{feet:{id:'minecraft:netherite_boots',components:{"minecraft:custom_data":{bone:1b}}}}}] at @s run tag @s add bone_reuse_boots

#Tome Armor - Removing Tome/Bone Reuse Tag
execute as @a[tag=tome_reuse_helm] at @s unless entity @s[nbt={equipment:{head:{id:'minecraft:netherite_helmet',components:{"minecraft:custom_data":{tometic:1b}}}}}] at @s run tag @s remove tome_reuse_helm
execute as @a[tag=tome_reuse_chest] at @s unless entity @s[nbt={equipment:{chest:{id:'minecraft:netherite_chestplate',components:{"minecraft:custom_data":{tometic:1b}}}}}] at @s run tag @s remove tome_reuse_chest
execute as @a[tag=tome_reuse_chest_dia] at @s unless entity @s[nbt={equipment:{chest:{id:'minecraft:diamond_chestplate',components:{"minecraft:custom_data":{tometic:1b}}}}}] at @s run tag @s remove tome_reuse_chest_dia
execute as @a[tag=tome_reuse_legs] at @s unless entity @s[nbt={equipment:{legs:{id:'minecraft:netherite_leggings',components:{"minecraft:custom_data":{tometic:1b}}}}}] at @s run tag @s remove tome_reuse_legs
execute as @a[tag=tome_reuse_boots] at @s unless entity @s[nbt={equipment:{feet:{id:'minecraft:netherite_boots',components:{"minecraft:custom_data":{tometic:1b}}}}}] at @s run tag @s remove tome_reuse_boots
#BONE
execute as @a[tag=bone_reuse_helm] at @s unless entity @s[nbt={equipment:{head:{id:'minecraft:netherite_helmet',components:{"minecraft:custom_data":{bone:1b}}}}}] at @s run tag @s remove bone_reuse_helm
execute as @a[tag=bone_reuse_chest] at @s unless entity @s[nbt={equipment:{chest:{id:'minecraft:netherite_chestplate',components:{"minecraft:custom_data":{bone:1b}}}}}] at @s run tag @s remove bone_reuse_chest
execute as @a[tag=bone_reuse_legs] at @s unless entity @s[nbt={equipment:{legs:{id:'minecraft:netherite_leggings',components:{"minecraft:custom_data":{bone:1b}}}}}] at @s run tag @s remove bone_reuse_legs
execute as @a[tag=bone_reuse_boots] at @s unless entity @s[nbt={equipment:{feet:{id:'minecraft:netherite_boots',components:{"minecraft:custom_data":{bone:1b}}}}}] at @s run tag @s remove bone_reuse_boots



#--- Armor Sets END ----------------------------------------------------------------------------------------------->

######## Holding Register - Will need to be reworked at some point - Needs to be more specific
scoreboard players set @a[nbt={SelectedItem:{id:"minecraft:item_frame"}}] trophy_delay 2

##Defender Trophy - HEAD PLAYER ITEM!
execute as @e[type=minecraft:item_frame,tag=defender] at @s run function voa:defender_trophy/place
execute as @e[type=minecraft:armor_stand,tag=trophy] at @s unless block ~ ~ ~ minecraft:player_head run function voa:defender_trophy/remove

#Defender Trophy END- HEAD PLAYER ITEM!
execute as @e[type=minecraft:item_frame,tag=defender_end] at @s run function voa:defender_trophy/place_end
execute as @e[type=minecraft:armor_stand,tag=trophy_end] at @s unless block ~ ~ ~ minecraft:player_head run function voa:defender_trophy/remove_end

##Defender Trophy Gladiator- HEAD PLAYER ITEM!
execute as @e[type=minecraft:item_frame,tag=defender_gladiator] at @s run function voa:defender_trophy/place_gladiator
execute as @e[type=minecraft:armor_stand,tag=trophy_gladiator] at @s unless block ~ ~ ~ minecraft:player_head run function voa:defender_trophy/remove_gladiator

#----------------------------------------------------------------------------------- Placeable Block Scoreboards ---------------------------------------------------------------------------------------------#
#### Constantly remove 1 from the delay - Register/Placeable blocks
execute as @a[scores={trophy_delay=1..}] unless entity @s[nbt={SelectedItem:{id:"minecraft:item_frame"}}] run scoreboard players remove @s trophy_delay 1
##### Reset eat scoreboard - All Types
scoreboard players reset @a[scores={trophy_place=1..}] trophy_place

#----------------------------------------------------------------------------------- Magic Staffs ---------------------------------------------------------------------------------------------#

#Harmony Staff
##Staff Fires AOE Heal
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffh12:1b}}}}] at @s run function voa:staff_harmony/harmony12
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffh11:1b}}}}] at @s run function voa:staff_harmony/harmony11
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffh10:1b}}}}] at @s run function voa:staff_harmony/harmony10
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffh9:1b}}}}] at @s run function voa:staff_harmony/harmony9
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffh8:1b}}}}] at @s run function voa:staff_harmony/harmony8
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffh7:1b}}}}] at @s run function voa:staff_harmony/harmony7
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffh6:1b}}}}] at @s run function voa:staff_harmony/harmony6
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffh5:1b}}}}] at @s run function voa:staff_harmony/harmony5
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffh4:1b}}}}] at @s run function voa:staff_harmony/harmony4
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffh3:1b}}}}] at @s run function voa:staff_harmony/harmony3
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffh2:1b}}}}] at @s run function voa:staff_harmony/harmony2
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffh1:1b}}}}] at @s run function voa:staff_harmony/harmony1

#Harmony Staff - Mythic
##Charge Staff - Staff Type Focus (NBT tags are different then cast)
execute as @a[scores={staff_charge=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_h:1b}}}}] at @s run function voa:staff_harmony_elite/charge
##Threshold - Staff Type Focus (NBT tags are different then cast)
execute as @a[scores={staff_charge_up=24..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_h:1b}}}}] at @s run function voa:staff_harmony_elite/threshold

##Cast - Durability Focus (NBT tags are different Charge/Threshold)
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_h1:1b}}}}] at @s run function voa:staff_harmony_elite/cast1
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_h2:1b}}}}] at @s run function voa:staff_harmony_elite/cast2
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_h3:1b}}}}] at @s run function voa:staff_harmony_elite/cast3
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_h4:1b}}}}] at @s run function voa:staff_harmony_elite/cast4
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_h5:1b}}}}] at @s run function voa:staff_harmony_elite/cast5
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_h6:1b}}}}] at @s run function voa:staff_harmony_elite/cast6
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_h7:1b}}}}] at @s run function voa:staff_harmony_elite/cast7
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_h8:1b}}}}] at @s run function voa:staff_harmony_elite/cast8
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_h9:1b}}}}] at @s run function voa:staff_harmony_elite/cast9
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_h10:1b}}}}] at @s run function voa:staff_harmony_elite/cast10
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_h11:1b}}}}] at @s run function voa:staff_harmony_elite/cast11
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_h12:1b}}}}] at @s run function voa:staff_harmony_elite/cast12


##Scoreboards
scoreboard players set @a[scores={staff_h=1..}] staff_h 0
scoreboard players remove @a[scores={staff_h_cool=1..}] staff_h_cool 1 
#Harmony Staff END#


#Lucky Staff
##Staff Fires Chicken Claw
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffl12:1b}}}}] at @s run function voa:staff_lucky/lucky12
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffl11:1b}}}}] at @s run function voa:staff_lucky/lucky11
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffl10:1b}}}}] at @s run function voa:staff_lucky/lucky10
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffl9:1b}}}}] at @s run function voa:staff_lucky/lucky9
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffl8:1b}}}}] at @s run function voa:staff_lucky/lucky8
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffl7:1b}}}}] at @s run function voa:staff_lucky/lucky7
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffl6:1b}}}}] at @s run function voa:staff_lucky/lucky6
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffl5:1b}}}}] at @s run function voa:staff_lucky/lucky5
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffl4:1b}}}}] at @s run function voa:staff_lucky/lucky4
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffl3:1b}}}}] at @s run function voa:staff_lucky/lucky3
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffl2:1b}}}}] at @s run function voa:staff_lucky/lucky2
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffl1:1b}}}}] at @s run function voa:staff_lucky/lucky1
###Scoreboards
scoreboard players set @a[scores={staff_l=1..}] staff_l 0
scoreboard players remove @a[scores={staff_l_cool=1..}] staff_l_cool 1 

#Ravager Health - Lucky Tome/Staff
execute as @e[type=minecraft:ravager,tag=!healthy] at @s run function voa:staff_lucky/ravager
execute as @e[type=minecraft:ravager,tag=healthy] run execute store result score @s titanhealth run data get entity @s Health

#Warden Health - Lucky Tome/Staff
execute as @e[type=minecraft:warden,tag=!healthy] at @s run function voa:staff_lucky/warden
execute as @e[type=minecraft:warden,tag=healthy] run execute store result score @s titanhealth run data get entity @s Health
#Lucky Staff END#

#lucky Staff - Mythic
##Charge Staff
execute as @a[scores={staff_charge=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_l:1b}}}}] at @s run function voa:staff_lucky_elite/charge
##Threshold
execute as @a[scores={staff_charge_up=24..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_l:1b}}}}] at @s run function voa:staff_lucky_elite/threshold
##Cast
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_l1:1b}}}}] at @s run function voa:staff_lucky_elite/cast1
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_l2:1b}}}}] at @s run function voa:staff_lucky_elite/cast2
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_l3:1b}}}}] at @s run function voa:staff_lucky_elite/cast3
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_l4:1b}}}}] at @s run function voa:staff_lucky_elite/cast4
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_l5:1b}}}}] at @s run function voa:staff_lucky_elite/cast5
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_l6:1b}}}}] at @s run function voa:staff_lucky_elite/cast6
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_l7:1b}}}}] at @s run function voa:staff_lucky_elite/cast7
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_l8:1b}}}}] at @s run function voa:staff_lucky_elite/cast8
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_l9:1b}}}}] at @s run function voa:staff_lucky_elite/cast9
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_l10:1b}}}}] at @s run function voa:staff_lucky_elite/cast10
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_l11:1b}}}}] at @s run function voa:staff_lucky_elite/cast11
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_l12:1b}}}}] at @s run function voa:staff_lucky_elite/cast12


#Dangerous Staff
##Staff Summons Fireball
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffd12:1b}}}}] at @s run function voa:staff_dangerous/dangerous12
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffd11:1b}}}}] at @s run function voa:staff_dangerous/dangerous11
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffd10:1b}}}}] at @s run function voa:staff_dangerous/dangerous10
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffd9:1b}}}}] at @s run function voa:staff_dangerous/dangerous9
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffd8:1b}}}}] at @s run function voa:staff_dangerous/dangerous8
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffd7:1b}}}}] at @s run function voa:staff_dangerous/dangerous7
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffd6:1b}}}}] at @s run function voa:staff_dangerous/dangerous6
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffd5:1b}}}}] at @s run function voa:staff_dangerous/dangerous5
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffd4:1b}}}}] at @s run function voa:staff_dangerous/dangerous4
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffd3:1b}}}}] at @s run function voa:staff_dangerous/dangerous3
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffd2:1b}}}}] at @s run function voa:staff_dangerous/dangerous2
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffd1:1b}}}}] at @s run function voa:staff_dangerous/dangerous1

#Dangerous Staff - Mythic
##Charge Staff
execute as @a[scores={staff_charge=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_d:1b}}}}] at @s run function voa:staff_dangerous_elite/charge
##Threshold
execute as @a[scores={staff_charge_up=24..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_d1:1b}}}}] at @s run function voa:staff_dangerous_elite/threshold1
execute as @a[scores={staff_charge_up=24..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_d2:1b}}}}] at @s run function voa:staff_dangerous_elite/threshold2
execute as @a[scores={staff_charge_up=24..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_d3:1b}}}}] at @s run function voa:staff_dangerous_elite/threshold3
execute as @a[scores={staff_charge_up=24..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_d4:1b}}}}] at @s run function voa:staff_dangerous_elite/threshold4
execute as @a[scores={staff_charge_up=24..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_d5:1b}}}}] at @s run function voa:staff_dangerous_elite/threshold5
execute as @a[scores={staff_charge_up=24..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_d6:1b}}}}] at @s run function voa:staff_dangerous_elite/threshold6
execute as @a[scores={staff_charge_up=24..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_d7:1b}}}}] at @s run function voa:staff_dangerous_elite/threshold7
execute as @a[scores={staff_charge_up=24..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_d8:1b}}}}] at @s run function voa:staff_dangerous_elite/threshold8
execute as @a[scores={staff_charge_up=24..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_d9:1b}}}}] at @s run function voa:staff_dangerous_elite/threshold9
execute as @a[scores={staff_charge_up=24..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_d10:1b}}}}] at @s run function voa:staff_dangerous_elite/threshold10
execute as @a[scores={staff_charge_up=24..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_d11:1b}}}}] at @s run function voa:staff_dangerous_elite/threshold11
execute as @a[scores={staff_charge_up=24..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_d12:1b}}}}] at @s run function voa:staff_dangerous_elite/threshold12
##Cast
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_d:1b}}}}] at @s run function voa:staff_dangerous_elite/cast



###Scoreboards
scoreboard players set @a[scores={staff_d=1..}] staff_d 0
scoreboard players remove @a[scores={staff_d_cool=1..}] staff_d_cool 1 
#Dangerous Staff END#


#Chaos Staff - Basic
##Staff Fires
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc12:1b}}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc11:1b}}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc10:1b}}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc9:1b}}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc8:1b}}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc7:1b}}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc6:1b}}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc5:1b}}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc4:1b}}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc3:1b}}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc2:1b}}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc1:1b}}}}] at @s run function voa:staff_chaos/chaos_effect

##Staff Wears Down
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc12:1b}}}}] at @s run function voa:staff_chaos/chaos12_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc11:1b}}}}] at @s run function voa:staff_chaos/chaos11_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc10:1b}}}}] at @s run function voa:staff_chaos/chaos10_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc9:1b}}}}] at @s run function voa:staff_chaos/chaos9_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc8:1b}}}}] at @s run function voa:staff_chaos/chaos8_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc7:1b}}}}] at @s run function voa:staff_chaos/chaos7_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc6:1b}}}}] at @s run function voa:staff_chaos/chaos6_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc5:1b}}}}] at @s run function voa:staff_chaos/chaos5_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc4:1b}}}}] at @s run function voa:staff_chaos/chaos4_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc3:1b}}}}] at @s run function voa:staff_chaos/chaos3_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc2:1b}}}}] at @s run function voa:staff_chaos/chaos2_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffc1:1b}}}}] at @s run function voa:staff_chaos/chaos1_worn


#Chaos Staff - Mythic
##Charge Staff
execute as @a[scores={staff_charge=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_c:1b}}}}] at @s run function voa:staff_chaos_elite/charge
##Threshold
execute as @a[scores={staff_charge_up=24..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_c:1b}}}}] at @s run function voa:staff_chaos_elite/threshold
##Cast
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_c1:1b}}}}] at @s run function voa:staff_chaos_elite/cast1
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_c2:1b}}}}] at @s run function voa:staff_chaos_elite/cast2
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_c3:1b}}}}] at @s run function voa:staff_chaos_elite/cast3
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_c4:1b}}}}] at @s run function voa:staff_chaos_elite/cast4
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_c5:1b}}}}] at @s run function voa:staff_chaos_elite/cast5
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_c6:1b}}}}] at @s run function voa:staff_chaos_elite/cast6
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_c7:1b}}}}] at @s run function voa:staff_chaos_elite/cast7
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_c8:1b}}}}] at @s run function voa:staff_chaos_elite/cast8
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_c9:1b}}}}] at @s run function voa:staff_chaos_elite/cast9
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_c10:1b}}}}] at @s run function voa:staff_chaos_elite/cast10
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_c11:1b}}}}] at @s run function voa:staff_chaos_elite/cast11
execute as @a[scores={staff_charge_up=24..,staff_charge_release=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{staffm_c12:1b}}}}] at @s run function voa:staff_chaos_elite/cast12


##Scoreboards - Chaos
scoreboard players set @a[scores={staff_c=1..}] staff_c 0
scoreboard players set @a[scores={staff_c_cool=50..}] staff_c_cool 0
#Chaos Staff END#

#Resets Staff if not charging - All Staffs
scoreboard players set @a[scores={staff_charge=1..}] staff_charge 0
execute as @a[scores={staff_charge_release=0}] at @s run scoreboard players set @a[scores={staff_charge_up=1..}] staff_charge_up 0
scoreboard players remove @a[scores={staff_charge_release=1..}] staff_charge_release 1

#----------------------------------------------------------------------------------- Tomes ---------------------------------------------------------------------------------------------#

#Harmony Tome
execute as @a[scores={tome_h=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{tome_h:1b}}}}] at @s run function voa:tome_harmony/harmony_fire

#Lucky Tome
execute as @a[scores={tome_l=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{tome_l:1b}}}}] at @s run function voa:tome_lucky/lucky_fire

#Chaos Tome
execute as @a[scores={tome_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_data":{tome_c:1b}}}}] at @s run function voa:tome_chaos/chaos_fire
#Stasis Field
execute as @e[type=minecraft:armor_stand,tag=stasis,scores={tome_c_cool=1..}] at @s run function voa:tome_chaos/stasis
execute as @e[type=minecraft:armor_stand,tag=stasis,scores={tome_c_cool=..0}] at @s run kill @s


##Scoreboards - Tomes
scoreboard players set @a[scores={tome_h=1..}] tome_h 0
scoreboard players set @a[scores={tome_l=1..}] tome_l 0
scoreboard players set @a[scores={tome_c=1..}] tome_c 0
scoreboard players remove @e[tag=stasis,type=minecraft:armor_stand,scores={tome_c_cool=1..}] tome_c_cool 1


#----------------------------------------------------------------------------------- Lockets ---------------------------------------------------------------------------------------------#

######## Locket - Executable Item - TEMPLATE!!!
scoreboard players set @a[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{harmony_locket:1b}}}}}] locket_h_delay 2
scoreboard players set @a[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{lucky_locket:1b}}}}}] locket_l_delay 2
scoreboard players set @a[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{chaos_locket:1b}}}}}] locket_c_delay 2

#Trigger Command
execute as @a[scores={locket_h_delay=1..,locketuse=1}] at @s run item replace entity @s weapon.offhand with stick[custom_name={"color":"dark_purple","italic":true,"text":"Void Locket (Uncharged)"},custom_model_data={floats:[313131]},custom_data={locket:1b}] 1
execute as @a[scores={locket_c_delay=1..,locketuse=1}] at @s run item replace entity @s weapon.offhand with stick[custom_name={"color":"dark_purple","italic":true,"text":"Void Locket (Uncharged)"},custom_model_data={floats:[313131]},custom_data={locket:1b}] 1
execute as @a[scores={locket_l_delay=1..,locketuse=1}] at @s run item replace entity @s weapon.offhand with stick[custom_name={"color":"dark_purple","italic":true,"text":"Void Locket (Uncharged)"},custom_model_data={floats:[313131]},custom_data={locket:1b}] 1

##### Constantly remove 1 from the delay 
execute as @a[scores={locket_h_delay=1..}] unless entity @s[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{harmony_locket:1b}}}}}] run scoreboard players remove @s locket_h_delay 1
execute as @a[scores={locket_c_delay=1..}] unless entity @s[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{chaos_locket:1b}}}}}] run scoreboard players remove @s locket_c_delay 1
execute as @a[scores={locket_l_delay=1..}] unless entity @s[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{lucky_locket:1b}}}}}] run scoreboard players remove @s locket_l_delay 1

#----------------------------------------------------------------------------------- Chrest ---------------------------------------------------------------------------------------------#
######## Chrest - Executable Item - TEMPLATE!!!
scoreboard players set @a[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{pandora:1b}}}}}] pandora_crest_delay 2

#Trigger Command - When Used In Death
execute as @a[scores={pandora_crest_delay=1..,locketuse=1}] at @s run function voa:pandoras_crest/open

##### Constantly remove 1 from the delay 
execute as @a[scores={pandora_crest_delay=1..}] unless entity @s[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{pandora:1b}}}}}] run scoreboard players remove @s pandora_crest_delay 1

#FRAME SPAWN
execute as @e[type=minecraft:armor_stand,tag=pandoraframeup,tag=!summoned] at @s run function voa:pandoras_crest/up
execute as @e[type=minecraft:armor_stand,tag=pandoraframeup,tag=summoned] at @s run kill @s


######## Crucifex -----------------------------------------------------------------------------#
scoreboard players set @a[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{crucifex:1b}}}}}] crucifex_crest_delay 2

#Trigger Command - When Used In Death
execute as @a[scores={crucifex_crest_delay=1..,locketuse=1}] at @s run function voa:crucifex/open

##### Constantly remove 1 from the delay 
execute as @a[scores={crucifex_crest_delay=1..}] unless entity @s[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{crucifex:1b}}}}}] run scoreboard players remove @s crucifex_crest_delay 1




#----------------------------------------------------------------------------------- Brooches ---------------------------------------------------------------------------------------------#
######## Brooch - Executable Item - TEMPLATE!!!
scoreboard players set @a[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{harmony_brooch:1b}}}}}] brooch_h_delay 2
scoreboard players set @a[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{chaos_brooch:1b}}}}}] brooch_c_delay 2
scoreboard players set @a[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{lucky_brooch:1b}}}}}] brooch_l_delay 2
scoreboard players set @a[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{dangerous_brooch:1b}}}}}] brooch_d_delay 2

######## Brooch - Executable Item - While Held
execute as @a[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{harmony_brooch:1b}}}}}] at @s run effect give @s minecraft:regeneration 1 0
execute as @a[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{lucky_brooch:1b}}}}}] at @s run effect give @s minecraft:luck 1 0
execute as @a[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{chaos_brooch:1b}}}}}] at @s run effect give @s minecraft:slow_falling 1 1
execute as @a[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{chaos_brooch:1b}}}}}] at @s run effect give @s minecraft:jump_boost 1 2
execute as @a[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{dangerous_brooch:1b}}}}}] at @s run effect give @e[distance=..12] minecraft:strength 1 0

#Trigger Command - When Used In Death

execute as @a[scores={brooch_h_delay=1..,locketuse=1}] at @s run item replace entity @s weapon.offhand with stick[custom_name={"color":"dark_purple","italic":true,"text":"Void Brooch (Uncharged)"},custom_model_data={floats:[310000]},custom_data={brooch:1b}] 1
execute as @a[scores={brooch_h_delay=1..,locketuse=1}] at @s run effect give @s minecraft:instant_health 1 5
execute as @a[scores={brooch_h_delay=1..,locketuse=1}] at @s run effect give @s minecraft:absorption 180 14
execute as @a[scores={brooch_c_delay=1..,locketuse=1}] at @s run item replace entity @s weapon.offhand with stick[custom_name={"color":"dark_purple","italic":true,"text":"Void Brooch (Uncharged)"},custom_model_data={floats:[310000]},custom_data={brooch:1b}] 1
execute as @a[scores={brooch_c_delay=1..,locketuse=1}] at @s run effect give @s minecraft:instant_health 1 5 
execute as @a[scores={brooch_c_delay=1..,locketuse=1}] at @s run function voa:jewelry/chaos_brooch
execute as @a[scores={brooch_l_delay=1..,locketuse=1}] at @s run item replace entity @s weapon.offhand with stick[custom_name={"color":"dark_purple","italic":true,"text":"Void Brooch (Uncharged)"},custom_model_data={floats:[310000]},custom_data={brooch:1b}] 1
execute as @a[scores={brooch_l_delay=1..,locketuse=1}] at @s run effect give @s minecraft:instant_health 1 5
execute as @a[scores={brooch_l_delay=1..,locketuse=1}] at @s run function voa:jewelry/lucky_brooch
execute as @a[scores={brooch_d_delay=1..,locketuse=1}] at @s run item replace entity @s weapon.offhand with stick[custom_name={"color":"dark_purple","italic":true,"text":"Void Brooch (Uncharged)"},custom_model_data={floats:[310000]},custom_data={brooch:1b}] 1
execute as @a[scores={brooch_d_delay=1..,locketuse=1}] at @s run effect give @s minecraft:instant_health 1 5
execute as @a[scores={brooch_d_delay=1..,locketuse=1}] at @s run function voa:jewelry/dangerous_brooch


#Tells if totem was used - For Both Brooch, Locket, and Crest
scoreboard players remove @a[scores={locketuse=1..}] locketuse 1
##### Constantly remove 1 from the delay 
execute as @a[scores={brooch_h_delay=1..}] unless entity @s[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{harmony_brooch:1b}}}}}] run scoreboard players remove @s brooch_h_delay 1
execute as @a[scores={brooch_c_delay=1..}] unless entity @s[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{chaos_brooch:1b}}}}}] run scoreboard players remove @s brooch_c_delay 1
execute as @a[scores={brooch_l_delay=1..}] unless entity @s[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{lucky_brooch:1b}}}}}] run scoreboard players remove @s brooch_l_delay 1
execute as @a[scores={brooch_d_delay=1..}] unless entity @s[nbt={equipment:{offhand:{id:'minecraft:totem_of_undying',components:{"minecraft:custom_data":{dangerous_brooch:1b}}}}}] run scoreboard players remove @s brooch_d_delay 1

#----------------------------------------------------------------------------------- Mobs ---------------------------------------------------------------------------------------------#
# <!---------------------------------------------------------------------------- Willowbee MOB------------------------------------------------------------------------------>
#---Willowbee MOB START#

## Armor Stand Rotation for body 
execute as @e[type=minecraft:bee,tag=willowbee] at @s store result entity @e[type=minecraft:armor_stand,tag=willowbee_body,limit=1,sort=nearest] Rotation[0] float 1 run data get entity @s Rotation[0]
execute as @e[type=minecraft:armor_stand,tag=willowbee_body] at @s unless entity @e[type=minecraft:bee,tag=willowbee,distance=0..2] run function voa:willowbee/death
execute as @e[type=minecraft:armor_stand,tag=willowbee_body] at @s unless entity @e[type=minecraft:bee,tag=willowbee,distance=0..2] run kill @s

## Initializes Willowbee Animation/Sound function
execute as @e[type=minecraft:bee,tag=willowbee] at @s if entity @a[distance=0..100] run function voa:willowbee/animate
## Mob is always flying and wings are always moving.
scoreboard players add @e[type=minecraft:bee,tag=willowbee,scores={animate=0..}] animate 1

## Laying "Eggs"
execute as @e[type=minecraft:bee,tag=willowbee,nbt={TicksSincePollination:1}] at @s run function voa:willowbee/eggs

## Health AOE Function
execute as @e[type=minecraft:bee,tag=willowbee,scores={heal_cool=0}] at @s if entity @a[distance=0..60] run function voa:willowbee/heal
## Activates Cooldown functionality
scoreboard players remove @e[type=minecraft:bee,tag=willowbee,scores={heal_cool=1..}] heal_cool 1

## Runs Sound File
execute as @e[type=minecraft:bee,tag=willowbee,scores={sound_cool=0}] at @s if entity @a[distance=0..20] run function voa:willowbee/sounds
## Activates Cooldown functionality
scoreboard players remove @e[tag=willowbee,type=minecraft:bee,scores={sound_cool=1..}] sound_cool 1

#SPAWN EGG FUNCTION - NEW!
execute as @e[type=minecraft:armor_stand,tag=willowbeeegg,tag=!summoned] at @s run function voa:willowbee/spawnegg
execute as @e[type=minecraft:armor_stand,tag=willowbeeegg,tag=summoned] at @s run kill @s

#Hive Commands
execute as @e[type=minecraft:bee,tag=willowbee,tag=!hived] at @s unless entity @e[type=minecraft:armor_stand,tag=willowbee_body,distance=..1] run function voa:willowbee/hive
execute as @e[type=minecraft:bee,tag=willowbee,tag=hived] at @s run tp @s ~ ~-260 ~

#---End willowbee Mob#

# <!---------------------------------------------------------------------------- Enchanted Brew MOB------------------------------------------------------------------------------>

execute as @e[type=minecraft:zombie,tag=brew_harmful] at @s if entity @a[distance=..3] run function voa:brew/harm
execute as @e[type=minecraft:zombie,tag=brew_poison] at @s if entity @a[distance=..3] run function voa:brew/poison
execute as @e[type=minecraft:zombie,tag=brew_weakness] at @s if entity @a[distance=..3] run function voa:brew/weakness
execute as @e[type=minecraft:zombie,tag=brew_levitation] at @s if entity @a[distance=..3] run function voa:brew/levitation


# <!---------------------------------------------------------------------------- Ethereal Citizen MOB------------------------------------------------------------------------------>

#Buccaneer Potion Drop
execute as @e[tag=potionhold,nbt={HurtTime:10s}] at @s run function voa:end_pirate/potionhold

#Ethereal-Citizen Aura - Casts to nearby Ethereal Fighters
execute as @e[tag=ethereal_citizen] at @s run effect give @s minecraft:conduit_power
execute as @e[tag=ethereal_citizen] at @s if entity @a[distance=..16] run particle minecraft:soul_fire_flame ~ ~1 ~ 0.25 0.25 0.25 .1 1
execute as @e[tag=ethereal_citizen] at @s if entity @a[distance=..3] run effect give @a[distance=..3] minecraft:weakness 5 0
execute as @e[tag=ethereal_citizen] at @s if entity @a[distance=..3] run effect give @a[distance=..3] minecraft:slowness 5 0

#Gladiator - Health Dependent
execute as @e[type=minecraft:stray,tag=gladiator,scores={gladiatorhealth=..120},tag=!gladhealth80] at @s run function voa:gladiator/glad80
execute as @e[type=minecraft:stray,tag=gladiator,scores={gladiatorhealth=..60},tag=!gladhealth40] at @s run function voa:gladiator/glad40
#Stores Health
execute as @e[type=minecraft:stray,tag=gladiator] run execute store result score @s gladiatorhealth run data get entity @s Health
