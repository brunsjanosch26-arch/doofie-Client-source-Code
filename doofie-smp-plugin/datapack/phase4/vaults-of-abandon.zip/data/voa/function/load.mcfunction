#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

tellraw @a {"text":"--- Vaults of Abandon : Loaded ---","color":"green"}

#----------------------------------------------------------------------------------- Scoreboards -----------------------------------------------------------------------------------------------------#
scoreboard objectives add cm_wraith dummy
scoreboard objectives add cm_abomination dummy
scoreboard objectives add cm_abyssalhorror dummy
scoreboard objectives add mob_demo_time dummy
scoreboard objectives add head_animate dummy
scoreboard objectives add harvest_cool dummy
scoreboard objectives add animate dummy
scoreboard objectives add skychecker dummy
scoreboard objectives add timeofday dummy
scoreboard objectives add sound_cool dummy
scoreboard objectives add atk_cool dummy
scoreboard objectives add atk_soar_cool dummy
scoreboard objectives add atk_dash_cool dummy
scoreboard objectives add atk_dart_cool dummy
scoreboard objectives add atk_lair_cool dummy
scoreboard objectives add petal_heal dummy
scoreboard objectives add atk_teleport dummy
scoreboard objectives add atk_flamethrower dummy
scoreboard objectives add atk_snare_cool dummy
scoreboard objectives add boss_cool dummy
scoreboard objectives add boss_health dummy
scoreboard objectives add proxy dummy
scoreboard objectives add proxy_ooze dummy
scoreboard objectives add heal_cool dummy
scoreboard objectives add yposition dummy
scoreboard objectives add xposition dummy
scoreboard objectives add zposition dummy
scoreboard objectives add coaltrain minecraft.used:minecraft.iron_sword
scoreboard objectives add irony minecraft.used:minecraft.iron_sword
scoreboard objectives add embezzler minecraft.used:minecraft.diamond_sword
scoreboard objectives add xblade_d minecraft.used:minecraft.netherite_sword
scoreboard objectives add bonelk minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add bonelk_cool dummy
scoreboard objectives add boneskt minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add bonesktrld minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add bonesktracking dummy
scoreboard objectives add bonesktready dummy
scoreboard objectives add boneskt_cool dummy
scoreboard objectives add bonespt minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add bonesptrld minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add bonesptracking dummy
scoreboard objectives add bonesptready dummy
scoreboard objectives add bonespt_cool dummy
scoreboard objectives add bonedoub minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add bonedrld minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add bonedracking dummy
scoreboard objectives add bonedready dummy
scoreboard objectives add d_bone_cool dummy
scoreboard objectives add d_bone_2nd_shot_cool dummy
scoreboard objectives add staff_h_cool dummy
scoreboard objectives add staff_h minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add staff_l_cool dummy
scoreboard objectives add staff_l minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add staff_d_cool dummy
scoreboard objectives add staff_d minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add staff_c_cool dummy
scoreboard objectives add staff_charge minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add staff_charge_up minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add staff_charge_release dummy
scoreboard objectives add staff_d_elite_cool dummy
scoreboard objectives add ghast_scepter_cool dummy
scoreboard objectives add ghast_spt minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add xblade_c_cool dummy
scoreboard objectives add staff_c minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add tome_h minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add tome_c minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add tome_c_cool dummy
scoreboard objectives add tome_l minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add Bdb_x1 dummy
scoreboard objectives add Bdb_y1 dummy
scoreboard objectives add Bdb_z1 dummy
scoreboard objectives add Bdb_x2 dummy
scoreboard objectives add Bdb_y2 dummy
scoreboard objectives add Bdb_z2 dummy
scoreboard objectives add bdb_cool dummy
scoreboard objectives add byb_cool dummy
scoreboard objectives add tf_rc dummy
scoreboard objectives add buildingtime dummy
scoreboard objectives add titanhealth dummy
scoreboard objectives add demonhealth dummy
scoreboard objectives add gladiatorhealth dummy
scoreboard objectives add locketuse minecraft.used:minecraft.totem_of_undying
scoreboard objectives add locket_h_delay dummy
scoreboard objectives add locket_l_delay dummy
scoreboard objectives add locket_c_delay dummy
scoreboard objectives add brooch_h_delay dummy
scoreboard objectives add brooch_l_delay dummy
scoreboard objectives add brooch_c_delay dummy
scoreboard objectives add brooch_d_delay dummy
scoreboard objectives add pandora_crest_delay dummy
scoreboard objectives add crucifex_crest_delay dummy
scoreboard objectives add MotionX dummy
scoreboard objectives add MotionY dummy
scoreboard objectives add MotionZ dummy
scoreboard objectives add PowerX dummy
scoreboard objectives add PowerY dummy
scoreboard objectives add PowerZ dummy
scoreboard objectives add trophy_delay dummy
scoreboard objectives add trophy_place minecraft.used:minecraft.item_frame
scoreboard objectives add end_trials_check dummy
scoreboard objectives add end_trials_score dummy
scoreboard objectives add end_trials_chaos dummy
scoreboard objectives add end_trials_chaos_countdown dummy
scoreboard objectives add end_trials_loot_countdown dummy
scoreboard objectives add dust_bomb_delay dummy
scoreboard objectives add dyna_bomb_delay dummy
scoreboard objectives add bomb_use minecraft.used:minecraft.snowball
scoreboard objectives add hellfire minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add hellfire_cool dummy


#----------------------------------------------------------------------------------- GENERATION Scoreboards -----------------------------------------------------------------------------------------------------#
scoreboard objectives add coords dummy
scoreboard objectives add constant dummy 
scoreboard players set #16 constant 16
scoreboard objectives add surfacecheck dummy
scoreboard objectives add biome dummy

#----------------------------------------------------------------------------------- Random Logic Scoreboards --------------------------------------------------------------------------------------------------------#
scoreboard objectives add dist dummy
scoreboard objectives add math dummy
scoreboard players reset * dist
scoreboard objectives add constant dummy
scoreboard players set #2 constant 2
scoreboard players set #lcg constant 1103515245

#----------------------------------------------------------------------------------- Natural Generation ---------------------------------------------------------------------------------------------#
##--- Monastery Spawn - Start ---##
#Monastery Spawn - Armor Stand Item -- THIS KICKSTARTS THE WHOLE Structure Generation
#/give @p armor_stand[entity_data={id:"minecraft:armor_stand",NoGravity:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["spawnoblisk"]}] 1
##--- Monastery Spawn End ---##

##--- Monastery QC Marker - Start ---##
#Monastery Spawn - Armor Stand Item -- THIS KICKSTARTS THE WHOLE Structure Generation
#/give @p armor_stand[custom_name='{"text":"Oblisk QC"}',entity_data={id:"minecraft:armor_stand",NoGravity:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["obliskqc"]}] 1
##--- Monastery Spawn End ---##

##--- Manor1 Spawn - Start ---##
#Manor1 Spawn - Armor Stand Item -- THIS KICKSTARTS THE WHOLE Structure Generation
#/give @p armor_stand{display:{Name:'{"text":"Manor1"}'},EntityTag:{Tags:["spawnmanor1"]}} 1
#/give @p armor_stand[custom_name='{"text":"Manor1"}',entity_data={id:"minecraft:armor_stand",Tags:["spawnmanor1"]}] 1
##--- Manor1 Spawn End ---##

##--- Manor2 Spawn - Start ---##
#Manor2 Spawn - Armor Stand Item -- THIS KICKSTARTS THE WHOLE Structure Generation
#/give @p armor_stand[custom_name='{"text":"Manor2"}',entity_data={id:"minecraft:armor_stand",Tags:["spawnmanor2"]}] 1
##--- Manor2 Spawn End ---##

##--- Manor3 Spawn - Start ---##
#Manor3 Spawn - Armor Stand Item -- THIS KICKSTARTS THE WHOLE Structure Generation
#/give @p armor_stand{display:{Name:'{"text":"Manor3"}'},EntityTag:{Tags:["spawnmanor3"]}} 1
##--- Manor2 Spawn End ---##

#----------------------------------------------------------------------------------- Structure Generation - Fixes - Sponges ----------------------------------------------------------------------------------#

##Sponge-hall
#/give @p armor_stand{display:{Name:'{"text":"Sponge-Hallway"}'},EntityTag:{Tags:["spongehall"]}} 1

##Sponge-hall-endcap (bottom floor)
#give @p armor_stand{display:{Name:'{"text":"Sponge-Endcap-Bottom"}'},EntityTag:{Tags:["spongecapbottom"]}} 1

##Sponge-hall-endcap (middle/upper floor)
#give @p armor_stand{display:{Name:'{"text":"Sponge-Endcap-Middle"}'},EntityTag:{Tags:["spongecapmidtop"]}} 1

##Sponge-hall-PLAYER
#/give @p armor_stand{display:{Name:'{"text":"Sponge-Hallway-PLAYER"}'},EntityTag:{NoGravity:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["spongehallplayer"]}} 1

##Sponge-hall-endcap (bottom floor)-PLAYER
#give @p armor_stand{display:{Name:'{"text":"Sponge-Endcap-Bottom-PLAYER"}'},EntityTag:{NoGravity:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["spongecapbottomplayer"]}} 1

##Sponge-hall-endcap (middle/upper floor)-PLAYER
#give @p armor_stand{display:{Name:'{"text":"Sponge-Endcap-Middle-PLAYER"}'},EntityTag:{NoGravity:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["spongecapmidtopplayer"]}} 1

##Sponge-ENTRY STAIRS
#/give @p armor_stand{display:{Name:'{"text":"Basement_sponge_monastery"}'},EntityTag:{Tags:["basement_sponge_monastery"]}} 1



#----------------------------------------------------------------------------------- Structure Generation - Manor - ROOMS ----------------------------------------------------------------------------------#

##Tnt-hall
#/give @p armor_stand{display:{Name:'{"text":"tntHall"}'},EntityTag:{Tags:["tnthall"]}} 1
#East West
#/give @p armor_stand{display:{Name:'{"text":"tntHallEW"}'},EntityTag:{Tags:["tnthallew"]}} 1

##Manor Distance Stopper - Set in surfance_manor
#/summon armor_stand ~ ~ ~ {NoGravity:1b,Silent:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["manor"]}


#----------------------------------------------------------------------------------- Structure Generation - Monastery - ROOMS ----------------------------------------------------------------------------------#
##--- 9x9 Oblisk Room Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"9x9Oblisk"}'},EntityTag:{Tags:["9x9oblisk"]}} 1

##--- Tower Oblisk Room Marker - Start ----##
#/give @p armor_stand[custom_name='{"text":"towerOblisk"}',entity_data={id:"minecraft:armor_stand",Tags:["toweroblisk"]}] 1

##--- Garden Oblisk Room Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Garden Oblisk"}'},EntityTag:{Tags:["gardenoblisk"]}} 1

##--- Vault-BASEMENT-Start Oblisk Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Vault-Start"}'},EntityTag:{Tags:["vaultstart"]}} 1


#----------------------------------------------------------------------------------- Structure Generation - VAULT BRICK LAYER - ROOMS ----------------------------------------------------------------------------------#
##--- Vault-NORTH-Hallway Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Vault-North-Hallway"}'},EntityTag:{NoGravity:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["vaultnorthhallway"]}} 1

##--- Vault-NORTH-Hallway Marker - QC CAP ----##
#/give @p armor_stand{display:{Name:'{"text":"North QC Cap"}'},EntityTag:{NoGravity:1b,Marker:1b,Invisible:0b,NoBasePlate:1b,Tags:["qcnorth"]}} 1

##--- Vault-SOUTH-Hallway Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Vault-South-Hallway"}'},EntityTag:{NoGravity:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["vaultsouthhallway"]}} 1

##--- Vault-SOUTH-Hallway Marker - QC CAP ----##
#/give @p armor_stand{display:{Name:'{"text":"South QC Cap"}'},EntityTag:{NoGravity:1b,Marker:1b,Invisible:0b,NoBasePlate:1b,Tags:["qcsouth"]}} 1

##--- Vault-EW-Hallway Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Vault-EASTWEST-Hallway"}'},EntityTag:{Tags:["vaulteastwesthallway"]}} 1

##--- 7x7 Small Brick Room Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"7x7Small Brick Room"}'},EntityTag:{Tags:["7x7sbr"]}} 1
#/give @p armor_stand{display:{Name:'{"text":"7x7Small Brick Room East-West"}'},EntityTag:{Tags:["7x7sbrew"]}} 1

##--- 10x10 Large Brick Room Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"10x10 Large Brick Room"}'},EntityTag:{Tags:["10x10lbr"]}} 1
#/give @p armor_stand{display:{Name:'{"text":"10x10 Large Brick Room East-West"}'},EntityTag:{Tags:["10x10lbrew"]}} 1

##--- Stairs Brick Layer Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Stairs Brick Layer"}'},EntityTag:{Tags:["sbl"]}} 1

##--- Vault Piece Brick Layer Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Vault Piece Brick Layer"}'},EntityTag:{Tags:["5x5vp"]}} 1
#/give @p armor_stand{display:{Name:'{"text":"Vault Piece Brick Layer East-West"}'},EntityTag:{Tags:["5x5vpew"]}} 1

##--- Fort - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Fort Room"}'},EntityTag:{Tags:["fort"]}} 1

##--- Fort Bossroom - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Boss Fort Room"}'},EntityTag:{Tags:["fortboss"]}} 1


#----------------------------------------------------------------------------------- Structure Generation - BASEMENT - ROOMS ----------------------------------------------------------------------------------#

##--- Basement Main - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Basement"}'},EntityTag:{Tags:["basement"]}} 1

##--- Basement Main - Rooms ----##
#/give @p armor_stand{display:{Name:'{"text":"Basement_room"}'},EntityTag:{Tags:["basement_room"]}} 1

##--- Basement Main - Sponge ----##
#/give @p armor_stand{display:{Name:'{"text":"Basement_sponge"}'},EntityTag:{Tags:["basement_sponge"]}} 1

#----------------------------------------------------------------------------------- Structure Generation - Monolith - Spawn ----------------------------------------------------------------------------------#

##--- Monolith Main - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Monolith_Start"}'},EntityTag:{Tags:["monolith_start"]}} 1

##--- Monolith Section 2 - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Monolith_Section_2"}'},EntityTag:{Tags:["monolith_2"]}} 1

##--- Monolith Section 3 - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Monolith_Section_3"}'},EntityTag:{Tags:["monolith_3"]}} 1

##--- Monolith Darkness Zone - Start ----##
#/give @p armor_stand[custom_name='{"text":"Deep Dark Blind"}',entity_data={id:"minecraft:armor_stand",NoGravity:1b,Silent:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["deep_dark_blind"]}] 1

##--- Monolith Ships NORTH - Start ----##
#/give @p armor_stand[custom_name='{"text":"Monolith_Ships_North"}',entity_data={id:"minecraft:armor_stand",NoGravity:1b,Silent:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["monolith_ships_north"]}] 1

##--- Monolith Ships South - Start ----##
#/give @p armor_stand[custom_name='{"text":"Monolith_Ships_South"}',entity_data={id:"minecraft:armor_stand",NoGravity:1b,Silent:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["monolith_ships_south"]}] 1


#----------------------------------------------------------------------------------- Structure Generation - Market - Spawn ----------------------------------------------------------------------------------#

##--- Market Main - Start ----##
#/give @p armor_stand[custom_name='"Market_Start"',entity_data={id:"minecraft:armor_stand",Tags:["market_start"]}] 1

##--- Market - Obsidian Core - Start ----##
#/give @p armor_stand[custom_name='"Market_Obi"',entity_data={id:"minecraft:armor_stand",Tags:["market_obi"]}] 1

##--- Market - Fort Room - Start ----##
#/give @p armor_stand[custom_name='"Market_Fort"',entity_data={id:"minecraft:armor_stand",Tags:["market_fort"]}] 1

##--- Market - Stall - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Market_Stall"}'},EntityTag:{Tags:["market_stall"]}} 1

##--- Market - Long - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Market_Long"}'},EntityTag:{Tags:["market_long"]}} 1

##--- Market - Large - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Market_Large"}'},EntityTag:{Tags:["market_large"]}} 1

##--- Market - Dark Room - Start ----##
#/give @p armor_stand[entity_data={id:"minecraft:armor_stand",Tags:["market_dark"]},custom_name="Market Dark"] 1

##Market Distance Stopper - Set in surface_end
#/summon armor_stand ~ ~ ~ {NoGravity:1b,Silent:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["market"]}

#----------------------------------------------------------------------------------- Structure Generation - Marina - Boats ----------------------------------------------------------------------------------#
##--- Marina Ghast-Post - Start ----##
#/give @p armor_stand[custom_name='"Ghast-Post"',entity_data={id:"minecraft:armor_stand",Tags:["ghast_post"]}] 1

##--- Marina Little Boat - Start ----##
#/give @p armor_stand[custom_name='"Boat_Little"',entity_data={id:"minecraft:armor_stand",Tags:["boat_little"]}] 1

##--- Marina Medium Boat - Start ----##
#/give @p armor_stand[custom_name='"Boat_Medium"',entity_data={id:"minecraft:armor_stand",Tags:["boat_medium"]}] 1

##--- Marina Large Boat - Start ----##
#/give @p armor_stand[custom_name='"Boat_Large"',entity_data={id:"minecraft:armor_stand",Tags:["boat_large"]}] 1

##--- Marina Station - Start ----##
#/give @p armor_stand[custom_name='"Station"',entity_data={id:"minecraft:armor_stand",Tags:["station"]}] 1

##~~~~~~~~~~~~~~~~~~~~~~ Ship Formations

##--- Marina Main - Start ----##
#/give @p armor_stand[custom_name='"Marina_Start"',entity_data={id:"minecraft:armor_stand",Tags:["marina_start"]}] 1

#----------------------------------------------------------------------------------- Spanwers  --------------------------------------------------------------------------------------------------------#
##--- Full Spawner - 100% to Spawn - (Spawns Zombie, Skeleton, Knight)
#/give @p armor_stand[custom_name='{"text":"100 Full Spawner"}',entity_data={id:"minecraft:armor_stand",Tags:["100fullspawner"]}] 1

##--- 75% Per Spawner - 75% to Spawn - (Spawns Zombie, Skeleton, Knight)
#/give @p armor_stand[custom_name='{"text":"75 Full Spawner"}',entity_data={id:"minecraft:armor_stand",Tags:["75fullspawner"]}] 1

##--- 50 Per Spawner - 50% to Spawn - (Spawns Zombie, Skeleton, Knight)
#/give @p armor_stand[custom_name='{"text":"50 Per Spawner"}',entity_data={id:"minecraft:armor_stand",Tags:["50perspawner"]}] 1

##--- Pest Spawner - 50% to Spawn - (Spawns SilverFish, Spider, CaveSpider)
#/give @p armor_stand[custom_name='{"text":"Pest Spawner"}',entity_data={id:"minecraft:armor_stand",Tags:["pestspawner"]}] 1

#----------------------------------------------------------------------------------- Custom Mobs ------------------------------------------------------------------------------------------------------#
##--- Wraith Mob START ##
# Fake player Scores for keeping track of Wraith
# Increases every eligible mob scanned
scoreboard players add wraith_count cm_wraith 0
#/give @p armor_stand[custom_name='"Wraith-Spawn-100"',entity_data={id:"minecraft:armor_stand",Tags:["spawnwraith100"]}] 1
##--- Wraith Mob END! ##


##--- Spectre Mob START ##
#--- Vault-Spectre - Armor Stand Item -- Spawn Marker
#/give @p armor_stand[custom_name='{"text":"Spectre-Spawn"}',entity_data={id:"minecraft:armor_stand",Tags:["spawnspectre"]}] 1
#/give @p armor_stand[custom_name='{"text":"Spectre-Spawn-100"}',entity_data={id:"minecraft:armor_stand",Tags:["spawnspectre100"]}] 1
##--- Spectre Mob END! ##


##--- Reaper Mob START ##
#--- Vault-Spectre - Armor Stand Item -- Spawn Marker
#/give @p armor_stand[custom_name='{"text":"Reaper-Spawn"}',entity_data={id:"minecraft:armor_stand",Tags:["spawnreaper"]}] 1
##--- Reaper Mob END! ##


##--- Abomination Mob START ###
# Fake player Scores for keeping track of Abomination
# Increases every eligible mob scanned
scoreboard players add abomination_count cm_abomination 0
#Abomination Spawn END! ##
##--- Abomination Mob END! ##


##--- Gila Monster Mob START ##
#--- Gila Monster - Armor Stand Item -- Spawn Marker
#/give @p armor_stand[custom_name='{"text":"Gila Monster - Spawn"}',entity_data={id:"minecraft:armor_stand",Tags:["spawngila"]}] 1
##--- Gila Monster Mob END! ##


##--- Abyssal Horror Mob START ###
#placeholder until spawn function is implemented
# Fake player Scores for keeping track of Abyssal Horror
# Increases every eligible mob scanned
scoreboard players add abyssalhorror_count cm_abyssalhorror 0
##--- Abyssal Horror Mob END! ##


##--- Legionnaire Brute START ##
#--- Legionnaire Brute - Armor Stand Item -- Spawn Marker
#/give @p armor_stand[custom_name='{"text":"Legionnaire-Brute-Spawn"}',entity_data={id:"minecraft:armor_stand",Tags:["legionbrute"]}] 1
##--- Legionnaire Brute END! ##


##--- Grotesque Titan Mob START ##
#--- Vault-GT - Armor Stand Item -- Spawn Marker
#/give @p armor_stand[custom_name='"Grotesque-Titan-Spawn"',entity_data={id:"minecraft:armor_stand",Tags:["spawntitan"]}] 1
#/give @p armor_stand[custom_name='"Grotesque-Titan-Spawn"',entity_data={id:"minecraft:armor_stand",Tags:["spawntitan100"]}] 1
##--- Grotesque Titan Mob END! ##


##--- Wraped Titan Mob START ##
#--- Vault-WT - Armor Stand Item -- Spawn Marker
#/give @p armor_stand[custom_name='{"text":"Warped-Titan-Spawn"}',entity_data={id:"minecraft:armor_stand",Tags:["spawnwarpedtitan"]}] 1
##--- Warped Titan Mob END! ##


##--- Axolotl Mob Chance START ##
#--- Axolotl - Armor Stand Item -- Spawn Marker
#/give @p armor_stand{display:{Name:'{"text":"Axo-Spawn"}'},EntityTag:{Tags:["axochance"]}} 1
##--- Axolotl Mob Chance END! ##


##---Willowbee Spawn Egg#
#/give @p phantom_spawn_egg{display:{Name:'{"text":"Willowbee Spawn Egg"}'},CustomModelData:555576,EntityTag:{Tags:["willowbeeegg"]}} 1
##-NEW EGG - USE THIS MODEL!
#/give @p armor_stand[custom_name='{"text":"Willowbee Spawn Egg"}',custom_model_data={floats:[100100]},entity_data={id:"minecraft:armor_stand",Tags:["willowbeeegg"]}] 1
##---Willowbee Spawn Egg END! ##

##--- Dream_Eater START ##
#--- Legionnaire Brute - Armor Stand Item -- Spawn Marker
#/give @p armor_stand[custom_name='{"text":"Dream-Eater-Spawn"}',entity_data={id:"minecraft:armor_stand",Tags:["spawndreameater"]}] 1
##--- Dream_Eater END! ##


##--- Shopkeeper NorthSouth Marker Only - lbr17
#/give @p armor_stand[custom_name='{"text":"Shopkeeper"}',entity_data={id:"minecraft:armor_stand",Tags:["shopkeeper"]}] 1

##--- MACRO CREEPERS
#/give @p armor_stand[custom_name='{"text":"Macro_Creeper"}',entity_data={id:"minecraft:armor_stand",Tags:["marco_creeper"]}] 1


##--- Flower  - BOSS - START ###
#Flower Boss Bar
bossbar add bossbar:flower "Flower"
bossbar set bossbar:flower color blue
bossbar set bossbar:flower style notched_6
bossbar set bossbar:flower max 800
##--- Flower - BOSS - END ###

##--- Petal  - BOSS - START ###
#/give @p armor_stand[custom_name="Petals Summon",entity_data={id:"minecraft:armor_stand",NoGravity:1b,Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["spawnpetal"]}] 1
#/give @p armor_stand[custom_name='{"text":"Petal Anchor"}',entity_data={id:"minecraft:armor_stand",NoGravity:1b,Silent:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["petal_anchor"]}] 1
#/give @p armor_stand[custom_name='{"text":"Petal Lair Dectection"}',entity_data={id:"minecraft:armor_stand",NoGravity:1b,Silent:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["petal_lair_detection"]}] 1
#/give @p armor_stand[custom_name='{"text":"Petal Isle Dectection"}',entity_data={id:"minecraft:armor_stand",NoGravity:1b,Silent:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["petal_isle_detection"]}] 1
#/give @p armor_stand[custom_name='{"text":"Petal Lava Field"}',entity_data={id:"minecraft:armor_stand",NoGravity:1b,Silent:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["petal_lava_field"]}] 1
#/give @p armor_stand[custom_name="Petals Minion Summon",entity_data={id:"minecraft:armor_stand",NoGravity:1b,Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["spawn_petal_minion"]}] 1

#Petal Boss Bar
bossbar add bossbar:petal "Petal"
bossbar set bossbar:petal color blue
bossbar set bossbar:petal style notched_6
bossbar set bossbar:petal max 800
##--- Petal - BOSS - END ###

##--- Nether_demon  - BOSS - START ###
#Nether_Demon Boss Bar
bossbar add bossbar:nether_demon "Tzeench - Nether Demon"
bossbar set bossbar:nether_demon color red
bossbar set bossbar:nether_demon style notched_6
bossbar set bossbar:nether_demon max 300
##--- Nether_demon - BOSS - END ###

##--- Ender_demon - BOSS - START ###
#/give @p armor_stand[custom_name='{"text":"Ender Demon"}',entity_data={id:"minecraft:armor_stand",Tags:["spawnenderdemon"]}] 1
##--- WAKE-UP Marker- 
#/give @p armor_stand[entity_data={id:"minecraft:armor_stand",NoGravity:1b,Silent:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,CustomName:'"Wake-Up-Demon"'}] 1
##--- Market Gas Main Dropdown Blocker Marker- 
#/give @p armor_stand{display:{Name:'{"text":"Market_Main_Dropdown_Gas"}'},EntityTag:{NoGravity:1b,Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["wakeup_dropdown"]}} 1
##--- WAKE-UP MIDDLE Marker- 
#/give @p armor_stand{display:{Name:'{"text":"Wake-Up-Demon-MIDDLE"}'},EntityTag:{NoGravity:1b,Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["wakeup","wakeup_middle"]}} 1
##--- Ender_demon  - BOSS - START ###
#Nether_Demon Boss Bar
bossbar add bossbar:ender_demon "Greedox - Ender Demon"
bossbar set bossbar:ender_demon color red
bossbar set bossbar:ender_demon style notched_6
bossbar set bossbar:ender_demon max 750
##--- Ender_demon - BOSS - END ###


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ End Dimension ENEMIES (Market/Monolith)---#

##--- Ethereal Single Spawn - (Armor Stand Spawn) ##
#--- Ethereal Spawner - Armor Stand Item -- Spawn Marker
#/give @p armor_stand[custom_name='"Gladiator-Spawn"',entity_data={id:"minecraft:armor_stand",Tags:["legendaryspawn"]}] 1
##--- Ethereal Brute END! ##

##--- Ethereal Pirate Single Spawn - (Armor Stand Spawn) ##
#--- Ethereal Pirate Spawner - Armor Stand Item -- Spawn Marker
#/give @p armor_stand[custom_name='{"text":"Ethereal-Pirate-Spawn"}',entity_data={id:"minecraft:armor_stand",Tags:["legendarypiratespawn"]}] 1
##--- Ethereal Brute END! ##

##--- Common End Spawner - (Spawner)
#/give @p armor_stand[custom_name='"Common End Spawner"',entity_data={id:"minecraft:armor_stand",Tags:["commonendspawner"]}] 1

##--- Enchanted Brew - (Armor Stand Spawn) ##
#/give @p armor_stand{display:{Name:'{"text":"Enchanted Brew"}'},EntityTag:{Tags:["brewspawn"]}} 1

##--- Shulker - (Armor Stand Spawn) ##
#/give @p armor_stand[custom_name='"Shulker- Spawn"',entity_data={id:"minecraft:armor_stand",Tags:["shulkerspawn"]}] 1

##--- Breeze Spawner - (Armor Stand Spawn) ##
#/give @p armor_stand[custom_name='"Breeze- Spawn"',entity_data={id:"minecraft:armor_stand",Tags:["breezespawn"]}] 1

##--- Ghast Spawner - (Armor Stand Spawn) ##
#/give @p armor_stand[custom_name='"Ghast- Spawn"',entity_data={id:"minecraft:armor_stand",Tags:["ghastspawn"]}] 1

##--- Endermite Spawner - (Armor Stand Spawn) ##
#/give @p armor_stand[entity_data={id:"minecraft:armor_stand",Tags:["endermitespawn"]},custom_name="Endermite Spawner"] 1

#----------------------------------------------------------------------------------- Mob Heads ----------------------------------------------------------------------------------------------------#
##--- Defender - Trophy
#/give @p item_frame[custom_name='"Defender Trophy"',custom_model_data={floats:[767676]},entity_data={id:"minecraft:item_frame",Item:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":767676,"minecraft:entity_data":{id:"minecraft:item_frame",Invisible:1b}}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["defender"]}] 1

##--- Defender - Trophy - End
#/give @p item_frame[custom_name='"Defender Trophy - End"',custom_model_data={floats:[777777]},entity_data={id:"minecraft:item_frame",Item:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":777777,"minecraft:entity_data":{id:"minecraft:item_frame",Invisible:1b}}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["defender_end"]}] 1

##--- Defender - Trophy - Gladiator
#/give @p item_frame[custom_name='"Defender Trophy - Gladiator"',custom_model_data={floats:[787878]},entity_data={id:"minecraft:item_frame",Item:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":787878,"minecraft:entity_data":{id:"minecraft:item_frame",Invisible:1b}}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["defender_gladiator"]}] 1


#----------------------------------------------------------------------------------- Alters/Plates ----------------------------------------------------------------------------------------------------#
##Plates------------------------- ##
##--- Plate of Weath#
#THIS CODE BELOW WAS PRIMARILY USED FOR TESTING ITEM UPON RELOADING THE DATAPACK!#
#/give @p item_frame[custom_name='{"text":"Plate of Wealth"}',custom_model_data={floats:[222223]},entity_data={id:"minecraft:item_frame",Item:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":222223}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["wealth"]}] 1
#Summon Code - Chance to spawn Plate
#/give @p armor_stand[custom_name='{"text":"Wealth Plate Oblisk"}',entity_data={id:"minecraft:armor_stand",Tags:["wealthplateOblisk"]}] 1
##Weath Plate END! ##

##--- Plate of Wrath ##
#THIS CODE BELOW WAS PRIMARILY USED FOR TEST UPON RELOADING THE DATAPACK!#
#/give @p item_frame[custom_name='{"text":"Plate of Wrath"}',custom_model_data={floats:[222222]},entity_data={id:"minecraft:item_frame",Item:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":222222}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["wrath"]}] 1
#Summon Code - Chance to spawn Plate
#/give @p armor_stand[custom_name='{"text":"Wrath Plate Oblisk"}',entity_data={id:"minecraft:armor_stand",Tags:["wrathplateOblisk"]}] 1
##Plate of Wrath END! ##

##--- Plate of Fear ##
#THIS CODE BELOW WAS PRIMARILY USED FOR TEST UPON RELOADING THE DATAPACK!#
#/give @p item_frame[custom_name='"Plate of Fear"',custom_model_data={floats:[696969]},entity_data={id:"minecraft:item_frame",Item:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":{floats:[696969]}}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["fear"]}] 1
#Summon Code - Chance to spawn Plate
#/give @p armor_stand[custom_name='{"text":"Fear Plate Oblisk"}',entity_data={id:"minecraft:armor_stand",Tags:["fearplateOblisk"]}] 1
##Plate of Wrath END! ##


##Alters------------------------- ##

##--- Wealth Alter Block#
#/give @p item_frame[custom_name='{"text":"Alter of Wealth"}',custom_model_data={floats:[151111]},entity_data={id:"minecraft:item_frame",Item:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":151111}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["wealth_alter"]}] 1
#--- Wealth Alter Marker - Start ----##
#/give @p armor_stand[custom_name='{"text":"wealthOblisk"}',entity_data={id:"minecraft:armor_stand",Tags:["wealthOblisk"]}] 1
#Wealth Alter Block END! ##
##--- Alter of Wealth END! ##

##--- Wrath Alter Block#
#/give @p item_frame[custom_name='{"text":"Wrath Alter"}',custom_model_data={floats:[1600000]},entity_data={id:"minecraft:item_frame",Item:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":1600000}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["wrath_alter"]}] 1
#--- Wrath Alter Marker - Start ----##
#/give @p armor_stand[custom_name='{"text":"wrathOblisk"}',entity_data={id:"minecraft:armor_stand",Tags:["wrathOblisk"]}] 1
#Wrath Alter Block END! ##

##--- Fear Alter Block#
#/give @p item_frame[custom_name='{"text":"Fear Alter"}',custom_model_data={floats:[1700000]},entity_data={id:"minecraft:item_frame",Item:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":1700000}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["fear_alter"]}] 1
#--- Wrath Alter Marker - Start ----##
#/give @p armor_stand[custom_name='{"text":"fearOblisk"}',entity_data={id:"minecraft:armor_stand",Tags:["fearOblisk"]}] 1
#/give @p armor_stand[custom_name='{"text":"elitefearOblisk"}',entity_data={id:"minecraft:armor_stand",Tags:["elitefearOblisk"]}] 1
#Wrath Alter Block END! ##

#----------------------------------------------------------------------------------- Potions ----------------------------------------------------------------------------------------------------------#
#Tears of Youth
#/give @p potion[custom_name='{"color":"gold","text":"Tears of Youth"}',potion_contents={custom_color:16711910,custom_effects:[{id:"minecraft:absorption",amplifier:3,duration:12000},{id:"minecraft:glowing",amplifier:0,duration:12000},{id:"minecraft:slow_falling",amplifier:0,duration:12000},{id:"minecraft:regeneration",amplifier:0,duration:12000},{id:"minecraft:fire_resistance",amplifier:0,duration:12000},{id:"minecraft:strength",amplifier:2,duration:12000},{id:"minecraft:resistance",amplifier:0,duration:12000},{id:"minecraft:speed",amplifier:0,duration:12000}]}] 1

#Wither Bomb III
#/give @p lingering_potion[custom_name='"Wither Bomb III"',potion_contents={custom_color:655360,custom_effects:[{id:"minecraft:wither",amplifier:2,duration:300}]}] 1

#Aggressive Healing Potion
#/give @p lingering_potion[potion_contents={custom_color:15073280,custom_effects:[{id:"minecraft:instant_health",amplifier:2,duration:0}]},custom_name={"color":"dark_red","text":"Aggressive Healing Potion"}] 1

#Aggressive Strength Potion
#/give @p potion[potion_contents={potion:"minecraft:long_strength",custom_color:10232336,custom_effects:[{id:"minecraft:strength",amplifier:1,duration:4800}]},custom_name={"color":"dark_red","text":"Aggressive Strength Potion"}] 1

#Aggressive Regeneration Potion
#/give @p potion[potion_contents={custom_color:12060296,custom_effects:[{id:"minecraft:regeneration",amplifier:1,duration:4800}]},custom_name={"color":"dark_purple","text":"Aggressive Regeneration Potion"}] 1

#Crisp Apple Potion
#/give @p potion[potion_contents={potion:"minecraft:thick",custom_color:16772431,custom_effects:[{id:"minecraft:absorption",amplifier:4,duration:9600},{id:"minecraft:regeneration",amplifier:0,duration:9600}]},custom_name={"color":"gold","text":"Crisp Apple Potion"}] 1

#----------------------------------------------------------------------------------- Arrows ----------------------------------------------------------------------------------------------------------#
#Undead Arrow
#/give @p tipped_arrow[potion_contents={custom_effects:[{id:"minecraft:instant_health",amplifier:4,duration:1}]},custom_name="Anti Undead Arrow"] 1

#----------------------------------------------------------------------------------- ESSENCE ----------------------------------------------------------------------------------------------------------#

##---Chaos Essence ##
#/give @p red_dye[custom_name='{"text":"Chaos Essence"}',custom_model_data={floats:[131313]},custom_data={chaos:"1b"}] 64
##---Chaos Essence END!##


##---Harmony Essence ##
#/give @p blue_dye[custom_name='"Harmony Essence"',custom_model_data={floats:[141414]},custom_data={harmony:"1b"}] 64
##---Harmony Essence END!##


##---Lucky Essence ##
#/give @p yellow_dye[custom_name='{"text":"Lucky Essence"}',custom_model_data={floats:[151515]},custom_data={lucky:"1b"}] 64
##---Lucky Essence END!##


#----------------------------------------------------------------------------------- ORBS/Runes --------------------------------------------------------------------------------------------------------#

##Rune Core ##
#give @p white_dye{display:{Name:'{"text":"Rune Core"}'},CustomModelData:331313,rune:1b} 1
##Rune Core END!##


##Chaos Orb ##
#/give @p red_dye[custom_name='{"text":"Chaos Orb"}',custom_model_data={floats:[231313]},custom_data={chaos_orb:"1b"}] 1
##Chaos Orb END!##


##Harmony Orb ##
#/give @p blue_dye[custom_name='{"text":"Harmony Orb"}',custom_model_data={floats:[241414]},custom_data={harmony_orb:"1b"}] 1
##Harmony Orb END!##


##Lucky Orb ##
#/give @p yellow_dye[custom_name='{"text":"Lucky Orb"}',custom_model_data={floats:[251515]},custom_data={lucky_orb:"1b"}] 1
##Lucky Orb END!##


##Dangerous Orb ##
#/give @p orange_dye[custom_name='{"text":"Dangerous Orb"}',custom_model_data={floats:[251515]},custom_data={dangerous_orb:"1b"}] 1
##Dangerous Orb END!##


#----------------------------------------------------------------------------------- Magic Staffs -------------------------------------------------------------------------------------------------------#

##Basic Staff ##
#/give @p stick[custom_name='{"text":"Unenchanted Staff"}',custom_model_data={floats:[303030]},custom_data={staff:"1b"}] 1
##Basic Staff END! ##

##Elite Staff ##
#/give @p stick[custom_name='{"text":"Unenchanted Godspell Staff"}',custom_model_data={floats:[303131]},custom_data={staff_mythic:"1b"}] 1
##Basic Staff END! ##

##---Battle Ghast Scepter#
##- Use Loot table command instead
scoreboard players add @a ghast_scepter_cool 0
##---Battle Ghast Spawn Egg# END! ##

##Chaos Staff ## STILL NEED TO BE CHANGED UP
#/give @p carrot_on_a_stick[custom_name='{"text":"Staff: Levitate (12 Charges)"}',custom_model_data={floats:[313131]},custom_data={staffc12:1b}] 1
#/give @p carrot_on_a_stick[custom_name='{"text":"Godspell Staff: Quantum Teleport (12 Charges)"}',custom_model_data={floats:[413131]},custom_data={staffm_c12:1b,staffm_c:1b}] 1
##### NEED TO SET UP THE CODE BELOW FOR STAFF VVV ##### 
#Initializes scoreboard so the player can use.
scoreboard players add @a staff_c_cool 0
##Chaos Staff END! ##


##Harmoneous Staff ##
#/give @p carrot_on_a_stick[custom_name='{"text":"Staff: First Aid (12 Charges)"}',custom_model_data={floats:[323232]},custom_data={staffh12:1b}] 1
#/give @p carrot_on_a_stick[custom_name='"Godspell Staff: Divine Heal (12 Charges)"',custom_model_data={floats:[423232]},custom_data={staffm_h12:1b,staffm_h:1b}] 1
##### NEED TO SET UP THE CODE BELOW FOR STAFF VVV ##### 
#Initializes scoreboard so the player can use.
scoreboard players add @a staff_h_cool 0
##Harmoneous Staff END! ##


##Lucky Staff ##
#/give @p carrot_on_a_stick[custom_name='{"text":"Staff: Chicken Claw (12 Charges)"}',custom_model_data={floats:[333333]},custom_data={staffl12:1b}] 1
#/give @p carrot_on_a_stick[custom_name='{"text":"Godspell Staff: Mob-Soul Alchemy Blast (12 Charges)"}',custom_model_data={floats:[433333]},custom_data={staffm_l12:1b,staffm_l:1b}] 1
##### NEED TO SET UP THE CODE BELOW FOR STAFF VVV ##### 
#Initializes scoreboard so the player can use.
scoreboard players add @a staff_l_cool 0
##Lucky Staff END! ##


##Dangerous Staff ##
#/give @p carrot_on_a_stick[custom_name='{"text":"Staff: Firebender (12 Charges)"}',custom_model_data={floats:[343434]},custom_data={staffd12:1b}] 1
#/give @p carrot_on_a_stick[custom_name='{"text":"Godspell Staff: Incineration (12 Charges)"}',custom_model_data={floats:[443434]},custom_data={staffm_d12:1b,staffm_d:1b}] 1
##### NEED TO SET UP THE CODE BELOW FOR STAFF VVV ##### 
#Initializes scoreboard so the player can use.
scoreboard players add @a staff_d_cool 0
scoreboard players add @a staff_d_elite_cool 0
##Dangerous Staff END! ##


#----------------------------------------------------------------------------------- X-Finity Blade -------------------------------------------------------------------------------------------------------#

##--- X-Finity Blade (Coreless) ##
#/give @p netherite_sword[custom_name='{"bold":true,"italic":true,"text":"X-Finity Blade (Coreless)"}',custom_model_data={floats:[666444]},custom_data={xblade:"1b"},enchantments={levels:{"minecraft:knockback":1,"minecraft:sharpness":3,"minecraft:unbreaking":5},show_in_tooltip:true}] 1
##--- X-Finity Blade (Coreless) ##


##--- X-Finity Blade (Chaos) ##
#/give @p netherite_sword[custom_name='{"bold":true,"italic":true,"text":"X-Finity Blade (Chaos)"}',custom_model_data={floats:[666445]},custom_data={xbladec:1b},enchantments={levels:{"minecraft:knockback":1,"minecraft:sharpness":3,"minecraft:unbreaking":5},show_in_tooltip:true}] 1
###### NEED TO SET UP THE CODE BELOW FOR STAFF VVV ##### 
##Initializes scoreboard so the player can use.
#scoreboard players add @a staff_c_cool 0
###--- X-Finity Blade (Chaos) ## END! ##


#####--- X-Finity Blade (Harmony) ## ##
#/give @p netherite_sword[custom_name='{"bold":true,"italic":true,"text":"X-Finity Blade (Harmony)"}',custom_model_data={floats:[666447]},custom_data={xbladeh:1b},enchantments={levels:{"minecraft:knockback":1,"minecraft:sharpness":3,"minecraft:smite":2,"minecraft:unbreaking":5},show_in_tooltip:true}] 1
###### NEED TO SET UP THE CODE BELOW FOR STAFF VVV ##### 
##Initializes scoreboard so the player can use.
#scoreboard players add @a staff_h_cool 0
#####--- X-Finity Blade (Harmony) ## ## END! ##


#####--- X-Finity Blade (Lucky) ## 
#/give @p netherite_sword[custom_name='{"bold":true,"italic":true,"text":"X-Finity Blade (Lucky)"}',custom_model_data={floats:[666446]},custom_data={xbladel:1b},enchantments={levels:{"minecraft:knockback":1,"minecraft:looting":2,"minecraft:sharpness":3,"minecraft:unbreaking":5},show_in_tooltip:true}] 1
###### NEED TO SET UP THE CODE BELOW FOR STAFF VVV ##### 
##Initializes scoreboard so the player can use.
#scoreboard players add @a staff_l_cool 0
#####--- X-Finity Blade (Lucky) ## 


#####--- X-Finity Blade (Dangerous) ## ##
#/give @p netherite_sword[custom_name='{"bold":true,"italic":true,"text":"X-Finity Blade (Dangerous)"}',custom_model_data={floats:[666448]},custom_data={xbladed:1b},enchantments={levels:{"minecraft:fire_aspect":2,"minecraft:knockback":1,"minecraft:sharpness":3,"minecraft:unbreaking":5},show_in_tooltip:true}] 1
###### NEED TO SET UP THE CODE BELOW FOR STAFF VVV ##### 
##Initializes scoreboard so the player can use.
#scoreboard players add @a staff_d_cool 0
#####--- X-Finity Blade (Dangerous) END! ##

#----------------------------------------------------------------------------------- Magic Tome -------------------------------------------------------------------------------------------------------#

##Magic Tome ##
#/give @p book[custom_name='{"text":"Magic Tome"}',custom_model_data={floats:[234444]},custom_data={tome:"1b"}] 1


##Chaos Tome ##
#/give @p carrot_on_a_stick[custom_name='{"text":"Tome: Stasis Field"}',custom_model_data={floats:[234445]},custom_data={tome_c:1b},enchantments={levels:{"minecraft:unbreaking":1},show_in_tooltip:false}] 1
scoreboard players add @a tome_c_cool 0


##Harmoneous Tome ##
#/give @p carrot_on_a_stick[custom_name='{"text":"Tome: Overshield"}',custom_model_data={floats:[234446]},custom_data={tome_h:1b},enchantments={levels:{"minecraft:unbreaking":1},show_in_tooltip:false}] 1


##Lucky Tome ##
#/give @p carrot_on_a_stick[custom_name='{"text":"Tome: Ring of Rabbit"}',custom_model_data={floats:[234447]},custom_data={tome_l:1b},enchantments={levels:{"minecraft:unbreaking":1},show_in_tooltip:false}] 1

#----------------------------------------------------------------------------------- Lockets ----------------------------------------------------------------------------------------------------------#

##Locket ##
#/give @p stick[custom_name='{"text":"Void Locket (Uncharged)"}',custom_model_data={floats:[313131]},custom_data={locket:"1b"}] 1
#/give @p stick[custom_name='{"text":"Void Locket (Uncharged)"}',custom_model_data={floats:[313131]},custom_data={tome_c:1b},enchantments={levels:{"minecraft:unbreaking":1},show_in_tooltip:false}] 1

##Locket ##

##Chaos locket ##
#/give @p totem_of_undying[custom_name='{"color":"dark_red","italic":true,"text":"Void Locket (Chaos)"}',custom_model_data={floats:[343434]},custom_data={chaos_locket:1b},enchantment_glint_override=true,attribute_modifiers=[{type:"generic.movement_speed",name:"generic.movement_speed",amount:.03,operation:"add_value",uuid:[I;-268625937,-1461171356,-1737445589,1349855392],slot:"offhand"}]] 1
##Locket ##

##Harmony locket ##
#/give @p totem_of_undying[custom_name='{"color":"dark_blue","italic":true,"text":"Void Locket (Harmony)"}',custom_model_data={floats:[323232]},custom_data={harmony_locket:1b},enchantment_glint_override=true,attribute_modifiers=[{type:"generic.max_health",name:"generic.max_health",amount:2,operation:"add_value",uuid:[I;-1617975544,1096698285,-1145124268,1967380553],slot:"offhand"}]] 1
##Locket ##

##Lucky locket ##
#/give @p totem_of_undying[custom_name='{"color":"gold","italic":true,"text":"Void Locket (Lucky)"}',custom_model_data={floats:[333333]},custom_data={lucky_locket:1b},enchantment_glint_override=true,attribute_modifiers=[{type:"generic.attack_damage",name:"generic.attack_damage",amount:2,operation:"add_value",uuid:[I;743081445,-1543552129,-2046876037,1580195639],slot:"offhand"}]] 1
##Locket ##

#----------------------------------------------------------------------------------- Brooches ----------------------------------------------------------------------------------------------------------#

##Brooch ##
#/give @p stick[custom_name='{"text":"Void Brooch (Uncharged)"}',custom_model_data={floats:[310000]},custom_data={brooch:"1b"}] 1
##Locket ##

##Chaos Brooch ##
#/give @p totem_of_undying[custom_name='{"color":"dark_red","italic":true,"text":"Void Brooch (Chaos)"}',custom_model_data={floats:[310003]},custom_data={chaos_brooch:1b},enchantment_glint_override=true,attribute_modifiers=[{id:"74398673496734",type:"movement_speed",amount:.03,operation:"add_value",slot:"offhand"},{id:"32896578647368376",type:"max_health",amount:4,operation:"add_value",slot:"offhand"}]] 1
##Locket ##

##Harmony Brooch ##
#/give @p totem_of_undying[custom_name='{"color":"dark_blue","italic":true,"text":"Void Brooch (Harmony)"}',custom_model_data={floats:[310001]},custom_data={harmony_brooch:1b},enchantment_glint_override=true,attribute_modifiers=[{type:"generic.max_health",name:"generic.max_health",amount:2,operation:"add_value",uuid:[I;-1924045033,1569083067,-1592899041,1659294777],slot:"offhand"},{type:"generic.attack_speed",name:"generic.attack_speed",amount:.15,operation:"add_value",uuid:[I;-2065805539,301551426,-1122894444,1363619893],slot:"offhand"}]] 1
##Locket ##

##Lucky Brooch ##
#/give @p totem_of_undying[custom_name='{"color":"gold","italic":true,"text":"Void Brooch (Lucky)"}',custom_model_data={floats:[310002]},custom_data={lucky_brooch:1b},enchantment_glint_override=true,attribute_modifiers=[{type:"generic.attack_damage",name:"generic.attack_damage",amount:3,operation:"add_value",uuid:[I;-570638120,1916093306,-1812418597,-410893104],slot:"offhand"},{type:"generic.max_health",name:"generic.max_health",amount:2,operation:"add_value",uuid:[I;-1110594501,-614513203,-1972128099,-1811069734],slot:"offhand"}]] 1
##Locket ##

##Dangerous Brooch ##
#/give @p totem_of_undying[custom_name='{"text":"Void Brooch (Dangerous)"}',custom_model_data={floats:[310004]},custom_data={dangerous_brooch:1b},enchantment_glint_override=true,attribute_modifiers=[{type:"generic.max_health",name:"generic.max_health",amount:2,operation:"add_value",uuid:[I;-1336954043,1571570581,-1905079804,-713615324],slot:"offhand"},{type:"generic.attack_damage",name:"generic.attack_damage",amount:2,operation:"add_value",uuid:[I;1560341620,344211875,-1501531721,768597365],slot:"offhand"},{type:"generic.movement_speed",name:"generic.movement_speed",amount:.03,operation:"add_value",uuid:[I;1738956120,980569555,-1257629849,-811899870],slot:"offhand"},{type:"generic.attack_speed",name:"generic.attack_speed",amount:.15,operation:"add_value",uuid:[I;-1598065921,-1287893459,-2131697285,-1878818940],slot:"offhand"}]] 1
##Locket ##

#----------------------------------------------------------------------------------- Items -----------------------------------------------------------------------------------------------------------#

##--- Bonelock ##
#/give @p carrot_on_a_stick[custom_name='{"text":"Bonelock Pistol"}',custom_model_data={floats:[977777]},custom_data={bonelock:"1b"}] 1
#Initializes scoreboard so the player can shoot.
scoreboard players add @a bonelk_cool 0
##--- Bonelock END! ##


##--- Bonesket ##
#/give @p carrot_on_a_stick[custom_name='{"text":"Bonesket"}',custom_model_data={floats:[977778]},custom_data={bonesket:"1b"},enchantments={levels:{"minecraft:knockback":1,"minecraft:sharpness":3},show_in_tooltip:false}] 1
#Initializes scoreboard so the player can shoot.
scoreboard players add @a boneskt_cool 0
scoreboard players add @a bonesktready 0
scoreboard players add @a bonesktracking 0
##--- Bonesket END! ##


##--- Bonesplitter ##
#/give @p carrot_on_a_stick[custom_name='{"text":"Bonesplitter"}',custom_model_data={floats:[888888]},custom_data={bonesplitter:"1b"},enchantments={levels:{"minecraft:knockback":1},show_in_tooltip:false}] 1
#Initializes scoreboard so the player can shoot.
scoreboard players add @a bonespt_cool 0
scoreboard players add @a bonesptready 0
scoreboard players add @a bonesptracking 0
##--- Bonesplitter END! ##


##--- Double-Bone ##
#/give @p carrot_on_a_stick[custom_name='{"text":"Double-Bone-87"}',custom_model_data={floats:[888900]},custom_data={dbone:"1b"}] 1
#Initializes scoreboard so the player can shoot.
scoreboard players add @a d_bone_cool 0
scoreboard players add @a bonedready 0
scoreboard players add @a bonedracking 0
scoreboard players add @a d_bone_2nd_shot_cool 0
##--- Double-Bone END! ##


##--- Boneshot (Ammo for Bone Weapons) ##
#/give @p stick[custom_name='{"text":"boneshot"}',custom_model_data={floats:[262626]},custom_data={boneshot:1b}] 64
##--- Bonelock END! ##


##--- Bone Dust Bomb ##
#/give @p snowball[custom_name='{"text":"Bone Dust Bomb"}',custom_model_data={floats:[100421]},custom_data={bdb:"1b"}] 1
##--- Bone Dust Bomb END! ##


##--- Dyna Bomb ##
#/give @p snowball[custom_name='{"text":"Dyna-Bomb"}',custom_model_data={floats:[100422]},custom_data={bynab:"1b"}] 1
##--- Dyna Bomb END! ##


##--- Skeel Blade ##
#THIS CODE BELOW WAS PRIMARILY USED FOR TESTING ITEM UPON RELOADING THE DATAPACK!#
#/give @p iron_sword[custom_name='{"bold":true,"italic":true,"text":"Skeel Blade"}',damage=1,custom_model_data={floats:[555555]},custom_data={skeelblade:1b},enchantments={levels:{"minecraft:knockback":3},show_in_tooltip:false}] 1
#/give @p diamond_sword[custom_name='{"bold":true,"italic":true,"text":"Elite Skeel Blade"}',damage=1,custom_model_data={floats:[555556]},custom_data={eliteskeelblade:1b},enchantments={levels:{"minecraft:knockback":4},show_in_tooltip:false}] 1
#/give @p netherite_sword[custom_name='{"bold":true,"italic":true,"text":"Ultimate Skeel Blade"}',custom_model_data={floats:[555557]},custom_data={ulitimateskeelblade:1b},enchantments={levels:{"minecraft:knockback":5},show_in_tooltip:false}] 1
##--- Skeel Blade END! ##


##--- Pestkeeper ##
#/give @p iron_sword[custom_name='{"bold":true,"italic":true,"text":"Pest Keeper"}',custom_model_data={floats:[555557]},custom_data={pestkeeper:"1b"},enchantments={levels:{"minecraft:bane_of_arthropods":5,"minecraft:sharpness":1,"minecraft:unbreaking":2},show_in_tooltip:false}] 1
scoreboard players add @a irony 0
##--- Pestkeeper END! ##


##--- Pike ##
#/give @p diamond_sword[custom_name='{"bold":true,"italic":true,"text":"Pike"}',custom_model_data={floats:[600000]},custom_data={pike:"1b"},enchantments={levels:{"minecraft:bane_of_arthropods":2,"minecraft:sweeping_edge":3,"minecraft:unbreaking":2},show_in_tooltip:true},attribute_modifiers=[{id:"attack_damage",type:"generic.attack_damage",amount:9,operation:"add_value",slot:"mainhand"},{id:"attack_speed",type:"generic.attack_speed",amount:.80,operation:"add_value",slot:"mainhand"},{id:"attack_speed",type:"generic.attack_speed",amount:.80,operation:"add_value",slot:"offhand"}]] 1
scoreboard players add @a irony 0
##--- Pestkeeper END! ##


##--- Coal-Train ##
#/give @p iron_sword[custom_name='{"bold":true,"italic":true,"text":"Coal Train"}',custom_model_data={floats:[555559]},custom_data={coaltrain:"1b"},enchantments={levels:{"minecraft:fire_aspect":3,"minecraft:knockback":2,"minecraft:sharpness":2,"minecraft:unbreaking":2},show_in_tooltip:false}] 1
scoreboard players add @a coaltrain 0
##--- Pestkeeper END! ##


##--- Spectral-Schimitar ##
#/give @p netherite_sword[custom_name='{"bold":true,"italic":true,"text":"Spectral-Scimitar"}',custom_model_data={floats:[666333]},custom_data={schimitar:"1b"},enchantments={levels:{"minecraft:smite":5,"minecraft:unbreaking":5},show_in_tooltip:false}] 1
##--- Spectral-Schimitar END! ##


##--- Cakeblade ##
#/give @p diamond_sword[custom_name='{"bold":true,"italic":true,"text":"Cake Blade"}',custom_model_data={floats:[355557]},custom_data={cakeblade:"1b"},enchantments={levels:{"minecraft:looting":3,"minecraft:sharpness":3,"minecraft:mending":1},show_in_tooltip:false}] 1
##--- CakeBlade END! ##


##--- Cookie Monster ##
#/give @p netherite_sword[custom_name='{"bold":true,"italic":true,"text":"Cookie Monster"}',custom_model_data={floats:[500001]},custom_data={cookieblade:"1b"},enchantments={levels:{"minecraft:looting":3,"minecraft:sharpness":5,"minecraft:unbreaking":3}}] 1
##--- Cookie Monster END! ##


##--- Embezzler ##
#/give @p diamond_sword[custom_name='{"bold":true,"italic":true,"text":"Emerald Embezzler"}',custom_model_data={floats:[555559]},custom_data={emeraldblade:1b},enchantments={levels:{"minecraft:looting":3,"minecraft:sharpness":3,"minecraft:mending":1},show_in_tooltip:false}] 1
scoreboard players add @a embezzler 0
##--- Embezzler END! ##


##--- Psionic Sabre ##
#/give @p netherite_sword[custom_name='{"bold":true,"italic":true,"text":"Psionic Sabre"}',custom_model_data={floats:[500000]},custom_data={psi_sabre:"1b"},enchantments={levels:{"minecraft:sharpness":6,"minecraft:unbreaking":3}}] 1
##--- Psionic Sabre END! ##


##--- Ice Sword ##
#/give @p netherite_sword[custom_name='{"bold":true,"italic":true,"text":"Ice Sword"}',custom_model_data={floats:[500002]},custom_data={ice_sword:"1b"},enchantments={levels:{"minecraft:sharpness":6,"minecraft:unbreaking":3}}] 1
##--- Ice Sword END! ##


##--- Challengers_Champion ##
#/give @p netherite_sword[custom_name='{"bold":true,"italic":true,"text":"Challengers Champion"}',custom_model_data={floats:[500003]},custom_data={champion:"1b"},enchantments={levels:{"minecraft:sharpness":7,"minecraft:unbreaking":3,"minecraft:fire_aspect":3,}}] 1
##--- Ice Sword END! ##


##--- Magic Bench Block#
#/give @p item_frame[custom_name='{"text":"Magic Bench"}',custom_model_data={floats:[727272]},entity_data={id:"minecraft:item_frame",Item:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":727272}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["magic_bench"]}] 1
#Summon Code - Chance MAGIC BENCH
#/give @p armor_stand[custom_name='{"text":"Magic Bench Marker"}',entity_data={id:"minecraft:armor_stand",Tags:["magicbenchmarker"]}] 1
##--- Magic Bench Block END! ##


##--- Enchancting Table Chance Marker# - lbr2
#/give @p armor_stand[custom_name='{"text":"Enchancting Table Chance Marker"}',entity_data={id:"minecraft:armor_stand",Tags:["enchantingtablechance"]}] 1
##--- Enchancting Table Chance Marker END! ##


##--- Treasure Chance Marker# - base12 - manor3
#/give @p armor_stand[custom_name='{"text":"Treasure Chance Marker"}',entity_data={id:"minecraft:armor_stand",Tags:["treasurechance"]}] 1
##--- Treasure Chance Marker##


##--- Pandoras Crest Frame#
#/summon glow_item_frame ~ ~ ~ {Facing:1b,Item:{id:"minecraft:totem_of_undying",count:1,components:{"minecraft:attribute_modifiers":[{id:"83421983246",type:"max_health",amount:2,operation:"add_value",slot:"offhand"},{id:"78542987932",type:"attack_damage",amount:2,operation:"add_value",slot:"offhand"},{id:"87659317829",type:"movement_speed",amount:.03,operation:"add_value",slot:"offhand"},{id:"91826987128",type:"attack_speed",amount:.3,operation:"add_value",slot:"offhand"}],"minecraft:custom_model_data":{floats:[310000]},"minecraft:custom_name":"Pandoras Crest","minecraft:lore":["Revives Upon Death; Also Opens Pandoras Box."],"minecraft:custom_data":{pandora:1b}}}}
#Summon Code - Chance MAGIC BENCH
#/give @p armor_stand[custom_name='{"text":"Pandora Crest Up"}',entity_data={id:"minecraft:armor_stand",Tags:["pandoraframeup"]}] 1
##--- Magic Bench Block END! ##

#----------------------------------------------------------------------------------- DUNGEON CHESTS -----------------------------------------------------------------------------------------------------------#

##---Vault-Light Chest#
#/setblock ~ ~ ~-1 chest{LootTable:"voa:blocks/vault_light"} replace
#/setblock ~ ~ ~-1 trapped_chest{LootTable:"voa:blocks/vault_light"} replace
#--- Vault-Light - Armor Stand Item -- Spawn Marker
#/give @p armor_stand[custom_name='{"text":"Light-Chest"}',entity_data={id:"minecraft:armor_stand",Tags:["spawnvaultlight"]}] 1
##TRAPROOM
#/give @p armor_stand[custom_name='{"text":"trapchest"}',entity_data={id:"minecraft:armor_stand",Tags:["trapchest"]}] 1
##---Vault-Light Chest END! ##

##---End-Light Chest#
#/setblock ~ ~ ~-1 chest{LootTable:"voa:blocks/end_light"} replace
#--- End-Light - Armor Stand Item -- Spawn Marker
#/give @p armor_stand[custom_name='{"text":"End-Light-Chest"}',entity_data={id:"minecraft:armor_stand",Tags:["spawnendlight"]}] 1
##---End-Light Chest END! ##



##---Vault-Medium Chest#
#/setblock ~ ~ ~-1 chest{LootTable:"voa:blocks/vault_medium"} replace
#/setblock ~ ~ ~-1 trapped_chest{LootTable:"voa:blocks/vault_medium"} replace
#--- Vault-Medium - Armor Stand Item -- Spawn Marker
#/give @p armor_stand[custom_name='{"text":"Med-Chest"}',entity_data={id:"minecraft:armor_stand",Tags:["spawnvaultmedium"]}] 1
##---Vault-Medium Chest END! ##

##---End-Medium Chest#
#/setblock ~ ~ ~-1 chest{LootTable:"voa:blocks/end_medium"} replace
#--- End-Medium - Armor Stand Item -- Spawn Marker
#/give @p armor_stand[custom_name='{"text":"End-Med-Chest"}',entity_data={id:"minecraft:armor_stand",Tags:["spawnendmedium"]}] 1
##---End-Medium Chest END! ##

##---Vault-Medium-Light Chance Chest#
#--- Vault-Medium - Armor Stand Item -- Spawn Marker
#/give @p armor_stand[custom_name='{"text":"Light-Med-Chest"}',entity_data={id:"minecraft:armor_stand",Tags:["spawnvaultlightmedium"]}] 1
##---Vault-Medium-Light Chance END! ##



##---Vault-Heavy Chest#
#/setblock ~ ~ ~-1 chest{LootTable:"voa:blocks/vault_heavy"} replace
#/setblock ~ ~ ~-1 trapped_chest{LootTable:"voa:blocks/vault_heavy"} replace
#--- Vault-Heavy - Armor Stand Item -- Spawn Marker
#/give @p armor_stand[custom_name='{"text":"Rich-Chest"}',entity_data={id:"minecraft:armor_stand",Tags:["spawnvaultrich"]}] 1
##---Vault-Heavy Chest END! ## 





##---Bookcases
#/give @p armor_stand[custom_name='{"text":"Sloop-Chest"}',entity_data={id:"minecraft:armor_stand",Tags:["bookcase_sloop"]}] 1

##---Pots
#/give @p armor_stand[custom_name='{"text":"Potion Pot"}',entity_data={id:"minecraft:armor_stand",Tags:["pot_potion"]}] 1
#/give @p armor_stand[custom_name='{"text":"Treasure Pot"}',entity_data={id:"minecraft:armor_stand",Tags:["pot_treasure"]}] 1
#/give @p armor_stand[custom_name='{"text":"Explosive Pot"}',entity_data={id:"minecraft:armor_stand",Tags:["pot_explosive"]}] 1
#/give @p armor_stand[custom_name='{"text":"Arrow Pot"}',entity_data={id:"minecraft:armor_stand",Tags:["pot_arrow"]}] 1


#----------------------------------------------------------------------------------- Event Markers - Montastery --------------------------------------------------------------------------------------------------------#
##--- Safe Breaker Marker - CATH9, sbr18 - fort2
#/give @p armor_stand[custom_name='{"text":"Cath-Vault"}',entity_data={id:"minecraft:armor_stand",Invisible:1b,Tags:["cathvault"]}] 1

##--- Blessing Marker NorthSouth Facing Room- cath8
#/give @p armor_stand[custom_name='{"text":"Bless_Event_NS"}',entity_data={id:"minecraft:armor_stand",Invisible:1b,Tags:["blessevent"]}] 1

##--- Witching Marker - sbr17 - sbr16 - fort1
#/give @p armor_stand[custom_name='{"text":"Witching_Event"}',entity_data={id:"minecraft:armor_stand",Invisible:1b,Tags:["witchevent"]}] 1

##--- Poison Trap - hallway bottom floor - Marina
#/give @p armor_stand[custom_name='{"text":"Poison Trap"}',entity_data={id:"minecraft:armor_stand",Invisible:0b,Tags:["poisontrap"]}] 1

##--- Titan - Poison Plate Trigger Trap - Marina - Monastery
#/give @p armor_stand[custom_name='{"text":"Titan Trap"}',entity_data={id:"minecraft:armor_stand",Invisible:1b,Invulnerable:1b,Marker:1b,Tags:["titantrap"]}] 1

##--- Leviation Trap - Marina
#/give @p armor_stand[custom_name='{"text":"Levi Trap"}',entity_data={id:"minecraft:armor_stand",Invisible:1b,Tags:["levitrap"]}] 1

##--- Floor Trap - Marina
#/give @p armor_stand[custom_name='{"text":"Floor Fall Trap"}',entity_data={id:"minecraft:armor_stand",Invisible:1b,Tags:["floorfalltrap"]}] 1

##--- Snare Trap - hallway bottom floor - Monolith
#/give @p armor_stand[custom_name='{"text":"Snare Trap"}',entity_data={id:"minecraft:armor_stand",Invisible:0b,Tags:["snaretrap"]}] 1

##--- Door Trap - Offices - Monolith
#/give @p armor_stand[custom_name='{"text":"Door Trap"}',entity_data={id:"minecraft:armor_stand",Invisible:0b,Tags:["doortrap"]}] 1

#----------------------------------------------------------------------------------- Event Markers - Market --------------------------------------------------------------------------------------------------------#
##--- Mining Debuff 
#/give @p armor_stand[custom_name='{"text":"Market_Mining_debuff"}',entity_data={id:"minecraft:armor_stand",Invisible:1b,Tags:["market_mine_debuff"]}] 1

##--- Market_Pet-Shop Event# 
#/give @p armor_stand[custom_name='{"text":"Market_Petshop"}',entity_data={id:"minecraft:armor_stand",Invisible:1b,Tags:["market_petshop"]}] 1

##--- Market_Material Event# 
#/give @p armor_stand[custom_name='{"text":"Market_Material"}',entity_data={id:"minecraft:armor_stand",Tags:["market_material"]}] 1

##--- Market_End_chest Event# 
#/give @p armor_stand[custom_name='{"text":"Market_End_Chest"}',entity_data={id:"minecraft:armor_stand",Tags:["market_end_chest"]}] 1

##--- Sculk Trap - hallway bottom floor
#/give @p armor_stand[custom_name='{"text":"Sculk Trap"}',entity_data={id:"minecraft:armor_stand",Invisible:0b,Tags:["sculktrap"]}] 1
##--- Sculk Trap - Gila_Egg
##/give @p item_frame[custom_name='"Gila Egg"',custom_model_data={floats:[100200]},entity_data={id:"minecraft:item_frame",Item:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":{floats:[100200]}}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["gila_egg"]}] 1
