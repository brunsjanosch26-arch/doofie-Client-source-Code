#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
# AS AND AT POSITION of custom item frame 
setblock ~ ~ ~ minecraft:quartz_slab
tag @s add placed 
