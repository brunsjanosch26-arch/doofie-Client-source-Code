#All of the code below is part of the Vaults of Abandon datapack created by Fried_Oats

summon zombie ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"voa:entities/abom_loot",PersistenceRequired:1b,Health:36f,IsBaby:0b,CanBreakDoors:1b,DrownedConversionTime:999999,Tags:["gila","voa","cryptid"],Passengers:[{id:"minecraft:armor_stand",Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["gila_body"],equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[400000]}}}}}],CustomName:"Gila Monster",equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[399999]}}}},drop_chances:{head:0.000},active_effects:[{id:"minecraft:invisibility",amplifier:1,duration:999999,show_particles:0b}],attributes:[{id:"minecraft:attack_damage",base:14},{id:"minecraft:follow_range",base:24},{id:"minecraft:knockback_resistance",base:0.45},{id:"minecraft:max_health",base:36},{id:"minecraft:movement_speed",base:0.35}]}

### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
scoreboard players add @e[tag=gila,type=minecraft:zombie,tag=!stats] sound_cool 0

tag @e[tag=gila,type=minecraft:zombie,tag=!stats] add stats

#Kills Marker
tag @s add summoned