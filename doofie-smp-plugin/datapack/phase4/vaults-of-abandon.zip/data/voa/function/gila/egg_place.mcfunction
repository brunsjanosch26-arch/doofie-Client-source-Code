#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
# AS AND AT POSITION of custom item frame 
setblock ~ ~ ~ minecraft:purple_concrete replace

execute positioned ^ ^ ^0.5 align xyz run summon armor_stand ~ ~ ~ {Fire:9999999,Small:1b,Marker:1b,Invisible:1b,Tags:["gila_egg"],equipment:{head:{id:"minecraft:item_frame",count:1,components:{custom_model_data:{floats:[100200]}}}}}
kill @s