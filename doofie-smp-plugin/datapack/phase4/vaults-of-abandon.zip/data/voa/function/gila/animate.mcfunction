#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#ABOMINATION!

#Head Movement 
execute if entity @s[scores={head_animate=0}] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run data merge entity @e[limit=1,distance=0..2.05,type=minecraft:zombie,sort=nearest,tag=gila] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[399999]}}}}}
execute if entity @s[scores={head_animate=12}] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run data merge entity @e[limit=1,distance=0..2.05,type=minecraft:zombie,sort=nearest,tag=gila] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[399998]}}}}}
execute if entity @s[scores={head_animate=21}] run scoreboard players set @s head_animate 1
##Resets Head Moving Animation
execute if entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players set @s head_animate 0
execute if entity @s[scores={head_animate=0}] run data merge entity @e[limit=1,distance=0..2.05,type=minecraft:zombie,sort=nearest,tag=gila] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[399999]}}}}}
##Detects if mob is moving - Applies head animation
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players add @s head_animate 1 

#Moving Animation - Body - Armor Stand Method
execute as @e[type=minecraft:armor_stand,tag=gila_body] at @s if entity @e[type=minecraft:zombie,tag=gila,distance=0..2.05,scores={animate=3}] run data merge entity @e[type=minecraft:armor_stand,tag=gila_body,limit=1,sort=nearest,distance=..100] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[400003]}}}}}
execute as @e[type=minecraft:armor_stand,tag=gila_body] at @s if entity @e[type=minecraft:zombie,tag=gila,distance=0..2.05,scores={animate=6}] run data merge entity @e[type=minecraft:armor_stand,tag=gila_body,limit=1,sort=nearest,distance=..100] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[400001]}}}}}
execute as @e[type=minecraft:armor_stand,tag=gila_body] at @s if entity @e[type=minecraft:zombie,tag=gila,distance=0..2.05,scores={animate=6}] run playsound minecraft:block.basalt.step hostile @a ~ ~ ~ 0.1
execute as @e[type=minecraft:armor_stand,tag=gila_body] at @s if entity @e[type=minecraft:zombie,tag=gila,distance=0..2.05,scores={animate=9}] run data merge entity @e[type=minecraft:armor_stand,tag=gila_body,limit=1,sort=nearest,distance=..100] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[400003]}}}}}
execute as @e[type=minecraft:armor_stand,tag=gila_body] at @s if entity @e[type=minecraft:zombie,tag=gila,distance=0..2.05,scores={animate=12}] run data merge entity @e[type=minecraft:armor_stand,tag=gila_body,limit=1,sort=nearest,distance=..100] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[400000]}}}}}
execute as @e[type=minecraft:armor_stand,tag=gila_body] at @s if entity @e[type=minecraft:zombie,tag=gila,distance=0..2.05,scores={animate=15}] run data merge entity @e[type=minecraft:armor_stand,tag=gila_body,limit=1,sort=nearest,distance=..100] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[400004]}}}}}
execute as @e[type=minecraft:armor_stand,tag=gila_body] at @s if entity @e[type=minecraft:zombie,tag=gila,distance=0..2.05,scores={animate=18}] run data merge entity @e[type=minecraft:armor_stand,tag=gila_body,limit=1,sort=nearest,distance=..100] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[400002]}}}}}
execute as @e[type=minecraft:armor_stand,tag=gila_body] at @s if entity @e[type=minecraft:zombie,tag=gila,distance=0..2.05,scores={animate=18}] run playsound minecraft:block.basalt.step hostile @a ~ ~ ~ 0.1
execute as @e[type=minecraft:armor_stand,tag=gila_body] at @s if entity @e[type=minecraft:zombie,tag=gila,distance=0..2.05,scores={animate=21}] run data merge entity @e[type=minecraft:armor_stand,tag=gila_body,limit=1,sort=nearest,distance=..100] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[400004]}}}}}
execute if entity @e[type=minecraft:zombie,tag=gila,distance=0..2.05,scores={animate=21..}] run scoreboard players set @s animate 1
##Resets Body Moving Animation
execute if entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players set @s animate 0
execute as @e[type=minecraft:armor_stand,tag=gila_body] at @s if entity @e[type=minecraft:zombie,tag=gila,distance=0..2.05,scores={animate=0}] run data merge entity @e[type=minecraft:armor_stand,tag=gila_body,limit=1,sort=nearest,distance=..100] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[400000]}}}}}
##Detects if mob is moving - Applies body animation
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players add @s animate 1 

#Damage Sound
execute if entity @s[nbt={HurtTime:10s}] run playsound minecraft:gila.mob.hurt hostile @a[distance=0..10]

#Detects if mob is moving
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players add @s animate 1 
