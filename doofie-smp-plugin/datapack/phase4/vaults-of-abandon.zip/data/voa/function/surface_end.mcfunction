#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#This file performs the Surface detection, and runs the command that spawns the Vault.

#say TETTITORY

#Stops Spawning if the structure is within a certain distance of a dungeon
execute as @s at @s store result score @s xposition run data get entity @s Pos[0]
execute as @s at @s store result score @s zposition run data get entity @s Pos[2]
execute as @s at @s[scores={xposition=-4050..4050,zposition=-4050..4050}] at @s run tag @s add territory
#Stops Spawning if the structure is within a certain distance of a dungeon
execute as @s at @s if entity @e[type=minecraft:armor_stand,tag=market,distance=..2400] run tag @s add territory


#Natural Air Scoreboard + Confirm Testing w/ output prompt --- WORKS, But doesn't test for ground!
#If failed to detect Water, Checks for Surface v
execute as @s[tag=!territory] at @s if block ~ 58 ~ minecraft:end_stone run function voa:natural_generation/ground/surface_valid
#If Failed to detect surface, Checks for Air
execute as @s[tag=!groundblock,tag=!territory] at @s if block ~ 58 ~ #minecraft:air_lock run function voa:natural_generation/ground/air
#If Pass, Spawns Structure
execute as @s[tag=!groundblock,tag=wehaveair,tag=!territory] at @s if block ~ 58 ~ #minecraft:air_lock run function voa:natural_generation/ground/spawn_structure_templates_market/58
#If Failed Ground Check, Removes ground tag
execute as @s[tag=groundblock,tag=!spawnvaultgen,tag=!territory] at @s run tag @s remove groundblock



#If failed to detect Water, Checks for Surface v
execute as @s[tag=!spawnvaultgen,tag=!territory] at @s if block ~ 59 ~ minecraft:end_stone run function voa:natural_generation/ground/surface_valid
#If Failed to detect surface, Checks for Air
execute as @s[tag=!groundblock,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 59 ~ #minecraft:air_lock run function voa:natural_generation/ground/air
#If Pass, Spawns Structure
execute as @s[tag=!groundblock,tag=wehaveair,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 59 ~ #minecraft:air_lock run function voa:natural_generation/ground/spawn_structure_templates_market/59
#If Failed Ground Check, Removes ground tag
execute as @s[tag=groundblock,tag=!spawnvaultgen,tag=!territory] at @s run tag @s remove groundblock



#If failed to detect Water, Checks for Surface v
execute as @s[tag=!spawnvaultgen,tag=!territory] at @s if block ~ 60 ~ minecraft:end_stone run function voa:natural_generation/ground/surface_valid
#If Failed to detect surface, Checks for Air
execute as @s[tag=!groundblock,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 60 ~ #minecraft:air_lock run function voa:natural_generation/ground/air
#If Pass, Spawns Structure
execute as @s[tag=!groundblock,tag=wehaveair,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 60 ~ #minecraft:air_lock run function voa:natural_generation/ground/spawn_structure_templates_market/60
#If Failed Ground Check, Removes ground tag
execute as @s[tag=groundblock,tag=!spawnvaultgen,tag=!territory] at @s run tag @s remove groundblock



#If failed to detect Water, Checks for Surface v
execute as @s[tag=!spawnvaultgen,tag=!territory] at @s if block ~ 61 ~ minecraft:end_stone run function voa:natural_generation/ground/surface_valid
#If Failed to detect surface, Checks for Air
execute as @s[tag=!groundblock,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 61 ~ #minecraft:air_lock run function voa:natural_generation/ground/air
#If Pass, Spawns Structure
execute as @s[tag=!groundblock,tag=wehaveair,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 61 ~ #minecraft:air_lock run function voa:natural_generation/ground/spawn_structure_templates_market/61
#If Failed Ground Check, Removes ground tag
execute as @s[tag=groundblock,tag=!spawnvaultgen,tag=!territory] at @s run tag @s remove groundblock



#If failed to detect Water, Checks for Surface v
execute as @s[tag=!spawnvaultgen,tag=!territory] at @s if block ~ 62 ~ minecraft:end_stone run function voa:natural_generation/ground/surface_valid
#If Failed to detect surface, Checks for Air
execute as @s[tag=!groundblock,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 62 ~ #minecraft:air_lock run function voa:natural_generation/ground/air
#If Pass, Spawns Structure
execute as @s[tag=!groundblock,tag=wehaveair,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 62 ~ #minecraft:air_lock run function voa:natural_generation/ground/spawn_structure_templates_market/62
#If Failed Ground Check, Removes ground tag
execute as @s[tag=groundblock,tag=!spawnvaultgen,tag=!territory] at @s run tag @s remove groundblock



#If failed to detect Water, Checks for Surface v
execute as @s[tag=!spawnvaultgen,tag=!territory] at @s if block ~ 63 ~ minecraft:end_stone run function voa:natural_generation/ground/surface_valid
#If Failed to detect surface, Checks for Air
execute as @s[tag=!groundblock,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 63 ~ #minecraft:air_lock run function voa:natural_generation/ground/air
#If Pass, Spawns Structure
execute as @s[tag=!groundblock,tag=wehaveair,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 63 ~ #minecraft:air_lock run function voa:natural_generation/ground/spawn_structure_templates_market/63
#If Failed Ground Check, Removes ground tag
execute as @s[tag=groundblock,tag=!spawnvaultgen,tag=!territory] at @s run tag @s remove groundblock



#If failed to detect Water, Checks for Surface v
execute as @s[tag=!spawnvaultgen,tag=!territory] at @s if block ~ 64 ~ minecraft:end_stone run function voa:natural_generation/ground/surface_valid
#If Failed to detect surface, Checks for Air
execute as @s[tag=!groundblock,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 64 ~ #minecraft:air_lock run function voa:natural_generation/ground/air
#If Pass, Spawns Structure
execute as @s[tag=!groundblock,tag=wehaveair,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 64 ~ #minecraft:air_lock run function voa:natural_generation/ground/spawn_structure_templates_market/64
#If Failed Ground Check, Removes ground tag
execute as @s[tag=groundblock,tag=!spawnvaultgen,tag=!territory] at @s run tag @s remove groundblock
