#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks


#Scoreboard Load
recipe give @s voa:boneshot

#Makes Run once
tag @s add recipevoa