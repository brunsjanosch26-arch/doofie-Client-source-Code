#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Runs Sound at Player
playsound minecraft:entity.firework_rocket.launch ambient @a[]

#Armor Stand is the stasis
summon armor_stand ~ ~ ~ {NoGravity:1b,Silent:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["stasis"]}

### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
scoreboard players add @e[type=minecraft:armor_stand,tag=stasis,sort=nearest,limit=1] tome_c_cool 300

