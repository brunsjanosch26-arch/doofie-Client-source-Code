#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

tag @s add dangerous_brooch
execute as @e[type=!#voa:not_mob] at @s if entity @a[distance=..18,tag=dangerous_brooch] run data merge entity @s {Fire:600}
tag @s remove dangerous_brooch
