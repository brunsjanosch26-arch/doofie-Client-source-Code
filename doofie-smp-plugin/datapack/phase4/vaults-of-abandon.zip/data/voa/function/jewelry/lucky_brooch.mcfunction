#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Runs Sound at Player
playsound minecraft:entity.egg.throw ambient @a[] 
particle minecraft:happy_villager ~ ~ ~ 2 2 2 .2 200 normal

execute as @e[type=!player,type=!#voa:not_mob,type=!#voa:ridable,type=!end_crystal,distance=..4,tag=!ring,tag=!titan,tag=!warpedtitan,tag=!gladiator,type=!ravager,type=!warden,type=!wither,type=!ender_dragon,tag=!boss] at @s run tag @s add ring
execute as @e[type=!player,type=!#voa:not_mob,type=!#voa:ridable,type=!end_crystal,distance=..4,tag=ring,tag=!titan,tag=!warpedtitan,tag=!gladiator,type=!ravager,type=!warden,type=!wither,type=!ender_dragon,tag=!boss] at @s run playsound minecraft:block.anvil.land player @a ~ ~ ~ 
execute as @e[type=!player,type=!#voa:not_mob,type=!#voa:ridable,type=!end_crystal,tag=ring,tag=!titan,tag=!warpedtitan,type=!ravager,tag=!gladiator,type=!warden,type=!wither,type=!ender_dragon,tag=!boss] at @s run particle minecraft:large_smoke ~ ~ ~ 3 3 3 0.3 50 normal
execute as @e[type=!player,type=!#voa:not_mob,type=!#voa:ridable,type=!end_crystal,tag=ring,tag=!titan,tag=!warpedtitan,type=!ravager,tag=!gladiator,type=!warden,type=!wither,type=!ender_dragon,tag=!boss] at @s run summon minecraft:iron_golem ~ ~ ~
execute as @e[tag=ring] at @s run tp @s ~ ~-256 ~

#Gladiator Mechanic
#Execute if above 50% Health
execute as @e[tag=gladiator,type=minecraft:stray,scores={gladiatorhealth=60..},distance=..5] at @s run damage @s 50 minecraft:player_attack at ~ ~ ~
execute as @e[tag=gladiator,type=minecraft:stray,scores={gladiatorhealth=60..},distance=..5] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 10 normal
#Execute if below 50% Health
execute as @e[tag=gladiator,type=minecraft:stray,scores={gladiatorhealth=..60},distance=..5] at @s run summon minecraft:iron_golem ~ ~ ~
execute at @e[tag=gladiator,type=minecraft:stray,scores={gladiatorhealth=..60},distance=..5] at @s run playsound minecraft:block.anvil.land player @a ~ ~ ~ 
execute at @e[tag=gladiator,type=minecraft:stray,scores={gladiatorhealth=..60},distance=..5] at @s run particle minecraft:large_smoke ~ ~ ~ 3 3 3 0.3 50 normal
execute as @e[tag=gladiator,type=minecraft:stray,scores={gladiatorhealth=..60},distance=..5] at @s run tp @s ~ ~-256 ~

#Titan Mechanic
#Execute if above 50% Health
execute as @e[tag=titan,type=minecraft:zombie,scores={titanhealth=50..},distance=..5] at @s run damage @s 50 minecraft:player_attack at ~ ~ ~
execute as @e[tag=titan,type=minecraft:zombie,scores={titanhealth=50..},distance=..5] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 10 normal
#Execute if below 50% Health
execute as @e[tag=titan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run summon minecraft:iron_golem ~ ~ ~
execute at @e[tag=titan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run playsound minecraft:block.anvil.land player @a ~ ~ ~ 
execute at @e[tag=titan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run particle minecraft:large_smoke ~ ~ ~ 3 3 3 0.3 50 normal
execute as @e[tag=titan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run tp @s ~ ~-256 ~

#Warped-Titan Mechanic
#Execute if above 50% Health
execute as @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=50..},distance=..5] at @s run damage @s 50 minecraft:player_attack at ~ ~ ~
execute as @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=50..},distance=..5] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 10 normal
#Execute if below 50% Health
execute as @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run summon minecraft:iron_golem ~ ~ ~
execute at @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run playsound minecraft:block.anvil.land player @a ~ ~ ~ 
execute at @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run particle minecraft:large_smoke ~ ~ ~ 3 3 3 0.3 50 normal
execute as @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run tp @s ~ ~-256 ~

#Ravager Mechanic
#Execute if above 50% Health
execute as @e[type=minecraft:ravager,scores={titanhealth=53..},distance=..5] at @s run damage @s 50 minecraft:player_attack at ~ ~ ~
execute as @e[type=minecraft:ravager,scores={titanhealth=53..},distance=..5] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 10 normal
#Execute if below 50% Health
execute as @e[type=minecraft:ravager,scores={titanhealth=..53},distance=..5] at @s run summon minecraft:iron_golem ~ ~ ~
execute at @e[type=minecraft:ravager,scores={titanhealth=..53},distance=..5] at @s run playsound minecraft:block.anvil.land player @a ~ ~ ~ 
execute at @e[type=minecraft:ravager,scores={titanhealth=..53},distance=..5] at @s run particle minecraft:large_smoke ~ ~ ~ 3 3 3 0.3 50 normal
execute as @e[type=minecraft:ravager,scores={titanhealth=..53},distance=..5] at @s run tp @s ~ ~-256 ~

#Warden Mechanic
#Execute if above 50% Health
execute as @e[type=minecraft:warden,scores={titanhealth=53..},distance=..5] at @s run damage @s 50 minecraft:player_attack at ~ ~ ~
execute as @e[type=minecraft:warden,scores={titanhealth=53..},distance=..5] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 10 normal
#Execute if below 50% Health
execute as @e[type=minecraft:warden,scores={titanhealth=..53},distance=..5] at @s run summon minecraft:iron_golem ~ ~ ~
execute at @e[type=minecraft:warden,scores={titanhealth=..53},distance=..5] at @s run playsound minecraft:block.anvil.land player @a ~ ~ ~ 
execute at @e[type=minecraft:warden,scores={titanhealth=..53},distance=..5] at @s run particle minecraft:large_smoke ~ ~ ~ 3 3 3 0.3 50 normal
execute as @e[type=minecraft:warden,scores={titanhealth=..53},distance=..5] at @s run tp @s ~ ~-256 ~


