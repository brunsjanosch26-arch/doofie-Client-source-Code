#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#This file performs the Surface detection, and runs the command that spawns the Vault.

#say Shippi

#Stops Spawning if the structure is within a certain distance of a dungeon
execute as @s at @s store result score @s xposition run data get entity @s Pos[0]
execute as @s at @s store result score @s zposition run data get entity @s Pos[2]

execute as @s at @s[scores={xposition=-1050..1050,zposition=-1050..1050}] at @s run tag @s add territory
#Stops Spawning if the structure is within a certain distance of a dungeon


#Natural Air Scoreboard + Confirm Testing w/ output prompt --- WORKS, But doesn't test for ground!
#If failed to detect Water, Checks for Surface v
execute as @s[tag=!territory] at @s unless entity @e[type=minecraft:armor_stand,tag=marina,distance=..1200] run function voa:natural_generation/ground/spawn_structure_templates_marina/130