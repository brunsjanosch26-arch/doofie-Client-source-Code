#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#Summon Willowbee
scoreboard players add @e[type=minecraft:happy_ghast,tag=!stats] ghast_scepter_cool 0

tag @s add stats

