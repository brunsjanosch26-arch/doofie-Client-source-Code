#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# Tag prevents current caster from being detected


#execute at @s run effect give @e[type=!area_effect_cloud,type=!experience_orb,type=!armor_stand,type=!item_frame,type=!player,type=!item,type=!arrow,type=!#voa:undead,distance=0..2.5,limit=1,sort=nearest] minecraft:instant_damage 1 1 true
execute at @s run effect give @e[type=!area_effect_cloud,type=!experience_orb,type=!armor_stand,type=!item_frame,type=!player,type=!item,type=!arrow,distance=0..1.5,limit=1,sort=nearest] minecraft:slowness 8 1 true
execute at @s run effect give @e[type=!area_effect_cloud,type=!experience_orb,type=!armor_stand,type=!item_frame,type=!player,type=!item,type=!arrow,distance=0..1.5,limit=1,sort=nearest] minecraft:weakness 8 1 true


execute as @s run damage @s[] 20 minecraft:player_attack by @e[type=happy_ghast,tag=raycasting,limit=1,sort=nearest]


tag @s remove ghast_shot
