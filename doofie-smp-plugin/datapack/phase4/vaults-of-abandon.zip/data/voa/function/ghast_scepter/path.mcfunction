#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#This function gives the bullet its Trajectery

#This function gives the bullet its Trajectery
# Using dx for precise hitbox detection
# Parameters:
#     Edit not_mob.json in tags/entities to change which entities will not be targetted
#     Change the "positioned" offsets to change projectile size
#       - If > 1 block, just use one dx detection
execute as @e[tag=!raycasting,type=!#voa:not_mob,dx=0] positioned ~-0.99 ~-0.99 ~-0.99 if entity @s[dx=0] positioned ~0.99 ~0.99 ~0.99 run function voa:ghast_scepter/collide

scoreboard players add .distance tf_rc 1

#Life-force
damage @s 2

# Make raycast visible
particle minecraft:snowflake ~ ~ ~ 0 0 0 0 0

# Repeat the raycast if certain conditions are met
# Parameters:
#    (score after "matches") * (accuracy increment) = range
#    The "positioned" value specifies the precision
#    Edit raycast_pass.json in tags/blocks to change which blocks the raycast ignores
#    "rotated" controls arc/curve of raycast path
execute if score .distance tf_rc matches ..1000 positioned ^ ^ ^0.1 rotated ~ ~ unless block ~ ~ ~ #voa:raycast_pass run function voa:ghast_scepter/collide_surface
execute if score .distance tf_rc matches ..1000 positioned ^ ^ ^0.1 rotated ~ ~ if block ~ ~ ~ #voa:raycast_pass run function voa:ghast_scepter/path

