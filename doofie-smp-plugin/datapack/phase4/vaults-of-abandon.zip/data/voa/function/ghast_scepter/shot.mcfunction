#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# Tag prevents current caster from being detected
tag @s add raycasting

# Anchor to the eyes and position with vector coordinates (Remove if not running from eyes of entity)
execute anchored eyes positioned ^ ^-4 ^2 run function voa:ghast_scepter/path
execute anchored eyes positioned ^ ^-4 ^2 run particle minecraft:soul_fire_flame ~ ~ ~ 0.5 0.5 0.5 0.01 100
execute as @e[tag=ghast_shot] at @s run function voa:ghast_scepter/dmg

# Remove the raycasting tag after raycast completion to prepare fo the next player
tag @s remove raycasting
scoreboard players reset .distance tf_rc

#Plays Sound
playsound minecraft:entity.ghast.warn ambient @a[distance=..20] ~ ~ ~ 3
playsound minecraft:entity.ghast.shoot ambient @a[distance=..20] ~ ~ ~ 3



#Sets Cooldown between shots - or rate of fire.
scoreboard players set @s ghast_scepter_cool 60
