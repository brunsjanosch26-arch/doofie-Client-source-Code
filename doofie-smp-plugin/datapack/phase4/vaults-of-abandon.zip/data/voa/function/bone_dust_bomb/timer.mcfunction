#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#Sounds
execute at @s run playsound minecraft:entity.firework_rocket.blast master @a[]

#Particles
execute at @s run particle minecraft:explosion ~ ~ ~ 3 3 3 .3 20 normal
execute at @s run particle flash{color:[1.000,1.000,1.000,1.00]} ~ ~ ~ 0 0 0 1 0 normal

#Explosion/effects
execute at @s run effect give @e[distance=0..8,type=!player] slowness 12 2
execute at @s run effect give @e[distance=0..8,type=!player] weakness 12 2
execute at @s run effect give @e[distance=0..8,type=player] speed 12 1

#Kills Snowball
execute at @s run kill @s

#B-E-A-G-L-E-B-L-O-C-K-S