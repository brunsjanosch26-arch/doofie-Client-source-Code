#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Spawn Structure
setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -17, mode: "LOAD", posY: 2, sizeX: 35, posZ: -17, integrity: 1.0f, showair: 0b, name: "voa:mont_three", id: "minecraft:structure_block", sizeY: 34, sizeZ: 35, showboundingbox: 1b}
setblock ~ ~1 ~ minecraft:redstone_block

tag @s add summoned