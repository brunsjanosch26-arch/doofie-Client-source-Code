#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

##North Side Ships
summon armor_stand ~4 ~4 ~15 {Tags:["boat_large"]}

tag @s add summoned