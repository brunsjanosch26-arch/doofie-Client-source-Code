#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#This file performs the Surface detection, and runs the command that spawns the Vault.

#say TETTITORY

#Stops Spawning if the structure is within a certain distance of a dungeon
execute as @s at @s store result score @s xposition run data get entity @s Pos[0]
execute as @s at @s store result score @s zposition run data get entity @s Pos[2]
execute as @s at @s[scores={xposition=-1050..1050,zposition=-1050..1050}] at @s run tag @s add territory
execute as @s at @s if entity @e[type=minecraft:armor_stand,tag=wealth_alter,distance=0..1650] run tag @s add territory

#Natural Air Scoreboard + Confirm Testing w/ output prompt --- WORKS, But doesn't test for ground!
#Checks For Water v
execute if block ~ 62 ~ minecraft:water run function voa:natural_generation/ground/water
#If failed to detect Water, Checks for Surface v
execute as @s[tag=!waterhazard,tag=!territory] at @s if block ~ 64 ~ #minecraft:surface run function voa:natural_generation/ground/surface_valid
#If Failed to detect surface, Checks for Air
execute as @s[tag=!waterhazard,tag=!groundblock,tag=!territory] at @s if block ~ 64 ~ #minecraft:air_lock run function voa:natural_generation/ground/air
#If Pass, Spawns Structure
execute as @s[tag=!waterhazard,tag=!groundblock,tag=wehaveair,tag=!territory] at @s if block ~ 64 ~ #minecraft:air_lock run function voa:natural_generation/ground/spawn_structure_templates/64
#If Failed Ground Check, Removes ground tag
execute as @s[tag=!waterhazard,tag=groundblock,tag=!spawnvaultgen,tag=!territory] at @s run tag @s remove groundblock



#If failed to detect Water, Checks for Surface v
execute as @s[tag=!waterhazard,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 65 ~ #minecraft:surface run function voa:natural_generation/ground/surface_valid
#If Failed to detect surface, Checks for Air
execute as @s[tag=!waterhazard,tag=!groundblock,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 65 ~ #minecraft:air_lock run function voa:natural_generation/ground/air
#If Pass, Spawns Structure
execute as @s[tag=!waterhazard,tag=!groundblock,tag=wehaveair,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 65 ~ #minecraft:air_lock run function voa:natural_generation/ground/spawn_structure_templates/65
#If Failed Ground Check, Removes ground tag
execute as @s[tag=!waterhazard,tag=groundblock,tag=!spawnvaultgen,tag=!territory] at @s run tag @s remove groundblock



#If failed to detect Water, Checks for Surface v
execute as @s[tag=!waterhazard,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 66 ~ #minecraft:surface run function voa:natural_generation/ground/surface_valid
#If Failed to detect surface, Checks for Air
execute as @s[tag=!waterhazard,tag=!groundblock,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 66 ~ #minecraft:air_lock run function voa:natural_generation/ground/air
#If Pass, Spawns Structure
execute as @s[tag=!waterhazard,tag=!groundblock,tag=wehaveair,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 66 ~ #minecraft:air_lock run function voa:natural_generation/ground/spawn_structure_templates/66
#If Failed Ground Check, Removes ground tag
execute as @s[tag=!waterhazard,tag=groundblock,tag=!spawnvaultgen,tag=!territory] at @s run tag @s remove groundblock



#If failed to detect Water, Checks for Surface v
execute as @s[tag=!waterhazard,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 67 ~ #minecraft:surface run function voa:natural_generation/ground/surface_valid
#If Failed to detect surface, Checks for Air
execute as @s[tag=!waterhazard,tag=!groundblock,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 67 ~ #minecraft:air_lock run function voa:natural_generation/ground/air
#If Pass, Spawns Structure
execute as @s[tag=!waterhazard,tag=!groundblock,tag=wehaveair,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 67 ~ #minecraft:air_lock run function voa:natural_generation/ground/spawn_structure_templates/67
#If Failed Ground Check, Removes ground tag
execute as @s[tag=!waterhazard,tag=groundblock,tag=!spawnvaultgen,tag=!territory] at @s run tag @s remove groundblock



#If failed to detect Water, Checks for Surface v
execute as @s[tag=!waterhazard,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 68 ~ #minecraft:surface run function voa:natural_generation/ground/surface_valid
#If Failed to detect surface, Checks for Air
execute as @s[tag=!waterhazard,tag=!groundblock,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 68 ~ #minecraft:air_lock run function voa:natural_generation/ground/air
#If Pass, Spawns Structure
execute as @s[tag=!waterhazard,tag=!groundblock,tag=wehaveair,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 68 ~ #minecraft:air_lock run function voa:natural_generation/ground/spawn_structure_templates/68
#If Failed Ground Check, Removes ground tag
execute as @s[tag=!waterhazard,tag=groundblock,tag=!spawnvaultgen,tag=!territory] at @s run tag @s remove groundblock



#If failed to detect Water, Checks for Surface v
execute as @s[tag=!waterhazard,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 69 ~ #minecraft:surface run function voa:natural_generation/ground/surface_valid
#If Failed to detect surface, Checks for Air
execute as @s[tag=!waterhazard,tag=!groundblock,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 69 ~ #minecraft:air_lock run function voa:natural_generation/ground/air
#If Pass, Spawns Structure
execute as @s[tag=!waterhazard,tag=!groundblock,tag=wehaveair,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 69 ~ #minecraft:air_lock run function voa:natural_generation/ground/spawn_structure_templates/69
#If Failed Ground Check, Removes ground tag
execute as @s[tag=!waterhazard,tag=groundblock,tag=!spawnvaultgen,tag=!territory] at @s run tag @s remove groundblock



#If failed to detect Water, Checks for Surface v
execute as @s[tag=!waterhazard,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 70 ~ #minecraft:surface run function voa:natural_generation/ground/surface_valid
#If Failed to detect surface, Checks for Air
execute as @s[tag=!waterhazard,tag=!groundblock,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 70 ~ #minecraft:air_lock run function voa:natural_generation/ground/air
#If Pass, Spawns Structure
execute as @s[tag=!waterhazard,tag=!groundblock,tag=wehaveair,tag=!spawnvaultgen,tag=!territory] at @s if block ~ 70 ~ #minecraft:air_lock run function voa:natural_generation/ground/spawn_structure_templates/70
#If Failed Ground Check, Removes ground tag
execute as @s[tag=!waterhazard,tag=groundblock,tag=!spawnvaultgen,tag=!territory] at @s run tag @s remove groundblock
