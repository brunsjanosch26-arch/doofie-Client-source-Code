#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function - 
scoreboard players set in math 0
scoreboard players set in1 math 30
function voa:natural_generation/random/range_lcg

#If 1 is selected, the following happens - Also Controls BN/VOA Loot Tables
#Books
execute if score out math matches 0 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=true,slot_1_occupied=false,slot_2_occupied=true,slot_3_occupied=true,slot_4_occupied=true,slot_5_occupied=false]{Items:[{Slot:0b,id:"minecraft:book",count:1},{Slot:2b,id:"minecraft:book",count:1},{Slot:3b,id:"minecraft:book",count:1},{Slot:4b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 0 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 1 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=true,slot_1_occupied=false,slot_2_occupied=true,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=false]{Items:[{Slot:0b,id:"minecraft:book",count:1},{Slot:2b,id:"minecraft:book",count:1},{Slot:4b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 1 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 2 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=false,slot_1_occupied=false,slot_2_occupied=true,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=true]{Items:[{Slot:2b,id:"minecraft:book",count:1},{Slot:4b,id:"minecraft:book",count:1},{Slot:5b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 2 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 3 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=false,slot_1_occupied=true,slot_2_occupied=false,slot_3_occupied=true,slot_4_occupied=false,slot_5_occupied=false]{Items:[{Slot:1b,id:"minecraft:book",count:1},{Slot:3b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 3 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 16 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=true,slot_1_occupied=false,slot_2_occupied=true,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=false]{Items:[{Slot:0b,id:"minecraft:book",count:1},{Slot:2b,id:"minecraft:book",count:1},{Slot:4b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 16 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 17 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=true,slot_1_occupied=false,slot_2_occupied=true,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=false]{Items:[{Slot:0b,id:"minecraft:book",count:1},{Slot:2b,id:"minecraft:book",count:1},{Slot:4b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 17 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 18 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=true,slot_1_occupied=false,slot_2_occupied=true,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=false]{Items:[{Slot:0b,id:"minecraft:book",count:1},{Slot:2b,id:"minecraft:book",count:1},{Slot:4b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 18 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 19 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=true,slot_1_occupied=false,slot_2_occupied=true,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=false]{Items:[{Slot:0b,id:"minecraft:book",count:1},{Slot:2b,id:"minecraft:book",count:1},{Slot:4b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 19 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 20 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=true,slot_1_occupied=false,slot_2_occupied=true,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=false]{Items:[{Slot:0b,id:"minecraft:book",count:1},{Slot:2b,id:"minecraft:book",count:1},{Slot:4b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 20 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 21 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=false,slot_1_occupied=true,slot_2_occupied=false,slot_3_occupied=true,slot_4_occupied=false,slot_5_occupied=false]{Items:[{Slot:1b,id:"minecraft:book",count:1},{Slot:3b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 21 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 22 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=false,slot_1_occupied=true,slot_2_occupied=false,slot_3_occupied=true,slot_4_occupied=false,slot_5_occupied=false]{Items:[{Slot:1b,id:"minecraft:book",count:1},{Slot:3b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 22 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 23 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=false,slot_1_occupied=true,slot_2_occupied=false,slot_3_occupied=true,slot_4_occupied=false,slot_5_occupied=false]{Items:[{Slot:1b,id:"minecraft:book",count:1},{Slot:3b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 23 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 26 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=false,slot_1_occupied=true,slot_2_occupied=false,slot_3_occupied=true,slot_4_occupied=false,slot_5_occupied=false]{Items:[{Slot:1b,id:"minecraft:book",count:1},{Slot:3b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 26 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 27 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=false,slot_1_occupied=true,slot_2_occupied=false,slot_3_occupied=true,slot_4_occupied=false,slot_5_occupied=false]{Items:[{Slot:1b,id:"minecraft:book",count:1},{Slot:3b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 27 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 28 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=false,slot_1_occupied=true,slot_2_occupied=false,slot_3_occupied=true,slot_4_occupied=false,slot_5_occupied=false]{Items:[{Slot:1b,id:"minecraft:book",count:1},{Slot:3b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 28 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 29 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=false,slot_1_occupied=true,slot_2_occupied=false,slot_3_occupied=true,slot_4_occupied=false,slot_5_occupied=false]{Items:[{Slot:1b,id:"minecraft:book",count:1},{Slot:3b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 29 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 30 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=false,slot_1_occupied=true,slot_2_occupied=false,slot_3_occupied=true,slot_4_occupied=false,slot_5_occupied=false]{Items:[{Slot:1b,id:"minecraft:book",count:1},{Slot:3b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 30 run setblock ~ ~ ~ minecraft:purpur_block

#Enchanted Bookshelves
execute if score out math matches 4 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=true,slot_1_occupied=false,slot_2_occupied=false,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=false]{Items:[{Slot:0b,id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:unbreaking":3}}},{Slot:4b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 4 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 5 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=false,slot_1_occupied=true,slot_2_occupied=true,slot_3_occupied=true,slot_4_occupied=false,slot_5_occupied=false]{Items:[{Slot:1b,id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:feather_falling":4}}},{Slot:2b,id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:protection":4}}},{Slot:3b,id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:smite":5}}}]} replace
execute if score out math matches 5 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 6 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=false,slot_1_occupied=false,slot_2_occupied=false,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=true]{Items:[{Slot:4b,id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:power":5}}},{Slot:5b,id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:sweeping_edge":3}}}]} replace
execute if score out math matches 6 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 7 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=true,slot_1_occupied=false,slot_2_occupied=false,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=false]{Items:[{Slot:0b,id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:feather_falling":4}}},{Slot:4b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 7 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 8 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=true,slot_1_occupied=false,slot_2_occupied=false,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=false]{Items:[{Slot:0b,id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:silk_touch":4}}},{Slot:4b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 8 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 9 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=true,slot_1_occupied=false,slot_2_occupied=false,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=false]{Items:[{Slot:0b,id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:multishot":4}}},{Slot:4b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 9 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 10 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=true,slot_1_occupied=false,slot_2_occupied=false,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=false]{Items:[{Slot:0b,id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:thorns":3}}},{Slot:4b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 10 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 11 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=true,slot_1_occupied=false,slot_2_occupied=false,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=false]{Items:[{Slot:0b,id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:mending":1}}},{Slot:4b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 11 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 12 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=true,slot_1_occupied=false,slot_2_occupied=false,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=false]{Items:[{Slot:0b,id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:looting":3}}},{Slot:4b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 12 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 13 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=true,slot_1_occupied=false,slot_2_occupied=false,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=false]{Items:[{Slot:0b,id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:fire_aspect":2}}},{Slot:4b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 13 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 14 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=true,slot_1_occupied=false,slot_2_occupied=false,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=false]{Items:[{Slot:0b,id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:infinity":1}}},{Slot:4b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 14 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 15 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=false,slot_1_occupied=false,slot_2_occupied=false,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=true]{Items:[{Slot:4b,id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:loyalty":3}}},{Slot:5b,id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:piercing":3}}}]} replace
execute if score out math matches 15 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 24 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=true,slot_1_occupied=false,slot_2_occupied=false,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=false]{Items:[{Slot:0b,id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:protection":4}}},{Slot:4b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 24 run setblock ~ ~ ~ minecraft:purpur_block
execute if score out math matches 25 run setblock ~ ~1 ~ chiseled_bookshelf[facing=south,slot_0_occupied=true,slot_1_occupied=false,slot_2_occupied=false,slot_3_occupied=false,slot_4_occupied=true,slot_5_occupied=false]{Items:[{Slot:0b,id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:bane_of_arthropods":5}}},{Slot:4b,id:"minecraft:book",count:1}]} replace
execute if score out math matches 25 run setblock ~ ~ ~ minecraft:purpur_block







tag @s add summoned