#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function - 
scoreboard players set in math 0
scoreboard players set in1 math 9
function voa:natural_generation/random/range_lcg

#If 1 is selected, the following happens - Also Controls BN/VOA Loot Tables
#Books
execute if score out math matches 0 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:gunpowder",count:3},sherds:["minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd","minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd"]} replace
execute if score out math matches 6 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:gunpowder",count:2},sherds:["minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd","minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd"]} replace
execute if score out math matches 7 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:gunpowder",count:1},sherds:["minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd","minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd"]} replace

execute if score out math matches 1 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:flint",count:1},sherds:["minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd","minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd"]} replace

execute if score out math matches 2 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:firework_rocket",count:3},sherds:["minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd","minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd"]} replace
execute if score out math matches 8 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:firework_rocket",count:2},sherds:["minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd","minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd"]} replace
execute if score out math matches 9 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:firework_rocket",count:1},sherds:["minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd","minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd"]} replace

execute if score out math matches 3 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:iron_ingot",count:3},sherds:["minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd","minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd"]} replace

execute if score out math matches 4 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:paper",count:3},sherds:["minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd","minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd"]} replace

execute if score out math matches 5 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:tnt",count:1},sherds:["minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd","minecraft:burn_pottery_sherd","minecraft:danger_pottery_sherd"]} replace

tag @s add summoned