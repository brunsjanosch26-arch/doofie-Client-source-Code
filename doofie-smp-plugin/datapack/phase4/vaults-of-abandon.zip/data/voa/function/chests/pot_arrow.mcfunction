#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function - 
scoreboard players set in math 0
scoreboard players set in1 math 4
function voa:natural_generation/random/range_lcg

#If 1 is selected, the following happens - Also Controls BN/VOA Loot Tables
#Books
execute if score out math matches 0 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:arrow",count:3},sherds:["minecraft:archer_pottery_sherd","minecraft:shelter_pottery_sherd","minecraft:archer_pottery_sherd","minecraft:shelter_pottery_sherd"]} replace
execute if score out math matches 1 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:arrow",count:2},sherds:["minecraft:archer_pottery_sherd","minecraft:shelter_pottery_sherd","minecraft:archer_pottery_sherd","minecraft:shelter_pottery_sherd"]} replace
execute if score out math matches 2 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:arrow",count:1},sherds:["minecraft:archer_pottery_sherd","minecraft:shelter_pottery_sherd","minecraft:archer_pottery_sherd","minecraft:shelter_pottery_sherd"]} replace
execute if score out math matches 3 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:tipped_arrow",count:1,components:{"minecraft:potion_contents":{custom_effects:[{id:"minecraft:instant_health",amplifier:2,duration:1}]},"minecraft:custom_name":"Anti Undead Arrow"}},sherds:["minecraft:archer_pottery_sherd","minecraft:shelter_pottery_sherd","minecraft:archer_pottery_sherd","minecraft:shelter_pottery_sherd"]} replace
execute if score out math matches 4 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:tipped_arrow",count:3,components:{"minecraft:potion_contents":{custom_effects:[{id:"minecraft:instant_health",amplifier:2,duration:1}]},"minecraft:custom_name":"Anti Undead Arrow"}},sherds:["minecraft:archer_pottery_sherd","minecraft:shelter_pottery_sherd","minecraft:archer_pottery_sherd","minecraft:shelter_pottery_sherd"]} replace


tag @s add summoned