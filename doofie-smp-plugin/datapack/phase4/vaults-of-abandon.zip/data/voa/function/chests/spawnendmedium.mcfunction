#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function - 
scoreboard players set in math 0
scoreboard players set in1 math 1
function voa:natural_generation/random/range_lcg

#B-E-A-G-L-E-B-L-O-C-K-S

#Spawn Chest Vault-Medium
execute if score out math matches 1 if entity @a[tag=authentication] run setblock ~ ~ ~ chest{LootTable:"voa:blocks/end_medium_bn"}
execute if score out math matches 1 if entity @a[tag=!authentication] run setblock ~ ~ ~ chest{LootTable:"voa:blocks/end_medium"}

tag @s add summoned