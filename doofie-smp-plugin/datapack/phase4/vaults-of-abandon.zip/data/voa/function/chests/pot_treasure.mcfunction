#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function - 
scoreboard players set in math 0
scoreboard players set in1 math 8
function voa:natural_generation/random/range_lcg

#If 1 is selected, the following happens - Also Controls BN/VOA Loot Tables
#Books
execute if score out math matches 0 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:diamond",count:1},sherds:["minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd","minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd"]} replace

execute if score out math matches 1 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:emerald",count:3},sherds:["minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd","minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd"]} replace

execute if score out math matches 2 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:gold_ingot",count:2},sherds:["minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd","minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd"]} replace

execute if score out math matches 3 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:iron_ingot",count:3},sherds:["minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd","minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd"]} replace

execute if score out math matches 4 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:ancient_debris",count:1},sherds:["minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd","minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd"]} replace

execute if score out math matches 5 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:diamond",count:1},sherds:["minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd","minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd"]} replace

execute if score out math matches 6 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:emerald",count:3},sherds:["minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd","minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd"]} replace

execute if score out math matches 7 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:gold_ingot",count:2},sherds:["minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd","minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd"]} replace

execute if score out math matches 8 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:iron_ingot",count:3},sherds:["minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd","minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd"]} replace

execute if score out math matches 9 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:diamond",count:1},sherds:["minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd","minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd"]} replace

execute if score out math matches 10 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:emerald",count:3},sherds:["minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd","minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd"]} replace

execute if score out math matches 11 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:gold_ingot",count:2},sherds:["minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd","minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd"]} replace

execute if score out math matches 12 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:iron_ingot",count:3},sherds:["minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd","minecraft:prize_pottery_sherd","minecraft:plenty_pottery_sherd"]} replace



tag @s add summoned