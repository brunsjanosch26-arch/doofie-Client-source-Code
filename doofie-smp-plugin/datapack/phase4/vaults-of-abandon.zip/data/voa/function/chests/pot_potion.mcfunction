#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function - 
scoreboard players set in math 0
scoreboard players set in1 math 4
function voa:natural_generation/random/range_lcg

#If 1 is selected, the following happens - Also Controls BN/VOA Loot Tables
#Books
execute if score out math matches 0 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:experience_bottle",count:1},sherds:["minecraft:guster_pottery_sherd","minecraft:brewer_pottery_sherd","minecraft:guster_pottery_sherd","minecraft:brewer_pottery_sherd"]} replace

execute if score out math matches 1 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:lingering_potion",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:strong_healing"}}},sherds:["minecraft:guster_pottery_sherd","minecraft:brewer_pottery_sherd","minecraft:guster_pottery_sherd","minecraft:brewer_pottery_sherd"]} replace

execute if score out math matches 2 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:potion",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:thick",custom_color:16777169,custom_effects:[{id:"minecraft:slow_falling",amplifier:1,duration:9600}]}}},sherds:["minecraft:guster_pottery_sherd","minecraft:brewer_pottery_sherd","minecraft:guster_pottery_sherd","minecraft:brewer_pottery_sherd"]} replace

execute if score out math matches 3 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:golden_apple",count:1},sherds:["minecraft:guster_pottery_sherd","minecraft:brewer_pottery_sherd","minecraft:guster_pottery_sherd","minecraft:brewer_pottery_sherd"]} replace

execute if score out math matches 4 run setblock ~ ~ ~ decorated_pot{item:{id:"minecraft:ender_pearl",count:1},sherds:["minecraft:guster_pottery_sherd","minecraft:brewer_pottery_sherd","minecraft:guster_pottery_sherd","minecraft:brewer_pottery_sherd"]} replace

tag @s add summoned