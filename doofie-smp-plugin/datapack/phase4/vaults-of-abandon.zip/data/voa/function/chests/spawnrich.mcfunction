#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Spawn Chest Vault-Heavy
execute if entity @a[tag=authentication] run setblock ~ ~ ~ chest{LootTable:"voa:blocks/vault_heavy_bn"}
execute if entity @a[tag=!authentication] run setblock ~ ~ ~ chest{LootTable:"voa:blocks/vault_heavy"}

tag @s add summoned