#RNG
scoreboard players set in math 0
scoreboard players set in1 math 3
function voa:natural_generation/random/range_lcg

#Random Chance - Removal

#Very Good
execute as @s if score out math matches 0 run effect give @s minecraft:absorption 300 14
execute as @s if score out math matches 0 run effect give @s minecraft:regeneration 300 2
execute as @s if score out math matches 0 run effect give @s minecraft:strength 300 2

#Good
execute as @s if score out math matches 1 run effect give @s minecraft:instant_health 20 0

#Bad
execute as @s if score out math matches 2 run effect give @s minecraft:instant_health 10 0
execute as @s if score out math matches 2 run effect give @s minecraft:slowness 300 0
execute as @s if score out math matches 2 run effect give @s minecraft:levitation 10 0
execute as @s if score out math matches 2 run effect give @s minecraft:resistance 300 2
execute as @s if score out math matches 2 run effect give @s minecraft:infested 300 2
execute as @s if score out math matches 2 run effect give @s minecraft:oozing 300 2
execute as @s if score out math matches 2 run effect give @s minecraft:weaving 300 2

#Very Bad
execute as @s if score out math matches 3 run effect give @s minecraft:darkness 60 0
execute as @s if score out math matches 3 run effect give @s minecraft:poison 60 2
execute as @s if score out math matches 3 run effect give @s minecraft:slowness 60 2
execute as @s if score out math matches 3 run effect give @s minecraft:weakness 60 0
execute as @s if score out math matches 3 run effect give @s minecraft:unluck 60 0