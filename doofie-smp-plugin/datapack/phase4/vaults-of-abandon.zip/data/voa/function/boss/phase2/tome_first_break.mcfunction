#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Control_Choice Sequence - Picks the Enemy

#Fancy Particles and Sounds
playsound minecraft:ambient.cave hostile @a[] ~ ~ ~ 4 
particle minecraft:soul_fire_flame ~7.5 ~ ~.5 12 12 12 .05 4000

##Tome Selection
#say IM a TOMEC
tag @s add tomec

#say IM a TOMEH
tag @s add tomeh

execute if entity @s[tag=boss,type=minecraft:zombified_piglin,tag=phase2] run data merge entity @e[limit=1,distance=0..2,type=minecraft:zombified_piglin,sort=nearest,tag=boss,tag=phase2] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[730004]}}}},mainhand:{id:"minecraft:air",count:1},HandDropChances:[0.000F,0.085F]}
