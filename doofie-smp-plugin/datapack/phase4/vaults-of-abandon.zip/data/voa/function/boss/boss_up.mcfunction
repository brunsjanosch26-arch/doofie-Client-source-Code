#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#say BOOOO!

execute at @s run playsound minecraft:ambient.cave ambient @a[distance=..100] ~ ~ ~ 5

#Phase One Up
execute if entity @e[tag=down,tag=boss,tag=phase1,type=minecraft:zombified_piglin,sort=nearest,limit=1] run data merge entity @e[tag=down,tag=boss,type=minecraft:zombified_piglin,sort=nearest,limit=1] {Invulnerable:1b,equipment:{head:{id:'minecraft:flint',count:1,components:{"minecraft:custom_model_data":{floats:[730000]}}}},attributes:[{id:attack_damage,base:12}]}
execute if entity @e[tag=down,tag=boss,tag=phase1,type=minecraft:zombified_piglin,sort=nearest,limit=1] run effect clear @s minecraft:resistance

#Phase Two Up 
execute if entity @e[tag=down,tag=boss,tag=phase2,type=minecraft:zombified_piglin,sort=nearest,limit=1] run data merge entity @e[tag=down,tag=boss,type=minecraft:zombified_piglin,sort=nearest,limit=1] {Invulnerable:0b,equipment:{head:{id:'minecraft:flint',count:1,components:{"minecraft:custom_model_data":{floats:[730000]}}}},attributes:[{id:follow_range,base:50},{id:knockback_resistance,base:.9},{id:movement_speed,base:0.33},{id:attack_damage,base:13}]}




tag @s remove down
tag @s add canattack



