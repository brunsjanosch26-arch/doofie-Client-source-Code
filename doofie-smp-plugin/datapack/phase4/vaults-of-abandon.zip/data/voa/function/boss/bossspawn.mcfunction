#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

### Battle ----------------------------------------------------------------------------------------------------------------------------------------------- #Prelude#

#Note for Summoners
say Relieve the flaming bats of their suffering to lower Flower's protective shield!

### Destroys Key on Alter
execute as @e[type=minecraft:item_frame,tag=wrath,tag=placed,limit=1,sort=nearest] at @s run tag @s add used
#Spawns Boss -Destroys Plate Placeholder
execute as @e[type=minecraft:item_frame,tag=wrath,tag=placed,limit=1,sort=nearest] at @s run setblock ~ ~ ~ minecraft:air replace

### Summons Effects and Clears Torches 
particle minecraft:soul_fire_flame ~7.5 ~ ~.5 3 4 3 .02 700 normal
execute at @s run playsound minecraft:ambient.cave ambient @a[] ~ ~ ~ 4
execute at @s run playsound minecraft:entity.lightning_bolt.thunder ambient @a[] ~ ~ ~ 4
#Bottom Half Torches
fill ~-16 ~ ~-24 ~30 ~10 ~24 air replace minecraft:torch
fill ~-16 ~ ~-24 ~30 ~10 ~24 air replace minecraft:wall_torch
#Top Half Torches
fill ~-16 ~10 ~-24 ~30 ~20 ~24 air replace minecraft:torch
fill ~-16 ~10 ~-24 ~30 ~20 ~24 air replace minecraft:wall_torch

### Spawns Enemies - Spawns Spooks - Selects which RNG will spawn in enemies
execute at @e[type=minecraft:armor_stand,tag=wrath_alter,limit=1,sort=nearest,tag=!alpha1,tag=!beta1] at @s run function voa:boss/rngspawn
execute at @e[type=minecraft:armor_stand,tag=wrath_alter,limit=1,sort=nearest,tag=alpha1] at @s run function voa:boss/alpha/alpha1
execute at @e[type=minecraft:armor_stand,tag=wrath_alter,limit=1,sort=nearest,tag=beta1] at @s run function voa:boss/beta/beta1
execute at @e[type=minecraft:armor_stand,tag=wrath_alter,limit=1,sort=nearest] at @s run function voa:boss/control/control_choice_teleport

### Spawns Boss ----------------------------------------------------------------------------------------------------------------------------------------- #Boss Start#
summon zombified_piglin ~7.5 ~ ~.5 {NoGravity:0b,Silent:1b,Invulnerable:1b,CustomNameVisible:0b,DeathLootTable:"voa:entities/boss_loot",PersistenceRequired:1b,Health:800f,CanBreakDoors:1b,Tags:["boss","voa","flower","ghost"],CustomName:"Flower",equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[730000]}}}},drop_chances:{head:0.000},active_effects:[{id:"minecraft:jump_boost",amplifier:1,duration:99999,show_particles:0b},{id:"minecraft:invisibility",amplifier:1,duration:999999,show_particles:0b}],attributes:[{id:"minecraft:attack_damage",base:12},{id:"minecraft:follow_range",base:8},{id:"minecraft:knockback_resistance",base:2},{id:"minecraft:max_health",base:800},{id:"minecraft:movement_speed",base:0}]}
#### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
scoreboard players add @e[tag=boss,type=minecraft:zombified_piglin,sort=nearest,limit=1] sound_cool 0
scoreboard players add @e[tag=boss,type=minecraft:zombified_piglin,sort=nearest,limit=1] boss_cool 0
scoreboard players add @e[tag=boss,type=minecraft:zombified_piglin,sort=nearest,limit=1] atk_cool 240
execute as @e[tag=boss,type=minecraft:zombified_piglin,sort=nearest,limit=1] at @s run tag @s add phase1
execute as @e[tag=boss,type=minecraft:zombified_piglin,sort=nearest,limit=1] at @s run tag @s add canattack

#Initializes Boss health Scoreboard - THIS IS ONLY USED FOR A PHASE 2, NOT BOSSBAR
scoreboard players add @e[tag=boss,type=minecraft:zombified_piglin,limit=1,sort=nearest] boss_health 0
### Spawns Boss -- #Boss END#

#Clears Old Chests - if present
setblock ~8 ~ ~-6 minecraft:air replace
setblock ~6 ~ ~-6 minecraft:air replace

setblock ~8 ~ ~6 minecraft:air replace
setblock ~6 ~ ~6 minecraft:air replace

setblock ~14 ~ ~1 minecraft:air replace
setblock ~14 ~ ~-1 minecraft:air replace

### Frame ----------------------------------------------------------------------------------------------------------------------------------------------- #Plate Kill#

#KILL ITEM FRAME - Plate Texture
kill @e[type=minecraft:item_frame,tag=wrath,tag=placed,tag=used,limit=1,sort=nearest]