#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Teleports all players to flower
execute as @a[distance=..40] at @s run tp @a[distance=..40] @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,tag=tomec,limit=1,sort=nearest]
playsound minecraft:entity.lightning_bolt.impact ambient @a ~ ~ ~ 4

#Sets Effects
execute as @a[distance=..40] at @s run effect give @a[distance=..40] minecraft:blindness 6 1 
execute as @a[distance=..40] at @s run effect give @a[distance=..40] minecraft:wither 6 4
execute as @a[distance=..40] at @s run effect give @a[distance=..40] minecraft:slowness 6 2

#Gives Flower
effect give @s minecraft:resistance 6 1

#B-E-A-G-L-E-B-L-O-C-K-S