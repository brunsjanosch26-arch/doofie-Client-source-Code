#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Control_Choice Sequence - Picks the Enemy
effect give @s minecraft:instant_damage 1 3

effect give @a[distance=..40] minecraft:instant_damage 1 1
execute as @a[distance=..40] at @s run particle minecraft:witch ~ ~ ~ .5 1 .5 .2 30

playsound minecraft:entity.player.levelup ambient @a[] ~ ~ ~ 4