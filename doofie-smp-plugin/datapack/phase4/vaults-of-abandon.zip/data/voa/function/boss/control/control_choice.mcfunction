#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Control_Choice Sequence - Picks the Enemy

##Picks Between Wraith or Spectre

#randomizer function - 50/50 odds
scoreboard players set in math 0
scoreboard players set in1 math 23
function voa:natural_generation/random/range_lcg

#Fancy Particles and Sounds
playsound minecraft:ambient.cave hostile @a[] ~7.5 ~ ~.5 4 
particle minecraft:cloud ~7.5 ~ ~.5 12 12 12 .05 4000

##Bottom Floor
execute if score out math matches 0 run summon armor_stand ~25 ~ ~19 {Tags:["spawnwraith100"]}
execute if score out math matches 1 run summon armor_stand ~25 ~ ~19 {Tags:["spawnspectre100"]}

execute if score out math matches 2 run summon armor_stand ~26 ~ ~-18 {Tags:["spawnwraith100"]}
execute if score out math matches 3 run summon armor_stand ~26 ~ ~-18 {Tags:["spawnspectre100"]}

execute if score out math matches 4 run summon armor_stand ~-11 ~ ~-19 {Tags:["spawnwraith100"]}
execute if score out math matches 5 run summon armor_stand ~-11 ~ ~-19 {Tags:["spawnspectre100"]}

execute if score out math matches 6 run summon armor_stand ~-12 ~ ~18 {Tags:["spawnwraith100"]}
execute if score out math matches 7 run summon armor_stand ~-12 ~ ~18 {Tags:["spawnspectre100"]}


##Middle Floor
execute if score out math matches 8 run summon armor_stand ~-2 ~8 ~-17 {Tags:["spawnwraith100"]}
execute if score out math matches 9 run summon armor_stand ~-2 ~8 ~-17 {Tags:["spawnspectre100"]}

execute if score out math matches 10 run summon armor_stand ~-2 ~8 ~18 {Tags:["spawnwraith100"]}
execute if score out math matches 11 run summon armor_stand ~-2 ~8 ~18 {Tags:["spawnspectre100"]}

execute if score out math matches 12 run summon armor_stand ~17 ~8 ~-17 {Tags:["spawnwraith100"]}
execute if score out math matches 13 run summon armor_stand ~17 ~8 ~-17 {Tags:["spawnspectre100"]}

execute if score out math matches 14 run summon armor_stand ~17 ~8 ~18 {Tags:["spawnwraith100"]}
execute if score out math matches 15 run summon armor_stand ~17 ~8 ~18 {Tags:["spawnspectre100"]}

##Top Floor
execute if score out math matches 16 run summon armor_stand ~-9 ~14 ~-16 {Tags:["spawnwraith100"]}
execute if score out math matches 17 run summon armor_stand ~-9 ~14 ~-16 {Tags:["spawnspectre100"]}

execute if score out math matches 18 run summon armor_stand ~-9 ~14 ~16 {Tags:["spawnwraith100"]}
execute if score out math matches 19 run summon armor_stand ~-9 ~14 ~16 {Tags:["spawnspectre100"]}

execute if score out math matches 20 run summon armor_stand ~23 ~14 ~16 {Tags:["spawnwraith100"]}
execute if score out math matches 21 run summon armor_stand ~23 ~14 ~16 {Tags:["spawnspectre100"]}

execute if score out math matches 22 run summon armor_stand ~23 ~14 ~-16 {Tags:["spawnwraith100"]}
execute if score out math matches 23 run summon armor_stand ~23 ~14 ~-16 {Tags:["spawnspectre100"]}

