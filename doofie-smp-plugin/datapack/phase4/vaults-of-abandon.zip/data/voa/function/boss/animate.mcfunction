#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Moving Animation 
execute if entity @s[scores={animate=1},tag=phase2] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run data merge entity @e[limit=1,distance=0..2,type=minecraft:zombified_piglin,sort=nearest,tag=boss,tag=phase2] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[730003]}}},mainhand:{id:"minecraft:air",count:1}}}

#Resets Moving Animation 
execute if entity @s[nbt={Motion:[0.0d,0.0d,0.0d]},tag=phase2] run scoreboard players set @s animate 0
execute if entity @s[scores={animate=0},tag=phase2] run data merge entity @e[limit=1,distance=0..2,type=minecraft:zombified_piglin,sort=nearest,tag=boss,tag=phase2] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[730002]}}},mainhand:{id:"minecraft:air",count:1}}}

#Damage Sound
execute if entity @s[nbt={HurtTime:10s}] run playsound minecraft:wraith.mob.hurt hostile @a[distance=0..10]

#Detects if mob is moving
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]},tag=phase2] run scoreboard players add @s animate 1 

#B-E-A-G-L-E-B-L-O-C-K-S
