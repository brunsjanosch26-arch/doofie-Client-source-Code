#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

### Battle ----------------------------------------------------------------------------------------------------------------------------------------------- #Prelude#

#Note for Summoners
say Bring an end to flower's reign, one way or another.

### Summons Effects and Clears Torches 
particle minecraft:soul_fire_flame ~7.5 ~ ~.5 3 4 3 .02 700 normal
execute at @s run playsound minecraft:ambient.cave ambient @a[distance=..100]
execute at @s run playsound minecraft:entity.lightning_bolt.thunder ambient @a[distance=..100]
#Bottom Half Torches
fill ~-16 ~ ~-24 ~30 ~10 ~24 air replace minecraft:torch
fill ~-16 ~ ~-24 ~30 ~10 ~24 air replace minecraft:wall_torch
#Top Half Torches
fill ~-16 ~10 ~-24 ~30 ~20 ~24 air replace minecraft:torch
fill ~-16 ~10 ~-24 ~30 ~20 ~24 air replace minecraft:wall_torch

#Tag Handling
execute as @e[tag=boss,type=minecraft:zombified_piglin,sort=nearest,limit=1] at @s run tag @s add phase2
execute as @e[tag=boss,type=minecraft:zombified_piglin,sort=nearest,limit=1] at @s run tag @s add canattack
execute as @e[tag=boss,type=minecraft:zombified_piglin,sort=nearest,limit=1] at @s run tag @s remove phase1
execute as @e[tag=boss,type=minecraft:zombified_piglin,sort=nearest,limit=1] at @s run tag @s remove alpha6
execute as @e[tag=boss,type=minecraft:zombified_piglin,sort=nearest,limit=1] at @s run tag @s remove beta6
scoreboard players set @e[tag=boss,type=minecraft:zombified_piglin] atk_cool 500
