#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

execute as @s at @s run data modify entity @e[type=minecraft:zombified_piglin,tag=boss,tag=phase2,tag=canattack,limit=1,sort=nearest] angry_at set from entity @p[distance=..40] UUID

#B-E-A-G-L-E-B-L-O-C-K-S