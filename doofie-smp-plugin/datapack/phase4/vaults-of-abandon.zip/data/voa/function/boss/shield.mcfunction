#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Damage Sound
particle minecraft:soul ~ ~ ~ .5 1 .5 .2 1 normal
particle minecraft:cloud ~ ~ ~ 1 2 1 .05 5 normal
execute as @e[type=minecraft:zombified_piglin,tag=boss,tag=canattack,tag=!casting] at @s if entity @a[distance=..4] run effect give @a[distance=..3] minecraft:wither 1 4
