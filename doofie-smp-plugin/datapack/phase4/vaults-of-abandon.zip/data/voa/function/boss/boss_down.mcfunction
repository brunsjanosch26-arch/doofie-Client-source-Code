#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#say BOOOO!

### Summons Effects
#particle minecraft:soul_fire_flame ~7.5 ~ ~.5 3 4 3 .02 700 normal
#execute at @s run playsound minecraft:ambient.cave ambient @a[distance=..100]

execute at @s run playsound minecraft:entity.lightning_bolt.thunder hostile @a[] ~ ~ ~ 5
execute at @s run playsound minecraft:block.anvil.land hostile @a[] ~ ~ ~ 5

execute if entity @e[tag=!down,tag=boss,type=minecraft:zombified_piglin,sort=nearest,limit=1] run data merge entity @e[tag=!down,tag=boss,type=minecraft:zombified_piglin,sort=nearest,limit=1] {Invulnerable:0b,equipment:{head:{id:'minecraft:flint',count:1,components:{"minecraft:custom_model_data":{floats:[730001]}}}},attributes:[{id:attack_damage,base:0}]}

###Added Damage Bonus - Turned off for now
effect give @s minecraft:resistance 100 1

#Summons Guards
execute as @e[tag=!down,tag=boss,tag=!beta6,tag=!alpha6,type=minecraft:zombified_piglin,sort=nearest,limit=1] at @s run summon stray ~ ~ ~2 {DeathLootTable:"voa:entities/legion_loot",Health:30f,Tags:["royal","voa"],CustomName:"Royal Legionnaire",equipment:{chest:{id:"minecraft:netherite_chestplate",count:1},head:{id:"minecraft:beetroot",count:1,components:{"minecraft:custom_model_data":{floats:[767676]}}},mainhand:{id:"minecraft:bow",count:1,components:{"minecraft:enchantments":{"minecraft:power":4,"minecraft:punch":2}}}},drop_chances:{chest:0.000,head:0.000,mainhand:0.000},attributes:[{id:"minecraft:follow_range",base:30},{id:"minecraft:max_health",base:30},{id:"minecraft:movement_speed",base:0.27}]}
execute as @e[tag=!down,tag=boss,tag=!beta6,tag=!alpha6,type=minecraft:zombified_piglin,sort=nearest,limit=1] at @s run summon stray ~ ~ ~-2 {DeathLootTable:"voa:entities/legion_loot",Health:30f,Tags:["royal","voa"],CustomName:"Royal Legionnaire",equipment:{chest:{id:"minecraft:netherite_chestplate",count:1},head:{id:"minecraft:beetroot",count:1,components:{"minecraft:custom_model_data":{floats:[767676]}}},mainhand:{id:"minecraft:bow",count:1,components:{"minecraft:enchantments":{"minecraft:power":4,"minecraft:punch":2}}}},drop_chances:{chest:0.000,head:0.000,mainhand:0.000},attributes:[{id:"minecraft:follow_range",base:30},{id:"minecraft:max_health",base:30},{id:"minecraft:movement_speed",base:0.27}]}


tag @s add down
tag @s remove canattack

scoreboard players set @e[tag=boss,type=minecraft:zombified_piglin,sort=nearest,limit=1] boss_cool 240





