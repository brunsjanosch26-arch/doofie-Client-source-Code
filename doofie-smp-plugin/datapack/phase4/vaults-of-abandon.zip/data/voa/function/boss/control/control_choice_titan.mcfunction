#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Control_Choice Sequence - Picks the Enemy

##Picks Between Wraith or Spectre

#randomizer function - 50/50 odds
scoreboard players set in math 0
scoreboard players set in1 math 11
function voa:natural_generation/random/range_lcg

#Fancy Particles and Sounds
playsound minecraft:ambient.cave hostile @a[] ~7.5 ~ ~.5 4 
particle minecraft:squid_ink ~7.5 ~ ~.5 12 12 12 .05 4000

##Bottom Floor
execute if score out math matches 0 run summon armor_stand ~25 ~ ~19 {Tags:["spawntitan100"]}

execute if score out math matches 1 run summon armor_stand ~26 ~ ~-18 {Tags:["spawntitan100"]}

execute if score out math matches 2 run summon armor_stand ~-11 ~ ~-19 {Tags:["spawntitan100"]}

execute if score out math matches 3 run summon armor_stand ~-12 ~ ~18 {Tags:["spawntitan100"]}


##Middle Floor
execute if score out math matches 4 run summon armor_stand ~-2 ~8 ~-17 {Tags:["spawntitan100"]}

execute if score out math matches 5 run summon armor_stand ~-2 ~8 ~18 {Tags:["spawntitan100"]}

execute if score out math matches 6 run summon armor_stand ~17 ~8 ~-17 {Tags:["spawntitan100"]}

execute if score out math matches 7 run summon armor_stand ~17 ~8 ~18 {Tags:["spawntitan100"]}


##Top Floor
execute if score out math matches 8 run summon armor_stand ~-9 ~14 ~-16 {Tags:["spawntitan100"]}

execute if score out math matches 9 run summon armor_stand ~-9 ~14 ~16 {Tags:["spawntitan100"]}

execute if score out math matches 10 run summon armor_stand ~23 ~14 ~16 {Tags:["spawntitan100"]}

execute if score out math matches 11 run summon armor_stand ~23 ~14 ~-16 {Tags:["spawntitan100"]}


### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
scoreboard players add @e[tag=titan,type=minecraft:zombie,tag=!stats] atk_cool 0
scoreboard players add @e[tag=titan,type=minecraft:zombie,tag=!stats] sound_cool 0
scoreboard players add @e[tag=titan,type=minecraft:zombie,tag=!stats] proxy 0
scoreboard players add @e[tag=titan,type=minecraft:zombie,tag=!stats] titanhealth 0

execute if score out math matches 9 run tag @e[tag=titan,type=minecraft:zombie,tag=!stats] add stats