#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Control_Choice Sequence - Picks the bat spawn

#say BETA1

##Bottom Floor
 #summon bat ~25.5 ~1 ~19.5 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,duration:999999,ShowParticles:0b}],Attributes:[{Name:max_health,Base:1},{Name:movement_speed,Base:0.15},{Name:attack_damage,Base:0}]}
 #summon bat ~26.5 ~1 ~-17.5 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,duration:999999,ShowParticles:0b}],Attributes:[{Name:max_health,Base:1},{Name:movement_speed,Base:0.15},{Name:attack_damage,Base:0}]}
 #summon bat ~-10.5 ~1 ~-18.5 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,duration:999999,ShowParticles:0b}],Attributes:[{Name:max_health,Base:1},{Name:movement_speed,Base:0.15},{Name:attack_damage,Base:0}]}
 #summon bat ~-11.5 ~1 ~18.5 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,duration:999999,ShowParticles:0b}],Attributes:[{Name:max_health,Base:1},{Name:movement_speed,Base:0.15},{Name:attack_damage,Base:0}]}
#
###Middle Floor
 #summon bat ~-2 ~9 ~-17 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,duration:999999,ShowParticles:0b}],Attributes:[{Name:max_health,Base:1},{Name:movement_speed,Base:0.15},{Name:attack_damage,Base:0}]}
 #summon bat ~-2 ~9 ~18 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,duration:999999,ShowParticles:0b}],Attributes:[{Name:max_health,Base:1},{Name:movement_speed,Base:0.15},{Name:attack_damage,Base:0}]}
 #summon bat ~17 ~9 ~-17 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,duration:999999,ShowParticles:0b}],Attributes:[{Name:max_health,Base:1},{Name:movement_speed,Base:0.15},{Name:attack_damage,Base:0}]}
summon bat ~17 ~9 ~18 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],active_effects:[{id:"minecraft:invisibility",amplifier:1,duration:999999,show_particles:0b}],attributes:[{id:attack_damage,base:0},{id:max_health,base:1},{id:movement_speed,base:0.15}]}

##Top Floor
 #summon bat ~-8.5 ~15 ~-15.5 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,duration:999999,ShowParticles:0b}],Attributes:[{Name:max_health,Base:1},{Name:movement_speed,Base:0.15},{Name:attack_damage,Base:0}]}
 #summon bat ~-8.5 ~15 ~16.5 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,duration:999999,ShowParticles:0b}],Attributes:[{Name:max_health,Base:1},{Name:movement_speed,Base:0.15},{Name:attack_damage,Base:0}]}
 #summon bat ~23.5 ~15 ~16.5 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,duration:999999,ShowParticles:0b}],Attributes:[{Name:max_health,Base:1},{Name:movement_speed,Base:0.15},{Name:attack_damage,Base:0}]}
summon bat ~23.5 ~15 ~-15.5 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],active_effects:[{id:"minecraft:invisibility",amplifier:1,duration:999999,show_particles:0b}],attributes:[{id:attack_damage,base:0},{id:max_health,base:1},{id:movement_speed,base:0.15}]}

execute at @s run function voa:boss/control/control1