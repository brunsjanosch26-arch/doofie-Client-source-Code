#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

execute store result score @s Bdb_x1 run data get entity @s Pos[0] 1000
execute store result score @s Bdb_y1 run data get entity @s Pos[1] 1000
execute store result score @s Bdb_z1 run data get entity @s Pos[2] 1000


tp @s ^ ^ ^0.1

execute store result score @s Bdb_x2 run data get entity @s Pos[0] 1000
execute store result score @s Bdb_y2 run data get entity @s Pos[1] 1000
execute store result score @s Bdb_z2 run data get entity @s Pos[2] 1000

scoreboard players operation @s Bdb_x2 -= @s Bdb_x1
scoreboard players operation @s Bdb_y2 -= @s Bdb_y1
scoreboard players operation @s Bdb_z2 -= @s Bdb_z1

execute store result entity @s Motion[0] double 0.03 run scoreboard players get @s Bdb_x2
execute store result entity @s Motion[1] double 0.03 run scoreboard players get @s Bdb_y2
execute store result entity @s Motion[2] double 0.03 run scoreboard players get @s Bdb_z2

execute store result entity @s power[0] double 0.000001 run scoreboard players get @s Bdb_x2
execute store result entity @s power[1] double 0.000001 run scoreboard players get @s Bdb_y2
execute store result entity @s power[2] double 0.000001 run scoreboard players get @s Bdb_z2

tag @s add motion

scoreboard players set @s byb_cool 35


