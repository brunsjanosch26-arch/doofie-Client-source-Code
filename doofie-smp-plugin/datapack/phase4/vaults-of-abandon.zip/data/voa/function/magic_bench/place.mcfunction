#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
# AS AND AT POSITION of custom item frame 
setblock ~ ~ ~ minecraft:dropper replace

execute positioned ^ ^ ^0.5 align xyz run summon armor_stand ~ ~ ~ {Fire:9999999,Small:1b,Marker:1b,Invisible:1b,Tags:["magic_bench"],equipment:{head:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":{floats:[727272]}}}}}
kill @s