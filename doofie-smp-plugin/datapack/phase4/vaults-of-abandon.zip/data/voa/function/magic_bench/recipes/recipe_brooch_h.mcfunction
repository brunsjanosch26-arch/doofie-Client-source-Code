#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

data merge block ~ ~ ~ {Items:[{Slot:4b,id:"minecraft:totem_of_undying",count:1,components:{"minecraft:custom_model_data":{floats:[310001]},"minecraft:attribute_modifiers":[{id:"653452343234",type:"attack_speed",amount:0.3d,operation:"add_value",slot:"offhand"},{id:"2314567543223",type:"max_health",amount:4.0d,operation:"add_value",slot:"offhand"}],"minecraft:custom_name":{"color":"blue","italic":true,"text":"Void Brooch (Lucky)"},"minecraft:enchantment_glint_override":true,"minecraft:custom_data":{harmony_brooch:1b}}}]}

playsound minecraft:entity.player.levelup master @a ~ ~ ~ 0.2 1