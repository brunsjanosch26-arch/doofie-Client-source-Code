#SUMMON DROPS
summon item ~ ~0.5 ~ {Item:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_name":"Magic Bench","minecraft:custom_model_data":{floats:[727272]},"minecraft:entity_data":{id:"minecraft:item_frame",Item:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":{floats:[727272]}}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["magic_bench"]}}}}

#KILL BLOCK DROP - PREVENTS Silk Touch!
kill @e[type=item,nbt={Item:{id:"minecraft:dropper"}},distance=0..2,sort=nearest,limit=1]


#KILL ITEM FRAME
kill @s