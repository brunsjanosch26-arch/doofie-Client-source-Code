#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

data merge block ~ ~ ~ {Items:[{Slot:4b,id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_model_data":{floats:[343434]},"minecraft:custom_name":"Staff: Firebender (12 Charges)","minecraft:custom_data":{staffd12:1b}}}]}


playsound minecraft:entity.player.levelup master @a ~ ~ ~ 0.2 1