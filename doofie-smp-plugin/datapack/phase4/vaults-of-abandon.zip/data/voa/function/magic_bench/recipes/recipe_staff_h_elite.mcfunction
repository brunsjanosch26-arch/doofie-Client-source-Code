#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

data merge block ~ ~ ~ {Items:[{Slot:4b,id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_model_data":{floats:[423232]},"minecraft:custom_name":"Godspell Staff: Divine Heal (12 Charges)","minecraft:custom_data":{staffm_h12:1b,staffm_h:1b}}}]}


playsound minecraft:entity.player.levelup master @a ~ ~ ~ 0.2 1