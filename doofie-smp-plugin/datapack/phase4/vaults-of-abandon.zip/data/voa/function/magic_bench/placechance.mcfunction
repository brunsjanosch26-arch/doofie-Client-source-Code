#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 9
function voa:natural_generation/random/range_lcg


#Result Run
execute if score out math matches 7 run function voa:magic_bench/placechancespawn
execute if score out math matches 8 run function voa:magic_bench/placechancespawn
execute if score out math matches 9 run function voa:magic_bench/placechancespawn


#B-E-A-G-L-E                B-L-O-C-K-S




tag @e[type=armor_stand,tag=magicbenchmarker,sort=nearest,limit=1] add summoned