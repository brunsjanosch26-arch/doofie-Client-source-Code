#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

data merge block ~ ~ ~ {Items:[{Slot:4b,id:"minecraft:netherite_sword",count:1,components:{"minecraft:custom_model_data":{floats:[666445]},"minecraft:enchantments":{"knockback":1,"sharpness":3,"smite":2,"unbreaking":5},"minecraft:custom_name":{"bold":true,"italic":true,"text":"X-Finity Blade (Chaos)"},"minecraft:custom_data":{xbladec:1b},"minecraft:lore":["Upon Damage; 33% Chance to Strap a mob to a rocket."]}}]}
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 0.2 1