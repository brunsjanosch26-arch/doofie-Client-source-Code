#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

data merge block ~ ~ ~ {Items:[{Slot:4b,id:"minecraft:carrot_on_a_stick",count:1,components:{"minecraft:custom_model_data":{floats:[234446]},"minecraft:enchantments":{"minecraft:unbreaking":1},"minecraft:tooltip_display":{hidden_components:["enchantments"]},"minecraft:custom_name":"Tome: Overshield","minecraft:custom_data":{tome_h:1b}}}]}


playsound minecraft:entity.player.levelup master @a ~ ~ ~ 0.2 1