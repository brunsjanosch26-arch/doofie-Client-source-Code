#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

data merge block ~ ~ ~ {Items:[{Slot:4b,id:"minecraft:totem_of_undying",count:1,components:{"minecraft:custom_model_data":{floats:[310003]},"minecraft:attribute_modifiers":[{id:"minecraft:74398673496734",type:"movement_speed",amount:0.03d,operation:"add_value",slot:"offhand"},{id:"minecraft:32896578647368376",type:"max_health",amount:4.0d,operation:"add_value",slot:"offhand"}],"minecraft:custom_name":{"color":"dark_red","italic":true,"text":"Void Brooch (Chaos)"},"minecraft:enchantment_glint_override":true,"minecraft:custom_data":{chaos_brooch:1b}}}]}


playsound minecraft:entity.player.levelup master @a ~ ~ ~ 0.2 1