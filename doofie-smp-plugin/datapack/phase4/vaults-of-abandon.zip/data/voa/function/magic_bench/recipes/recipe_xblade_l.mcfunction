#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

data merge block ~ ~ ~ {Items:[{Slot:4b,id:"minecraft:netherite_sword",count:1,components:{"minecraft:custom_model_data":{floats:[666446]},"minecraft:enchantments":{"knockback":1,"looting":3,"sharpness":3,"smite":2,"unbreaking":5},"minecraft:custom_name":{"bold":true,"italic":true,"text":"X-Finity Blade (Lucky)"},"minecraft:custom_data":{xbladel:1b},"minecraft:lore":["Upon Damage; 15% chance to turn Non-Monstrous Mob into a Bat."]}}]}

playsound minecraft:entity.player.levelup master @a ~ ~ ~ 0.2 1