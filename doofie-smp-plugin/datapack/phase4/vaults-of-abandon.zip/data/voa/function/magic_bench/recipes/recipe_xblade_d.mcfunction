#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

data merge block ~ ~ ~ {Items:[{Slot:4b,id:"minecraft:netherite_sword",count:1,components:{"minecraft:custom_model_data":{floats:[666448]},"minecraft:enchantments":{"fire_aspect":3,"knockback":1,"sharpness":3,"smite":3,"unbreaking":5},"minecraft:custom_name":{"bold":true,"italic":true,"text":"X-Finity Blade (Dangerous)"},"minecraft:custom_data":{xbladed:1b},"minecraft:lore":["Upon Damage; 20% Chance to set firestorm on ANY mobs within 7 Blocks."]}}]}

playsound minecraft:entity.player.levelup master @a ~ ~ ~ 0.2 1

#B-E-A-G-L-E-B-L-O-C-K-S
