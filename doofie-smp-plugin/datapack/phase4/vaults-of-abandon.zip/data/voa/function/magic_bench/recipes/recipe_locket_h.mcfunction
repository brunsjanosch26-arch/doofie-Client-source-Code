#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

data merge block ~ ~ ~ {Items:[{Slot:4b,id:"minecraft:totem_of_undying",count:1,components:{"minecraft:custom_model_data":{floats:[323232]},"minecraft:attribute_modifiers":[{id:"minecraft:101010",type:"max_health",amount:2.0d,operation:"add_value",slot:"offhand"}],"minecraft:custom_name":{"color":"blue","italic":true,"text":"Void Locket (Harmony)"},"minecraft:enchantment_glint_override":true,"minecraft:custom_data":{harmony_locket:1b}}}]}


playsound minecraft:entity.player.levelup master @a ~ ~ ~ 0.2 1                                          
