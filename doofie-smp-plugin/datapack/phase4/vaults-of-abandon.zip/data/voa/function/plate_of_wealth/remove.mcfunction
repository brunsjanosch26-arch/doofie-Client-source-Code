#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#SUMMON DROPS
summon item ~ ~0.5 ~ {Item:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_name":"Plate of Wealth","minecraft:custom_model_data":{floats:[222223]},"minecraft:entity_data":{id:"minecraft:item_frame",Item:{id:"minecraft:item_frame",count:1,components:{"minecraft:custom_model_data":{floats:[222223]}}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["wealth"]}}}}
#KILL BLOCK DROP - PREVENTS Silk Touch!
kill @e[type=item,nbt={Item:{id:"minecraft:quartz_slab"}},distance=0..2,sort=nearest,limit=1]


#KILL ITEM FRAME
kill @s