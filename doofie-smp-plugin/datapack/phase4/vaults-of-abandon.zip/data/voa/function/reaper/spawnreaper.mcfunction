#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 2
function voa:natural_generation/random/range_lcg

### THIS IS THE SPAWN COMMAND if I need to change the mob attributes this is where I will do it!!!
execute if score out math matches 1 run particle soul ~ ~1 ~ 0.2 0.5 0.2 0.0005 20 normal
execute if score out math matches 1 run summon husk ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"voa:entities/reaper_loot",PersistenceRequired:1b,Health:30f,CanBreakDoors:1b,DrownedConversionTime:99999,Tags:["reaper","voa"],CustomName:"Reaper",equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[931022]}}}},drop_chances:{head:0.000},active_effects:[{id:"minecraft:jump_boost",amplifier:1,duration:99999,show_particles:0b},{id:"minecraft:invisibility",amplifier:1,duration:999999,show_particles:0b}],attributes:[{id:"minecraft:attack_damage",base:20},{id:"minecraft:follow_range",base:20},{id:"minecraft:max_health",base:30},{id:"minecraft:movement_speed",base:0.2}]}
execute if score out math matches 1 run playsound minecraft:block.grass.step hostile @a ~ ~ ~ 0.6 1.5
#### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
scoreboard players add @e[tag=reaper,type=minecraft:husk,sort=nearest,limit=1] sound_cool 0

#Execute for Spectral-Schimitar
tag @e[tag=reaper,type=minecraft:husk] add ghost

#Kills Marker
tag @s add summoned