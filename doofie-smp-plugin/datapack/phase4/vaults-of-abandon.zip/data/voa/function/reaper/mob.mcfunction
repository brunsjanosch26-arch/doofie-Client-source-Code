#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
##Sounds-------------------------------------------
execute as @s[scores={sound_cool=75},tag=frenzied] at @s run playsound minecraft:reaper.mob.wail hostile @a[]
execute as @s[scores={sound_cool=0},tag=frenzied] at @s run scoreboard players set @s sound_cool 150

##Animation----------------------------------------
#Mob Sound/Sound Timer/Reset Sound so it happens again - UNFRENZY
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players add @s mob_demo_time 1
execute if entity @s[scores={mob_demo_time=2},tag=!frenzied] run playsound minecraft:block.grass.step hostile @a[distance=0..14] ~ ~ ~ 0.2 1
execute if entity @s[scores={mob_demo_time=20,},tag=!frenzied] run scoreboard players set @s mob_demo_time 0
execute if entity @s[scores={mob_demo_time=20,},tag=frenzied] run scoreboard players set @s mob_demo_time 0
#Mob Sound/Sound Timer/Reset Sound so it happens again - FRENZY!
execute if entity @s[scores={mob_demo_time=2},tag=frenzied] run playsound minecraft:block.grass.step hostile @a[distance=0..14] ~ ~ ~ 0.2 1
execute if entity @s[scores={mob_demo_time=2},tag=frenzied] run particle minecraft:ash ~ ~1 ~ 0 0 0 1 6 normal
execute if entity @s[scores={mob_demo_time=8},tag=frenzied] run particle minecraft:ash ~ ~1 ~ 0 0 0 1 6 normal
execute if entity @s[scores={mob_demo_time=8,},tag=frenzied] run scoreboard players set @s mob_demo_time 0
#Moving Animation - FRENZY!
execute if entity @s[scores={animate=1},tag=frenzied] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=reaper,tag=frenzied] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[931021]}}}}}
#Resets Moving Animation - FRENZY!
execute if entity @s[nbt={Motion:[0.0d,0.0d,0.0d]},tag=frenzied] run scoreboard players set @s animate 0
execute if entity @s[scores={animate=0},tag=frenzied] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=reaper,tag=frenzied] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[931020]}}}}}
#Damage Sound
execute if entity @s[nbt={HurtTime:10s}] run playsound minecraft:wraith.mob.hurt hostile @a[distance=0..10]
#Detects if mob is moving
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]},tag=frenzied] run scoreboard players add @s animate 1 

##Frenzy Attack------------------------------------
execute as @s[tag=!frenzied] at @s if entity @a[distance=..3] run playsound minecraft:reaper.mob.attack hostile @a[distance=0..16]
execute as @s[tag=!frenzied] at @s if entity @a[distance=..3] run particle minecraft:white_smoke ~ ~ ~ 0 0 0 .15 200
execute as @s[tag=!frenzied] at @s if entity @a[distance=..3] run data merge entity @e[tag=!frenzied,tag=reaper,type=minecraft:husk,sort=nearest,limit=1] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[931021]}}}},attributes:[{id:movement_speed,base:0.50}]}
execute as @s[tag=!frenzied] at @s if entity @a[distance=..3] run tag @s add frenzied

##Unfrenzy Mode
execute as @s[tag=frenzied] at @s unless entity @a[distance=..12] run particle minecraft:white_smoke ~ ~ ~ 0 0 0 .15 200
execute as @s[tag=frenzied] at @s unless entity @a[distance=..12] run data merge entity @e[tag=frenzied,tag=reaper,type=minecraft:husk,sort=nearest,limit=1] {equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:custom_model_data":{floats:[931022]}}}},attributes:[{id:movement_speed,base:0.20}]}
execute as @s[tag=frenzied] at @s unless entity @a[distance=..12] run tag @s remove frenzied

##Countdown----------------------------------------
execute as @s[] at @s run scoreboard players remove @s[scores={sound_cool=1..},tag=frenzied] sound_cool 1