execute at @s if entity @n[type=minecraft:copper_golem, distance=..10] unless data entity @n[type=minecraft:copper_golem] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims bolt
advancement revoke @s only tatevancements:apply_thematic_trim_check/bolt