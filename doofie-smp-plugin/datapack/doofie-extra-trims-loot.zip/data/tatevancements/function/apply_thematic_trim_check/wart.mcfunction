execute at @s if entity @n[type=minecraft:witch, distance=..10] unless data entity @n[type=minecraft:witch] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims wart
advancement revoke @s only tatevancements:apply_thematic_trim_check/wart