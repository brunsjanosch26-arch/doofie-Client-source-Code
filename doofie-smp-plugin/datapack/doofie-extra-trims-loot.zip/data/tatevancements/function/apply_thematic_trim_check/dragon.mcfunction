execute at @s if entity @n[type=minecraft:ender_dragon, distance=..10] unless data entity @n[type=minecraft:ender_dragon] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims dragon
advancement revoke @s only tatevancements:apply_thematic_trim_check/dragon