execute at @s if entity @n[type=minecraft:cave_spider, distance=..10] unless data entity @n[type=minecraft:cave_spider] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims miner
advancement revoke @s only tatevancements:apply_thematic_trim_check/miner