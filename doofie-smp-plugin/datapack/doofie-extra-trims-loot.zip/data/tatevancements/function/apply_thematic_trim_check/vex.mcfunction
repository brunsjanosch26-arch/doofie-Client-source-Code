execute at @s if entity @n[type=minecraft:vex, distance=..10] unless data entity @n[type=minecraft:vex] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims vex
advancement revoke @s only tatevancements:apply_thematic_trim_check/vex