execute at @s if entity @n[type=minecraft:drowned, distance=..10] unless data entity @n[type=minecraft:drowned] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims flood
advancement revoke @s only tatevancements:apply_thematic_trim_check/flood