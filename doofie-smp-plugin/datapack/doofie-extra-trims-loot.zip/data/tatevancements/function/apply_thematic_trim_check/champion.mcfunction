execute at @s if entity @n[type=minecraft:ravager, distance=..10] unless data entity @n[type=minecraft:ravager] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims champion
advancement revoke @s only tatevancements:apply_thematic_trim_check/champion