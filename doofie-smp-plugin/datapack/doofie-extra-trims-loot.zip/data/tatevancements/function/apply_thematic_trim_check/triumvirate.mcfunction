execute at @s if entity @n[type=minecraft:wither, distance=..10] unless data entity @n[type=minecraft:wither] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims triumvirate
advancement revoke @s only tatevancements:apply_thematic_trim_check/triumvirate