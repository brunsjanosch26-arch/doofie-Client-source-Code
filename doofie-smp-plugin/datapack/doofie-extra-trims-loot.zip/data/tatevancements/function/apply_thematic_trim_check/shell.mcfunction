execute at @s if entity @n[type=minecraft:armadillo, distance=..10] unless data entity @n[type=minecraft:armadillo] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims shell
advancement revoke @s only tatevancements:apply_thematic_trim_check/shell