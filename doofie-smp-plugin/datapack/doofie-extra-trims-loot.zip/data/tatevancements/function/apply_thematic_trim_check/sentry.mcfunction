execute at @s if entity @n[type=minecraft:pillager, distance=..10] unless data entity @n[type=minecraft:pillager] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims sentry
advancement revoke @s only tatevancements:apply_thematic_trim_check/sentry