execute at @s if entity @n[type=minecraft:enderman, distance=..10] unless data entity @n[type=minecraft:enderman] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims eye
advancement revoke @s only tatevancements:apply_thematic_trim_check/eye