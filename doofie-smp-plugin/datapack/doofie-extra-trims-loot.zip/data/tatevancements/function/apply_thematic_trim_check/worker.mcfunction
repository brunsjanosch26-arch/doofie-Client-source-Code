execute at @s if entity @n[type=minecraft:villager, distance=..10] unless data entity @n[type=minecraft:villager] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims worker
advancement revoke @s only tatevancements:apply_thematic_trim_check/worker