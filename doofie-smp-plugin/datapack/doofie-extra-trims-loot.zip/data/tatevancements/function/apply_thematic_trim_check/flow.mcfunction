execute at @s if entity @n[type=minecraft:breeze, distance=..10] unless data entity @n[type=minecraft:breeze] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims flow
advancement revoke @s only tatevancements:apply_thematic_trim_check/flow