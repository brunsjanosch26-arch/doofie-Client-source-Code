execute at @s if entity @n[type=minecraft:elder_guardian, distance=..10] unless data entity @n[type=minecraft:elder_guardian] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims tide
advancement revoke @s only tatevancements:apply_thematic_trim_check/tide