execute at @s if entity @n[type=minecraft:creeper, distance=..10] unless data entity @n[type=minecraft:creeper] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims creep
advancement revoke @s only tatevancements:apply_thematic_trim_check/creep