execute at @s if entity @n[type=minecraft:warden, distance=..10] unless data entity @n[type=minecraft:warden] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims silence
advancement revoke @s only tatevancements:apply_thematic_trim_check/silence