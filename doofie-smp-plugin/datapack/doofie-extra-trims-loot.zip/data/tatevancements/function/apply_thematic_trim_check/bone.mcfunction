execute at @s if entity @n[type=#extratrims:skeletons, distance=..10] unless data entity @n[type=#extratrims:skeletons] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims bone
advancement revoke @s only tatevancements:apply_thematic_trim_check/bone