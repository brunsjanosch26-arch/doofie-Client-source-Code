execute at @s if entity @n[type=minecraft:piglin_brute, distance=..10] unless data entity @n[type=minecraft:piglin_brute] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims snout
advancement revoke @s only tatevancements:apply_thematic_trim_check/snout