execute at @s if entity @n[type=minecraft:shulker, distance=..10] unless data entity @n[type=minecraft:shulker] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims spire
advancement revoke @s only tatevancements:apply_thematic_trim_check/spire