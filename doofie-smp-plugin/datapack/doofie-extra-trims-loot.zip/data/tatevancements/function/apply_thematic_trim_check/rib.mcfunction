execute at @s if entity @n[type=minecraft:wither_skeleton, distance=..10] unless data entity @n[type=minecraft:wither_skeleton] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims rib
advancement revoke @s only tatevancements:apply_thematic_trim_check/rib