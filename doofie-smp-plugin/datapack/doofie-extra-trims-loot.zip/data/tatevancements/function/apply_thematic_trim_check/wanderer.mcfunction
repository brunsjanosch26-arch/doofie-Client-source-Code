execute at @s if entity @n[type=minecraft:wandering_trader, distance=..10] unless data entity @n[type=minecraft:wandering_trader] NoAI \
run advancement grant @s only tatevancements:apply_thematic_trims wanderer
advancement revoke @s only tatevancements:apply_thematic_trim_check/wanderer