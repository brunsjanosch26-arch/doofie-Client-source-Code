# determine what material to give before removing trim.
playsound minecraft:block.grindstone.use block @a[distance=..8] ~ ~ ~ 100 1.15 1
particle minecraft:block{block_state:{Name:"minecraft:grindstone"}} ~ ~ ~ 0.25 0.25 0.25 1 5 force

function extratrims:remove_trim/material

data remove entity @s Item.components.minecraft:trim