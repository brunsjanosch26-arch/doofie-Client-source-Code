# Change the armor's trim to the dropped material and remove one of that material from its stack.
advancement grant @p[distance=..5] only tatevancements:change_trim_material
playsound minecraft:block.smithing_table.use block @a[distance=..8] ~ ~ ~ 100 1.15 1
particle minecraft:block{block_state:{Name:"minecraft:smithing_table"}} ~ ~ ~ 0.25 0.25 0.25 1 5 force

$item modify entity @n[type=minecraft:item, distance=...5, nbt={Item:{id:"$(item)"}}] container.0 [{function:"minecraft:set_count", count:-1, add:true}]
$data modify entity @s Item.components.minecraft:trim.material set value "$(material)"