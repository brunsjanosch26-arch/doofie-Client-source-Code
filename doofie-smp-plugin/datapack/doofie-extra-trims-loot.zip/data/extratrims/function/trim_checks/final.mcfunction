# Remove trim of armor thrown on Grindstone
execute if block ~ ~-1 ~ minecraft:grindstone run return run function extratrims:remove_trim/main

# Change the trim material of armor thrown on a Smithing Table next to another item
execute if block ~ ~-1 ~ minecraft:smithing_table if items entity @n[type=minecraft:item, distance=.01...5] container.0 #minecraft:trim_materials \
run function extratrims:change_trim_material/initial