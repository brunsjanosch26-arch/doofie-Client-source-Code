# So do not fear, for I am with you; do not be dismayed, for I am your God. 
# I will strengthen you and help you; I will uphold you with my righteous right hand.
# - Isaiah 41:10

# Check item for trim material
execute as @e[type=minecraft:item] if items entity @s container.0 *[minecraft:trim] at @s \
run function extratrims:trim_checks/final