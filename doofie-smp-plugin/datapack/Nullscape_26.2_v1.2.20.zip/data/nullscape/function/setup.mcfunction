# Init scoreboards
scoreboard objectives add tr.first dummy

# Schedule (wait for Terralith + Incendium)
schedule function nullscape:wait_for_player 30t replace