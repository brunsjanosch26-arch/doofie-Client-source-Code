# run from #minecraft:tick

# rift gateway linking
execute in minecraft:the_end as @e[type=minecraft:marker,tag=nullscape.rift_gateway,x=0] at @s if data block ~ ~ ~ exit_portal run function nullscape:link_rift
