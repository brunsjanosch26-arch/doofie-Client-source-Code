# from: ./on_hit

effect give @e[type=#minecraft:undead,tag=in.hit] instant_health 1 1
effect give @e[type=!#minecraft:undead,tag=in.hit] instant_damage 1 1
