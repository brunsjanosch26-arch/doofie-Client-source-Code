# from ./update
# @s: helper marker (at @s is still player)

# update rotation as well
$execute rotated $(scouts_helmet) 0 positioned ^ ^ ^0.6 run particle minecraft:dust_color_transition{from_color:[1f,0f,0f], scale:1.4, to_color:[0f,1f,1f]} ~ ~0.6 ~ 0 0 0 1 2 force
