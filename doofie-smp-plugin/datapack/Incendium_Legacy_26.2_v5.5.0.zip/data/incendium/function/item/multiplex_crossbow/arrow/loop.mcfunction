# loops the code at active targets
execute as @e[type=#arrows,tag=in.multiplex_arrow,tag=in.checked] run execute at @s as @s run function incendium:item/multiplex_crossbow/arrow/main


