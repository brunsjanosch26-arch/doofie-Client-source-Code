playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.840896 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.334840 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.681793 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.334840 1
playsound minecraft:block.note_block.guitar record @s ^0 ^ ^ 1 0.840896 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 1 1.681793 1
playsound minecraft:block.note_block.bass record @s ^0 ^ ^ 1 1.122462 1
playsound minecraft:block.note_block.bass record @s ^0 ^ ^ 1 1.681793 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.681793 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.334840 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 1 0.629961 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 1 1.781797 1
scoreboard players set @s nbs_borderofli_t 470