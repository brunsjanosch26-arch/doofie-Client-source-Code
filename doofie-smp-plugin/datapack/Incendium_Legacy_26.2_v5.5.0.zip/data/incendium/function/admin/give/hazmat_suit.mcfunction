loot give @s loot incendium:artifact/tool/hazmat_helm
loot give @s loot incendium:artifact/tool/hazmat_chest
loot give @s loot incendium:artifact/tool/hazmat_legs
loot give @s loot incendium:artifact/tool/hazmat_boots
